package com.example.bikerental

import java.util.Date

data class Rental(
    val id: String,
    val bikeName: String,
    val bikeType: String,
    val startTime: Date,
    val endTime: Date?,
    val duration: Int, // in hours
    val price: Double,
    val status: RentalStatus,
    val location: String,
    val imageRes: Int = android.R.drawable.ic_menu_mylocation
)

enum class RentalStatus {
    ACTIVE,
    COMPLETED,
    CANCELLED,
    UPCOMING
} 