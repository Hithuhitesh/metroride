package com.example.bikerental

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.bikerental.databinding.ActivityLoginDetailsBinding

class LoginDetailsActivity : AppCompatActivity() {
    private lateinit var binding: ActivityLoginDetailsBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginDetailsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val role = intent.getStringExtra("role") ?: "user"
        
        // Set role-specific content
        setupRoleSpecificContent(role)
        
        // Add entrance animations
        addEntranceAnimations()

        binding.btnContinue.setOnClickListener {
            if (validateForm()) {
                val name = binding.etName.text.toString().trim()
                val email = binding.etEmail.text.toString().trim()
                val phone = binding.etPhone.text.toString().trim()
                
                // Generate a simple password for new users (in real app, this would be set by user)
                val password = "metro123" // Default password for new accounts
                
                // Save user data
                val prefs = getSharedPreferences("metro_ride_prefs", MODE_PRIVATE)
                prefs.edit()
                    .putString("role", role)
                    .putString("name", name)
                    .putString("email", email)
                    .putString("phone", phone)
                    .putString("password", password)
                    .putBoolean("isLoggedIn", true)
                    .apply()
                
                // Show success message and navigate
                Toast.makeText(this, "Account created successfully! Default password: metro123", Toast.LENGTH_LONG).show()
                startActivity(Intent(this, MainActivity::class.java))
                finish()
            }
        }
    }
    
    private fun setupRoleSpecificContent(role: String) {
        val roleIndicator = binding.tvRoleIndicator
        val loginSubtitle = binding.tvLoginSubtitle
        
        when (role) {
            "admin" -> {
                roleIndicator.text = "Admin Profile"
                loginSubtitle.text = "Complete your admin profile to manage the platform"
            }
            "user" -> {
                roleIndicator.text = "User Profile"
                loginSubtitle.text = "Complete your profile to start renting bikes"
            }
            else -> {
                roleIndicator.text = "User Profile"
                loginSubtitle.text = "Complete your profile to continue"
            }
        }
    }
    
    private fun addEntranceAnimations() {
        // Simple fade in for the card
        binding.root.findViewById<androidx.cardview.widget.CardView>(R.id.cardView)?.alpha = 0f
        binding.root.findViewById<androidx.cardview.widget.CardView>(R.id.cardView)?.animate()?.alpha(1f)?.setDuration(800)?.start()
    }

    private fun validateForm(): Boolean {
        val name = binding.etName.text.toString().trim()
        val email = binding.etEmail.text.toString().trim()
        val phone = binding.etPhone.text.toString().trim()

        var isValid = true

        if (name.isEmpty()) {
            binding.etName.error = "Name is required"
            isValid = false
        }

        if (email.isEmpty()) {
            binding.etEmail.error = "Email is required"
            isValid = false
        } else if (!android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            binding.etEmail.error = "Please enter a valid email"
            isValid = false
        }

        // Phone number is optional, but if provided, it should be valid
        if (phone.isNotEmpty() && phone.length < 10) {
            binding.etPhone.error = "Please enter a valid phone number"
            isValid = false
        }

        return isValid
    }
} 