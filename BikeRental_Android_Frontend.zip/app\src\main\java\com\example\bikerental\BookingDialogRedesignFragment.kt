package com.example.bikerental

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.fragment.app.DialogFragment

class BookingDialogRedesignFragment : DialogFragment() {
    private var bike: Bike? = null
    private var isHourly: Boolean = true
    private var selectedHours: Int = 1
    private var startDateMs: Long? = null
    private var endDateMs: Long? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        bike = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) {
            arguments?.getParcelable(ARG_BIKE, Bike::class.java)
        } else {
            @Suppress("DEPRECATION")
            arguments?.getParcelable(ARG_BIKE)
        }
        // Use default dialog theme; custom style optional
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater.inflate(R.layout.fragment_booking_dialog_redesign, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        var b = bike ?: return
        // Enrich specs so nothing is blank
        b = b.withDefaultsForKnownBike()

        // Read initial selection from args (from BrowseBikesFragment/Time picker)
        arguments?.let { a ->
            isHourly = a.getBoolean("isHourly", isHourly)
            selectedHours = a.getInt("duration", selectedHours)
        }

        // Header/back
        view.findViewById<ImageView?>(R.id.btnBack)?.setOnClickListener { dismiss() }

        // Basic details
        view.findViewById<ImageView?>(R.id.ivBikeImage)?.setImageResource(b.getBikeImageRes())
        view.findViewById<TextView?>(R.id.tvBikeName)?.text = b.name
        view.findViewById<TextView?>(R.id.tvBikeType)?.text = "${b.type} • ${if (b.year>0) b.year else "-"}"
        view.findViewById<TextView?>(R.id.tvBikeRating)?.text = "${String.format("%.1f", b.rating)} (${b.reviewCount} reviews)"
        view.findViewById<TextView?>(R.id.tvBikePrice)?.text = "₹${b.price}/hour"

        // Location
        val hasAddress = b.address.isNotBlank()
        val fullAddress = if (hasAddress) listOf(b.address, b.city, b.pincode).filter { it.isNotBlank() }.joinToString(", ") else b.location
        view.findViewById<TextView?>(R.id.tvBikeLocation)?.text = b.location
        // Hide address/landmark if not explicitly provided to avoid fake-looking details
        val tvAddr = view.findViewById<TextView?>(R.id.tvBikeAddress)
        val llLandmark = view.findViewById<View?>(R.id.llLandmark)
        if (hasAddress) {
            tvAddr?.text = b.address
            tvAddr?.visibility = View.VISIBLE
            if (b.landmark.isNotBlank()) {
                llLandmark?.visibility = View.VISIBLE
                view.findViewById<TextView?>(R.id.tvBikeLandmark)?.text = "Near ${b.landmark}"
            } else {
                llLandmark?.visibility = View.GONE
            }
        } else {
            tvAddr?.visibility = View.GONE
            llLandmark?.visibility = View.GONE
        }
        view.findViewById<TextView?>(R.id.tvFullAddress)?.text = fullAddress

        val openMap: (View) -> Unit = {
            val query = if (fullAddress.isNotBlank()) fullAddress else b.location
            val uri = Uri.parse("geo:0,0?q=" + Uri.encode(query))
            val intent = Intent(Intent.ACTION_VIEW, uri).setPackage("com.google.android.apps.maps")
            if (intent.resolveActivity(requireContext().packageManager) != null) startActivity(intent)
        }
        view.findViewById<View?>(R.id.btnViewMap)?.setOnClickListener(openMap)
        view.findViewById<View?>(R.id.ivMapPreview)?.setOnClickListener(openMap)
        view.findViewById<View?>(R.id.btnOpenInMaps)?.setOnClickListener(openMap)

        // Owner
        view.findViewById<TextView?>(R.id.tvOwnerName)?.text = when (b.location) {
            "Marina Beach" -> "Rahul Kumar"
            "T. Nagar" -> "Priya Sharma"
            "Velachery" -> "Arun Kumar"
            "Adyar" -> "Meera Patel"
            "Guindy" -> "Suresh Reddy"
            "Anna Nagar" -> "Lakshmi Devi"
            else -> "Bike Owner"
        }
        view.findViewById<View?>(R.id.btnContactOwner)?.setOnClickListener {
            val phone = if (b.ownerPhone.isNotEmpty()) b.ownerPhone else "9876543210"
            val options = arrayOf("Call", "Message")
            androidx.appcompat.app.AlertDialog.Builder(requireContext())
                .setTitle("Contact Owner")
                .setItems(options) { d, which ->
                    if (which == 0) {
                        val dial = Intent(Intent.ACTION_DIAL, Uri.parse("tel:${phone}"))
                        if (dial.resolveActivity(requireContext().packageManager) != null) startActivity(dial)
                    } else {
                        val sms = Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:${phone}"))
                        sms.putExtra("sms_body", "Hi, I'm interested in the ${b.name} booking.")
                        if (sms.resolveActivity(requireContext().packageManager) != null) startActivity(sms)
                    }
                    d.dismiss()
                }
                .show()
        }

        // Specifications table
        view.findViewById<TextView?>(R.id.tvBikeSpecType)?.text = b.type.ifEmpty { "-" }
        view.findViewById<TextView?>(R.id.tvBikeSpecFuel)?.text = when {
            b.fuelType.isNotEmpty() -> b.fuelType
            b.batteryCapacityKwh != null -> "Electric"
            else -> "-"
        }
        view.findViewById<TextView?>(R.id.tvBikeSpecYear)?.text = if (b.year>0) "${b.year}" else "-"
        view.findViewById<TextView?>(R.id.tvBikeSpecEngine)?.text = when {
            b.engineCc != null -> "${b.engineCc}cc ${b.engineType}".trim()
            b.batteryCapacityKwh != null -> "${b.batteryCapacityKwh} kWh"
            else -> "-"
        }
        view.findViewById<TextView?>(R.id.tvBikeSpecFuelCapacity)?.text = b.fuelCapacityLiters?.let { "${String.format("%.1f", it)} L" } ?: "-"
        view.findViewById<TextView?>(R.id.tvBikeSpecMileage)?.text = b.mileageKmpl?.let { "${it} kmpl" } ?: b.rangeKm?.let { "${it} km" } ?: "-"
        view.findViewById<TextView?>(R.id.tvBikeSpecTopSpeed)?.text = b.topSpeedKmph?.let { "${it} kmph" } ?: "-"
        view.findViewById<TextView?>(R.id.tvBikeSpecDeposit)?.text = b.getFormattedDeposit()

        // Populate clear specifications block (layoutSpecs)
        view.findViewById<TextView?>(R.id.tvSpecModel)?.text = b.model?.let { "Model: ${it}" } ?: "Model: ${b.name}"
        view.findViewById<TextView?>(R.id.tvSpecYear)?.text = "Year: ${if (b.year > 0) b.year else "-"}"
        view.findViewById<TextView?>(R.id.tvSpecFuel)?.text = "Fuel: " + when {
            b.fuelType.isNotEmpty() -> b.fuelType
            b.batteryCapacityKwh != null -> "Electric"
            else -> "-"
        }
        view.findViewById<TextView?>(R.id.tvSpecEngBat)?.text = when {
            b.engineCc != null -> "Engine: ${b.engineCc}cc ${b.engineType}".trim()
            b.batteryCapacityKwh != null -> "Battery: ${b.batteryCapacityKwh} kWh"
            else -> "Engine/Battery: -"
        }
        view.findViewById<TextView?>(R.id.tvSpecPowerTorque)?.text = listOfNotNull(
            b.powerHp?.let { "Power: ${String.format("%.1f", it)} hp" },
            b.torqueNm?.let { "Torque: ${String.format("%.0f", it)} Nm" }
        ).joinToString("  •  ").let { if (it.isBlank()) "Power/Torque: -" else it }
        view.findViewById<TextView?>(R.id.tvSpecRangeMileage)?.text = when {
            b.rangeKm != null -> "Range: ${b.rangeKm} km"
            b.mileageKmpl != null -> "Mileage: ${b.mileageKmpl} kmpl"
            else -> "Range/Mileage: -"
        }
        view.findViewById<TextView?>(R.id.tvSpecDeposit)?.text = "Refundable Deposit: ${b.getFormattedDeposit()}"
        view.findViewById<TextView?>(R.id.tvSpecSafety)?.text = "Safety: ABS / Helmet Provided / Insurance"

        // Booking options and price
        val hourlyRate = b.price
        val dailyRate = b.price * 8
        view.findViewById<TextView?>(R.id.tvSelectedBookingType)?.text = "Hourly Booking Selected"
        view.findViewById<TextView?>(R.id.tvHourlyPrice)?.text = "₹${hourlyRate}/hour"
        view.findViewById<TextView?>(R.id.tvDailyPrice)?.text = "₹${dailyRate}/day"
        view.findViewById<TextView?>(R.id.tvHourlyRate)?.text = "₹${hourlyRate}/hr"
        view.findViewById<TextView?>(R.id.tvDailyRate)?.text = "₹${dailyRate}/day"
        view.findViewById<TextView?>(R.id.tvBasePrice)?.text = "₹${hourlyRate}"
        view.findViewById<TextView?>(R.id.tvPriceDuration)?.text = "${selectedHours} hour"
        view.findViewById<TextView?>(R.id.tvTotalCost)?.text = "₹${hourlyRate * selectedHours}"
        view.findViewById<TextView?>(R.id.tvRentalDuration)?.text = "1-24 hours"
        view.findViewById<TextView?>(R.id.tvPickupMode)?.text = b.pickupMode.ifEmpty { "Manual pickup" }

        val layoutHourly: View? = null
        val layoutDaily = view.findViewById<View?>(R.id.layoutDateSelection)
        val btnHourly: Button? = null
        val btnDaily: Button? = null
        val tvHours: TextView? = null
        val tvHourlyTotal: TextView? = null
        val btnDec: Button? = null
        val btnInc: Button? = null
        val btnStartDate = view.findViewById<Button?>(R.id.btnStartDate)
        val btnEndDate = view.findViewById<Button?>(R.id.btnEndDate)
        val tvDateDuration = view.findViewById<TextView?>(R.id.tvDateDuration)

        fun updateHourlyUi() {
            // hourly UI removed
            view.findViewById<TextView?>(R.id.tvPriceDuration)?.text = "${selectedHours} ${if (selectedHours==1) "hour" else "hours"}"
            view.findViewById<TextView?>(R.id.tvTotalCost)?.text = "₹${hourlyRate * selectedHours}"
        }

        fun updateDailyUi() {
            val days = if (startDateMs != null && endDateMs != null && endDateMs!! >= startDateMs!!) {
                val oneDay = 24L * 60 * 60 * 1000
                val d = ((endDateMs!! - startDateMs!!) / oneDay).toInt().coerceAtLeast(1)
                d
            } else 1
            tvDateDuration?.text = "Duration: ${days} ${if (days==1) "day" else "days"}"
            view.findViewById<TextView?>(R.id.tvPriceDuration)?.text = "${days} ${if (days==1) "day" else "days"}"
            view.findViewById<TextView?>(R.id.tvTotalCost)?.text = "₹${dailyRate * days}"
        }

        fun selectHourly() {
            isHourly = true
            // Remove hour selector per request; keep it hidden
            // no hourly layout anymore
            layoutDaily?.visibility = View.GONE
        view.findViewById<TextView?>(R.id.tvSelectedBookingType)?.text = "Hourly Booking Selected"
            updateHourlyUi()
            // pricing selector removed
        }

        fun selectDaily() {
            isHourly = false
            layoutHourly?.visibility = View.GONE
            layoutDaily?.visibility = View.VISIBLE
            view.findViewById<TextView?>(R.id.tvSelectedBookingType)?.text = "Daily Booking Selected"
            updateDailyUi()
            // pricing selector removed
        }

        // default selection based on passed mode
        if (isHourly) selectHourly() else selectDaily()

        // pricing selector removed

        // decrement/increment removed

        val dateFormat = java.text.SimpleDateFormat("dd MMM yyyy", java.util.Locale.getDefault())
        btnStartDate?.setOnClickListener {
            val cal = java.util.Calendar.getInstance()
            val dp = android.app.DatePickerDialog(requireContext(), { _, y, m, d ->
                val c = java.util.Calendar.getInstance().apply { set(y, m, d, 0, 0, 0); set(java.util.Calendar.MILLISECOND, 0) }
                startDateMs = c.timeInMillis
                btnStartDate.text = dateFormat.format(c.time)
                if (endDateMs == null || endDateMs!! < startDateMs!!) endDateMs = startDateMs
                btnEndDate.text = dateFormat.format(java.util.Date(endDateMs!!))
                updateDailyUi()
            }, cal.get(java.util.Calendar.YEAR), cal.get(java.util.Calendar.MONTH), cal.get(java.util.Calendar.DAY_OF_MONTH))
            dp.datePicker.minDate = System.currentTimeMillis()
            dp.show()
        }
        btnEndDate?.setOnClickListener {
            val cal = java.util.Calendar.getInstance()
            val dp = android.app.DatePickerDialog(requireContext(), { _, y, m, d ->
                val c = java.util.Calendar.getInstance().apply { set(y, m, d, 0, 0, 0); set(java.util.Calendar.MILLISECOND, 0) }
                endDateMs = c.timeInMillis
                if (startDateMs == null) startDateMs = endDateMs
                if (endDateMs!! < startDateMs!!) endDateMs = startDateMs
                btnEndDate.text = dateFormat.format(java.util.Date(endDateMs!!))
                updateDailyUi()
            }, cal.get(java.util.Calendar.YEAR), cal.get(java.util.Calendar.MONTH), cal.get(java.util.Calendar.DAY_OF_MONTH))
            dp.datePicker.minDate = System.currentTimeMillis()
            dp.show()
        }

        // Buttons
        view.findViewById<Button?>(R.id.btnCancel)?.setOnClickListener { dismiss() }
        val startPayment: (View) -> Unit = {
            // Optional: create booking on backend; on failure proceed to PaymentActivity
            val bikeId = b.id
            val now = java.time.Instant.now()
            val startIso = if (isHourly) now.toString() else java.time.Instant.ofEpochMilli(startDateMs ?: System.currentTimeMillis()).toString()
            val endIso = if (isHourly) now.plusSeconds((selectedHours * 3600).toLong()).toString() else java.time.Instant.ofEpochMilli(endDateMs ?: (startDateMs ?: System.currentTimeMillis())).toString()
            val pricingMode = if (isHourly) "hourly" else "daily"
            val total = if (isHourly) b.price * selectedHours else b.price * 8 * kotlin.math.max(1, ((endDateMs ?: 0L) - (startDateMs ?: 0L)) / (24L*60*60*1000)).toInt()

            val userId = UserManager.getCurrentUser()?.id ?: "guest"
            val req = CreateBookingRequest(
                user_id = userId,
                bike_id = bikeId,
                start_time = startIso,
                end_time = endIso,
                pricing_mode = pricingMode,
                total_amount = total
            )

            // Optional loading state (removed as layout has no progress bar)

            // Debug logging
            android.util.Log.d("BOOKING_DEBUG", "🚀 Attempting to create booking...")
            android.util.Log.d("BOOKING_DEBUG", "📊 Request data: user_id=$userId, bike_id=$bikeId, amount=$total")
            android.util.Log.d("BOOKING_DEBUG", "🌐 API URL: ${ApiClient.apiService}")
            
            ApiClient.apiService.createBooking(req).enqueue(object : retrofit2.Callback<Map<String, Any>> {
                override fun onResponse(
                    call: retrofit2.Call<Map<String, Any>>, response: retrofit2.Response<Map<String, Any>>
                ) {
                    android.util.Log.d("BOOKING_DEBUG", "✅ Backend response: Code=${response.code()}")
                    android.util.Log.d("BOOKING_DEBUG", "✅ Response body: ${response.body()}")
                    if (response.isSuccessful) {
                        android.util.Log.d("BOOKING_DEBUG", "🎉 Booking posted to backend successfully!")
                    } else {
                        android.util.Log.e("BOOKING_DEBUG", "❌ Backend returned error: ${response.code()}")
                    }
                    saveLocalBooking(response.body())
                    proceedToPayment()
                }

                override fun onFailure(call: retrofit2.Call<Map<String, Any>>, t: Throwable) {
                    android.util.Log.e("BOOKING_DEBUG", "❌ Backend connection failed: ${t.message}")
                    android.util.Log.e("BOOKING_DEBUG", "📱 Saving booking locally only")
                    saveLocalBooking(null)
                    proceedToPayment()
                }

                fun proceedToPayment() {
                    // Hide loading state (no-op)
                    val intent = Intent(requireContext(), PaymentActivity::class.java)
                    intent.putExtra("bike", b)
                    if (isHourly) {
                        intent.putExtra("selectedHours", selectedHours)
                        intent.putExtra("isHourly", true)
                    } else {
                        val days = if (startDateMs != null && endDateMs != null && endDateMs!! >= startDateMs!!) {
                            val oneDay = 24L * 60 * 60 * 1000
                            ((endDateMs!! - startDateMs!!) / oneDay).toInt().coerceAtLeast(1)
                        } else 1
                        intent.putExtra("selectedDays", days)
                        intent.putExtra("isHourly", false)
                    }
                    startActivity(intent)
                    dismiss()
                }

                fun saveLocalBooking(apiResp: Map<String, Any>?) {
                    val dateFmt = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.getDefault())
                    val start = if (isHourly) java.util.Date() else java.util.Date(startDateMs ?: System.currentTimeMillis())
                    val end = if (isHourly) java.util.Date(System.currentTimeMillis() + selectedHours * 3600_000L) else java.util.Date(endDateMs ?: (startDateMs ?: System.currentTimeMillis()))
                    val apiId = try { (apiResp?.get("id") as? String) ?: (apiResp?.get("booking_id") as? String) } catch (_: Exception) { null }
                    val booking = Booking(
                        bikeName = b.name,
                        renterName = UserManager.getCurrentUserName().ifEmpty { "Guest" },
                        location = b.getFullAddress(),
                        startDate = dateFmt.format(start),
                        endDate = dateFmt.format(end),
                        pickupTime = if (isHourly) java.text.SimpleDateFormat("hh:mm a", java.util.Locale.getDefault()).format(start) else "",
                        dropoffTime = if (isHourly) java.text.SimpleDateFormat("hh:mm a", java.util.Locale.getDefault()).format(end) else "",
                        price = total,
                        imageRes = b.getBikeImageRes(),
                        status = "Active",
                        pickupMode = b.pickupMode,
                        lastKnownLocation = b.location,
                        bookingCode = (100000..999999).random().toString(),
                        apiId = apiId,
                        userName = UserManager.getCurrentUserName(),
                        mobileNumber = UserManager.getCurrentUser()?.phone ?: "",
                        email = UserManager.getCurrentUser()?.email ?: ""
                    )
                    BookingRepository.allBookings.add(0, booking)
                }
            })
        }
        view.findViewById<Button?>(R.id.btnBookNow)?.setOnClickListener(startPayment)
        view.findViewById<Button?>(R.id.btnPayment)?.setOnClickListener(startPayment)
    }

    companion object {
        private const val ARG_BIKE = "bike"
        fun newInstance(bike: Bike, extra: Bundle? = null): BookingDialogRedesignFragment {
            return BookingDialogRedesignFragment().apply {
                arguments = Bundle().apply { 
                    putParcelable(ARG_BIKE, bike)
                    extra?.let { putAll(it) }
                }
            }
        }
    }
}


