package com.example.bikerental

import android.app.Dialog
import android.content.Context
import android.content.SharedPreferences
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.DialogFragment
import com.google.android.material.dialog.MaterialAlertDialogBuilder

class RoleSwitchDialogFragment : DialogFragment() {
    private var currentRole: String = "user"
    private var targetRole: String = "admin"
    private lateinit var prefs: SharedPreferences

    companion object {
        fun newInstance(currentRole: String, targetRole: String): RoleSwitchDialogFragment {
            val fragment = RoleSwitchDialogFragment()
            fragment.currentRole = currentRole
            fragment.targetRole = targetRole
            return fragment
        }
    }

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        android.util.Log.d("RoleSwitchDialog", "Creating dialog for role switch: $currentRole -> $targetRole")
        
        prefs = requireContext().getSharedPreferences("metro_ride_prefs", Context.MODE_PRIVATE)
        
        val dialogView = LayoutInflater.from(context).inflate(R.layout.dialog_role_switch, null)
        
        val tvTitle = dialogView.findViewById<TextView>(R.id.tvDialogTitle)
        val tvSubtitle = dialogView.findViewById<TextView>(R.id.tvDialogSubtitle)
        val etEmail = dialogView.findViewById<EditText>(R.id.etEmail)
        val etPassword = dialogView.findViewById<EditText>(R.id.etPassword)
        val btnCancel = dialogView.findViewById<Button>(R.id.btnCancel)
        val btnSwitch = dialogView.findViewById<Button>(R.id.btnSwitch)
        
        // Set dialog content based on role switch
        val roleText = if (targetRole == "admin") "Owner" else "User"
        tvTitle.text = "Switch to $roleText Mode"
        tvSubtitle.text = "Please enter your credentials to switch to $roleText mode"
        
        // Update button text based on role
        btnSwitch.text = "Switch to $roleText Mode"
        
        // Pre-fill email with current user's email from UserManager
        val currentUserEmail = UserManager.getCurrentUserEmail()
        if (currentUserEmail.isNotEmpty()) {
            etEmail.setText(currentUserEmail)
        }
        
        btnCancel.setOnClickListener {
            // Notify ProfileFragment to revert the switch when cancelled
            (parentFragment as? ProfileFragment)?.onRoleSwitchFailed()
            dismiss()
        }
        
        btnSwitch.setOnClickListener {
            val email = etEmail.text.toString().trim()
            val password = etPassword.text.toString().trim()
            
            android.util.Log.d("RoleSwitchDialog", "Attempting role switch with email: $email")
            
            if (validateCredentials(email, password)) {
                // Switch role and set admin flag
                prefs.edit()
                    .putString("role", targetRole)
                    .putBoolean("is_admin", targetRole == "admin")
                    .apply()
                
                Toast.makeText(requireContext(), "Switched to $roleText Mode", Toast.LENGTH_SHORT).show()
                
                // Notify activity to update UI and navigate to appropriate fragment
                (activity as? MainActivity)?.updateNavigationForRole(targetRole, true)
                
                // Notify ProfileFragment to update switch state
                (parentFragment as? ProfileFragment)?.onRoleSwitched(targetRole)
                
                dismiss()
            } else {
                Toast.makeText(requireContext(), "Invalid credentials", Toast.LENGTH_SHORT).show()
                // Notify ProfileFragment to revert the switch on authentication failure
                (parentFragment as? ProfileFragment)?.onRoleSwitchFailed()
            }
        }
        
        return MaterialAlertDialogBuilder(requireContext())
            .setView(dialogView)
            .setCancelable(false)
            .create()
    }
    
    private fun validateCredentials(email: String, password: String): Boolean {
        if (email.isEmpty() || password.isEmpty()) {
            return false
        }
        
        // Use UserManager to validate credentials
        return UserManager.validateCredentials(email, password)
    }
} 