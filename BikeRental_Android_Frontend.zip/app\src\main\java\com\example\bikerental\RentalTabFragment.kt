package com.example.bikerental

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import android.widget.Toast
import java.util.Calendar

class RentalTabFragment : Fragment() {
    private lateinit var rentalAdapter: RentalAdapter
    private lateinit var allRentals: List<Rental>
    private var tabType: String = "current"

    companion object {
        private const val ARG_TAB_TYPE = "tab_type"
        
        fun newInstance(tabType: String): RentalTabFragment {
            val fragment = RentalTabFragment()
            val args = Bundle()
            args.putString(ARG_TAB_TYPE, tabType)
            fragment.arguments = args
            return fragment
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {
            tabType = it.getString(ARG_TAB_TYPE, "current")
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_rental_tab, container, false)
        
        // Sample rental data
        allRentals = createSampleRentals()
        
        val recyclerView = view.findViewById<RecyclerView>(R.id.rvRentals)
        recyclerView.layoutManager = LinearLayoutManager(requireContext())
        
        rentalAdapter = RentalAdapter(getFilteredRentals()) { rental ->
            handleRentalAction(rental)
        }
        recyclerView.adapter = rentalAdapter
        
        return view
    }

    private fun createSampleRentals(): List<Rental> {
        val calendar = Calendar.getInstance()
        
        return listOf(
            Rental(
                "1", "Marina Cruiser", "Standard Bike",
                calendar.time, null, 2, 24.0,
                RentalStatus.ACTIVE, "Marina Beach"
            ),
            Rental(
                "2", "E-Bike Pro", "Electric Bike",
                calendar.apply { add(Calendar.DAY_OF_MONTH, -1) }.time,
                calendar.apply { add(Calendar.HOUR, 2) }.time, 3, 54.0,
                RentalStatus.COMPLETED, "T. Nagar"
            ),
            Rental(
                "3", "Scooty Zip", "Scooter",
                calendar.apply { add(Calendar.DAY_OF_MONTH, 1) }.time,
                null, 1, 10.0,
                RentalStatus.UPCOMING, "Velachery"
            ),
            Rental(
                "4", "Classic Hero", "Standard Bike",
                calendar.apply { add(Calendar.DAY_OF_MONTH, -3) }.time,
                calendar.apply { add(Calendar.HOUR, 1) }.time, 1, 11.0,
                RentalStatus.COMPLETED, "Adyar"
            ),
            Rental(
                "5", "GreenGo", "Electric Bike",
                calendar.apply { add(Calendar.DAY_OF_MONTH, -5) }.time,
                null, 2, 32.0,
                RentalStatus.CANCELLED, "Guindy"
            )
        )
    }

    private fun getFilteredRentals(): List<Rental> {
        return when (tabType) {
            "current" -> allRentals.filter { 
                it.status == RentalStatus.ACTIVE || it.status == RentalStatus.UPCOMING 
            }
            "past" -> allRentals.filter { 
                it.status == RentalStatus.COMPLETED || it.status == RentalStatus.CANCELLED 
            }
            else -> allRentals
        }
    }

    private fun handleRentalAction(rental: Rental) {
        when (rental.status) {
            RentalStatus.ACTIVE -> {
                Toast.makeText(requireContext(), "Ending ride for ${rental.bikeName}", Toast.LENGTH_SHORT).show()
                // Here you would implement the logic to end the ride
            }
            RentalStatus.COMPLETED -> {
                Toast.makeText(requireContext(), "Renting ${rental.bikeName} again", Toast.LENGTH_SHORT).show()
                // Here you would implement the logic to rent the same bike again
            }
            RentalStatus.UPCOMING -> {
                Toast.makeText(requireContext(), "Cancelling rental for ${rental.bikeName}", Toast.LENGTH_SHORT).show()
                // Here you would implement the logic to cancel the upcoming rental
            }
            else -> {}
        }
    }
} 