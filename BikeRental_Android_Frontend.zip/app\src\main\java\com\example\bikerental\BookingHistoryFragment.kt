package com.example.bikerental

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class BookingHistoryFragment : Fragment() {
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_booking_history, container, false)
        val recyclerView = view.findViewById<RecyclerView>(R.id.rvBookingHistory)
        recyclerView.layoutManager = LinearLayoutManager(requireContext())
        recyclerView.adapter = BookingHistoryAdapter(getMockBookings())
        return view
    }

    private fun getMockBookings(): List<Booking> = listOf(
        Booking(
            bikeName = "Marina Cruiser",
            renterName = "Alice",
            location = "Marina Beach",
            startDate = "2024-06-01",
            endDate = "2024-06-03",
            price = 192,
            imageRes = R.drawable.unicorn_standard_bike, // Use a valid drawable
            status = "Completed"
        ),
        Booking(
            bikeName = "E-Bike Pro",
            renterName = "Bob",
            location = "T. Nagar",
            startDate = "2024-06-02",
            endDate = "2024-06-02",
            price = 60,
            imageRes = R.drawable.unicorn_standard_bike, // Use a valid drawable
            status = "Ongoing"
        )
    )

    inner class BookingHistoryAdapter(private val items: List<Booking>) : RecyclerView.Adapter<BookingHistoryAdapter.ViewHolder>() {
        inner class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
            val tvBikeName: TextView = view.findViewById(R.id.tvBikeName)
            val tvRenterName: TextView = view.findViewById(R.id.tvRenterName)
            val tvDuration: TextView = view.findViewById(R.id.tvDuration)
            val tvPrice: TextView = view.findViewById(R.id.tvPrice)
            val tvPickupTime: TextView = view.findViewById(R.id.tvPickupTime)
            val tvDropTime: TextView = view.findViewById(R.id.tvDropTime)
            val tvStatus: TextView = view.findViewById(R.id.tvStatus)
        }
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
            val v = LayoutInflater.from(parent.context).inflate(R.layout.item_booking_history, parent, false)
            return ViewHolder(v)
        }
        override fun onBindViewHolder(holder: ViewHolder, position: Int) {
            val item = items[position]
            holder.tvBikeName.text = item.bikeName
            holder.tvRenterName.text = "Renter: ${item.renterName}"
            holder.tvDuration.text = "From: ${item.startDate} To: ${item.endDate}"
            holder.tvPrice.text = "₹${item.price}"
            holder.tvPickupTime.text = "Location: ${item.location}"
            holder.tvDropTime.text = "Status: ${item.status}"
            holder.tvStatus.text = item.status
        }
        override fun getItemCount() = items.size
    }
} 