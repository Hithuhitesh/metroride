package com.example.bikerental

import android.app.Dialog
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.widget.ImageView
import android.widget.TextView
import androidx.fragment.app.DialogFragment
import com.google.android.material.button.MaterialButton

class BookingDialogV2 : DialogFragment() {

    private var bike: Bike? = null
    private var startMs: Long = 0L
    private var endMs: Long = 0L
    private var isHourly: Boolean = true

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        retainInstance = true
        arguments?.let { args ->
            bike = args.getParcelable("bike")
            startMs = args.getLong("startMs")
            endMs = args.getLong("endMs")
            isHourly = args.getBoolean("isHourly", true)
        }
    }

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        val v = LayoutInflater.from(requireContext()).inflate(R.layout.dialog_booking_v2, null, false)
        val tvBikeName = v.findViewById<TextView>(R.id.tvBikeName)
        val ivBike = v.findViewById<ImageView>(R.id.ivBike)
        val tvTimeWindow = v.findViewById<TextView>(R.id.tvTimeWindow)
        val ivMapPreview = v.findViewById<ImageView>(R.id.ivMapPreview)
        val btnCancel = v.findViewById<MaterialButton>(R.id.btnCancel)
        val btnConfirm = v.findViewById<MaterialButton>(R.id.btnConfirm)

        bike?.let { b ->
            tvBikeName.text = b.name
            ivBike.setImageResource(b.getBikeImageRes())
            tvTimeWindow.text = formatWindowReadable(startMs, endMs, isHourly)
            ivMapPreview.setOnClickListener { openMapWithLocation(requireContext(), b.location) }
        }

        btnCancel.setOnClickListener { dismissAllowingStateLoss() }
        btnConfirm.setOnClickListener {
            val b = bike ?: return@setOnClickListener
            // Save a lightweight booking into repository for demo
            val price = if (isHourly) b.price else b.price * 8
            val dateFormatDb = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.getDefault())
            val booking = Booking(
                bikeName = b.name,
                renterName = "User",
                location = b.location,
                startDate = dateFormatDb.format(java.util.Date(startMs)),
                endDate = dateFormatDb.format(java.util.Date(endMs)),
                price = price,
                imageRes = b.imageRes,
                status = "Active",
                pickupMode = b.pickupMode,
                lastKnownLocation = b.location,
                bookingCode = (100000..999999).random().toString()
            )
            BookingRepository.allBookings.add(0, booking)
            startActivity(Intent(requireContext(), PaymentActivity::class.java).apply {
                putExtra("bikeName", b.name)
                putExtra("imageRes", b.getBikeImageRes())
                putExtra("startMs", startMs)
                putExtra("endMs", endMs)
                putExtra("isHourly", isHourly)
                putExtra("hourlyRate", b.price.toDouble())
                putExtra("locationLabel", b.location)
            })
            dismissAllowingStateLoss()
        }

        return androidx.appcompat.app.AlertDialog.Builder(requireContext())
            .setView(v)
            .create()
    }

    private fun openMapWithLocation(context: Context, label: String) {
        val uri = Uri.parse("geo:0,0?q=" + Uri.encode(label))
        val intent = Intent(Intent.ACTION_VIEW, uri)
        intent.setPackage("com.google.android.apps.maps")
        if (intent.resolveActivity(context.packageManager) != null) context.startActivity(intent)
    }

    companion object {
        fun newInstance(bike: Bike, startMs: Long, endMs: Long, isHourly: Boolean): BookingDialogV2 {
            val f = BookingDialogV2()
            val args = Bundle()
            args.putParcelable("bike", bike)
            args.putLong("startMs", startMs)
            args.putLong("endMs", endMs)
            args.putBoolean("isHourly", isHourly)
            f.arguments = args
            return f
        }
    }
}

fun formatWindowReadable(startMs: Long, endMs: Long, isHourly: Boolean): String {
    val zone = java.time.ZoneId.systemDefault()
    val start = java.time.Instant.ofEpochMilli(startMs).atZone(zone)
    val end = java.time.Instant.ofEpochMilli(endMs).atZone(zone)
    return if (isHourly) {
        "${start.toLocalDate()} ${start.toLocalTime()} → ${end.toLocalDate()} ${end.toLocalTime()}"
    } else {
        "${start.toLocalDate()} → ${end.toLocalDate()}"
    }
}










