package com.example.bikerental

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView

class RentalsFragmentV2 : Fragment() {

    private lateinit var rv: RecyclerView
    private val adapter = BookingAdapter()

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater.inflate(R.layout.fragment_rentals_v2, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        rv = view.findViewById(R.id.rvRentalsV2)
        rv.layoutManager = LinearLayoutManager(requireContext())
        rv.adapter = adapter
        adapter.submitList(loadBookings(requireContext()))
    }

    private fun loadBookings(context: Context): List<Booking> {
        // Use in-memory repository already used in app
        return BookingRepository.allBookings.toList()
    }

    private class BookingAdapter : ListAdapter<Booking, VH>(DIFF) {
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
            val v = LayoutInflater.from(parent.context).inflate(R.layout.item_booking_v2, parent, false)
            return VH(v)
        }
        override fun onBindViewHolder(holder: VH, position: Int) {
            holder.bind(getItem(position))
        }
        private object DIFF : DiffUtil.ItemCallback<Booking>() {
            override fun areItemsTheSame(oldItem: Booking, newItem: Booking) =
                oldItem.bikeName == newItem.bikeName && oldItem.startDate == newItem.startDate
            override fun areContentsTheSame(oldItem: Booking, newItem: Booking) = oldItem == newItem
        }
    }

    private class VH(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val ivBike = itemView.findViewById<ImageView>(R.id.ivBike)
        private val tvName = itemView.findViewById<TextView>(R.id.tvBikeName)
        private val tvWindow = itemView.findViewById<TextView>(R.id.tvWindow)
        private val tvDetails = itemView.findViewById<TextView>(R.id.tvDetails)
        private val ivMap = itemView.findViewById<ImageView>(R.id.ivMapThumb)

        fun bind(b: Booking) {
            ivBike.setImageResource(b.imageRes)
            tvName.text = b.bikeName
            tvWindow.text = "${b.startDate} → ${b.endDate}"
            val bike = BikeRepository.allBikes.find { it.name == b.bikeName }
            tvDetails.text = buildDetailsLine(bike)
            ivMap.setOnClickListener { openMap(itemView.context, b.location) }
            itemView.setOnClickListener {
                android.widget.Toast.makeText(itemView.context, "Booking: ${b.bikeName}", android.widget.Toast.LENGTH_SHORT).show()
            }
        }

        private fun buildDetailsLine(bike: Bike?): String {
            if (bike == null) return ""
            val parts = mutableListOf<String>()
            parts.add(bike.type)
            bike.engineCc?.let { parts.add("${it}cc") }
            bike.batteryCapacityKwh?.let { parts.add("${it}kWh") }
            bike.rangeKm?.let { parts.add("${it}km range") }
            bike.mileageKmpl?.let { parts.add("${it} kmpl") }
            parts.add("Deposit: ${bike.getFormattedDeposit()}")
            return parts.joinToString(" • ")
        }

        private fun openMap(context: Context, label: String) {
            val uri = Uri.parse("geo:0,0?q=" + Uri.encode(label))
            val intent = Intent(Intent.ACTION_VIEW, uri).setPackage("com.google.android.apps.maps")
            if (intent.resolveActivity(context.packageManager) != null) context.startActivity(intent)
        }
    }
}










