package com.example.bikerental

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import android.widget.LinearLayout
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager2.adapter.FragmentStateAdapter
import androidx.viewpager2.widget.ViewPager2
import com.google.android.material.tabs.TabLayout
import com.google.android.material.tabs.TabLayoutMediator
import java.text.SimpleDateFormat
import java.text.ParseException
import java.util.Locale
import android.widget.RatingBar
import android.widget.EditText
import java.util.Date
import android.content.Context

class RentalsFragment : Fragment() {
    private lateinit var currentBookingSection: LinearLayout
    private lateinit var ivCurrentBike: ImageView
    private lateinit var tvCurrentBikeName: TextView
    private lateinit var tvCurrentTimeWindow: TextView
    private lateinit var tvCurrentStatus: TextView
    private lateinit var btnCancelBooking: Button
    private lateinit var rvPastBookings: RecyclerView
    private lateinit var pastBookingsAdapter: PastBookingsAdapter
    
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_rentals, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        
        initializeViews(view)
        setupRecyclerView()
        updateCurrentBooking()
        updatePastBookings()
        fetchBookingsFromApi()
    }
    
    private fun initializeViews(view: View) {
        currentBookingSection = view.findViewById(R.id.currentBookingSection)
        ivCurrentBike = view.findViewById(R.id.ivCurrentBike)
        tvCurrentBikeName = view.findViewById(R.id.tvCurrentBikeName)
        tvCurrentTimeWindow = view.findViewById(R.id.tvCurrentTimeWindow)
        tvCurrentStatus = view.findViewById(R.id.tvCurrentStatus)
        btnCancelBooking = view.findViewById(R.id.btnCancelBooking)
        val btnEndBooking = view.findViewById<Button?>(R.id.btnEndBooking)
        rvPastBookings = view.findViewById(R.id.rvPastBookings)
        
        btnCancelBooking.setOnClickListener { cancelCurrentBooking() }
        btnEndBooking?.setOnClickListener {
            val currentBooking = BookingRepository.allBookings.find { it.status == "Active" }
            currentBooking?.let { booking ->
                // Mark as completed and refresh lists
                val idx = BookingRepository.allBookings.indexOfFirst { it.bikeName == booking.bikeName && it.startDate == booking.startDate }
                if (idx != -1) {
                    BookingRepository.allBookings[idx] = BookingRepository.allBookings[idx].copy(status = "Completed")
                }
                updateCurrentBooking()
                updatePastBookings()
                Toast.makeText(requireContext(), getString(R.string.end_ride_success), Toast.LENGTH_SHORT).show()
            }
        }
    }
    
    private fun setupRecyclerView() {
        rvPastBookings.layoutManager = androidx.recyclerview.widget.LinearLayoutManager(requireContext())
        pastBookingsAdapter = PastBookingsAdapter(emptyList())
        rvPastBookings.adapter = pastBookingsAdapter
    }
    
    private fun updateCurrentBooking() {
        val currentBooking = BookingRepository.allBookings.find { it.status == "Active" }
        
        if (currentBooking != null) {
            currentBookingSection.visibility = View.VISIBLE
            val bike = BikeRepository.allBikes.find { it.name == currentBooking.bikeName }?.withDefaultsForKnownBike()
            if (bike != null) {
                ivCurrentBike.setImageResource(bike.getBikeImageRes())
            } else {
                ivCurrentBike.setImageResource(currentBooking.imageRes)
            }
            tvCurrentBikeName.text = currentBooking.bikeName
            val timeWindow = "${currentBooking.startDate} ${currentBooking.pickupTime} - ${currentBooking.endDate} ${currentBooking.dropoffTime}"
            tvCurrentTimeWindow.text = timeWindow
            // Open detailed booking card when tapping the current booking section
            currentBookingSection.setOnClickListener {
                showBookingDetails(currentBooking)
            }
            tvCurrentTimeWindow.setOnClickListener { showBookingDetails(currentBooking) }
            tvCurrentStatus.text = currentBooking.status
            // Owner inline
            view?.findViewById<TextView>(R.id.tvCurrentOwner)?.text = if (!bike?.ownerPhone.isNullOrEmpty()) "Owner: ${bike?.ownerPhone}" else "Owner: Not provided"
        } else {
            currentBookingSection.visibility = View.GONE
        }
    }

    private fun showBookingDetails(booking: Booking) {
        // Show a dialog styled like the payment breakdown but read-only
        val ctx = requireContext()
        val v = LayoutInflater.from(ctx).inflate(R.layout.activity_payment, null, false)
        // Bind essentials
        v.findViewById<ImageView>(R.id.ivBikeImage)?.setImageResource(booking.imageRes)
        v.findViewById<TextView>(R.id.tvBikeName)?.text = booking.bikeName
        val bikeRaw = BikeRepository.allBikes.find { it.name == booking.bikeName }
        val bike = bikeRaw?.withDefaultsForKnownBike()
        v.findViewById<TextView>(R.id.tvBikeType)?.text = bike?.type ?: "Bike"
        v.findViewById<TextView>(R.id.tvBikeLocation)?.text = booking.location
        v.findViewById<TextView>(R.id.tvBookingDate)?.text = "Date: ${booking.startDate}"
        v.findViewById<TextView>(R.id.tvBookingTime)?.text = "Time: ${booking.pickupTime} - ${booking.dropoffTime}"
        v.findViewById<TextView>(R.id.tvBookingDuration)?.text = "Duration: ${booking.pickupTime} - ${booking.dropoffTime}"
        v.findViewById<TextView>(R.id.tvBasePrice)?.text = "₹${booking.price}"
        v.findViewById<TextView>(R.id.tvDuration)?.text = "—"
        v.findViewById<TextView>(R.id.tvTotalCost)?.text = "₹${booking.price}"
        // Populate specs block similarly to payment page
        bike?.let { b ->
            v.findViewById<TextView>(R.id.tvSpecModel)?.text = "Model: ${b.model.ifEmpty { b.name }}"
            v.findViewById<TextView>(R.id.tvSpecYear)?.text = if (b.year>0) "Year: ${b.year}" else "Year: -"
            val fuel = if (b.fuelType.isNotEmpty()) b.fuelType else if (b.batteryCapacityKwh != null) "Electric" else "-"
            v.findViewById<TextView>(R.id.tvSpecFuel)?.text = "Fuel: ${fuel}"
            v.findViewById<TextView>(R.id.tvSpecEngBat)?.text = listOfNotNull(
                b.engineCc?.let { "Engine: ${it}cc ${b.engineType}".trim() },
                b.batteryCapacityKwh?.let { "Battery: ${it}kWh" }
            ).joinToString("  •  ")
            v.findViewById<TextView>(R.id.tvSpecPowerTorque)?.text = listOfNotNull(
                b.powerHp?.let { "Power: ${"" + it}hp" },
                b.torqueNm?.let { "Torque: ${"" + it}Nm" }
            ).joinToString("  •  ")
            v.findViewById<TextView>(R.id.tvSpecRangeMileage)?.text = listOfNotNull(
                b.rangeKm?.let { "Range: ${it} km" },
                b.mileageKmpl?.let { "Mileage: ${it} kmpl" }
            ).joinToString("  •  ")
            v.findViewById<TextView>(R.id.tvSpecDeposit)?.text = "Deposit: ${b.getFormattedDeposit()}"
            val safety = mutableListOf<String>().apply {
                if (b.helmetProvided) add("Helmet Provided")
                if (b.insuranceIncluded) add("Insurance Included")
            }
            v.findViewById<TextView>(R.id.tvSpecSafety)?.text = safety.joinToString(" / ")
        }
        // Hide the actionable payment button and payment options in this dialog
        v.findViewById<Button>(R.id.btnCompleteBooking)?.visibility = View.GONE
        val rg = v.findViewById<android.widget.RadioGroup?>(R.id.rgPaymentMethod)
        rg?.visibility = View.GONE
        v.findViewById<android.widget.ImageView?>(R.id.ivMapPreview)?.setOnClickListener { openMap(booking.location) }
        androidx.appcompat.app.AlertDialog.Builder(ctx)
            .setView(v)
            .setPositiveButton("Close") { d, _ -> d.dismiss() }
            .show()
    }
    
    private fun updatePastBookings() {
        val pastBookings = BookingRepository.allBookings.filter { it.status == "Completed" }
        pastBookingsAdapter.updateList(pastBookings)
    }

    private fun fetchBookingsFromApi() {
        ApiClient.apiService.getBookings().enqueue(object : retrofit2.Callback<List<ApiBooking>> {
            override fun onResponse(
                call: retrofit2.Call<List<ApiBooking>>, response: retrofit2.Response<List<ApiBooking>>
            ) {
                val items = response.body() ?: return
                if (items.isEmpty()) return
                val mapped = items.mapNotNull { r ->
                    val bike = BikeRepository.allBikes.firstOrNull { it.id == (r.bike_id ?: "") || it.name == (r.bike_id ?: "") }?.withDefaultsForKnownBike()
                    val dfIn = java.time.format.DateTimeFormatter.ISO_INSTANT
                    val dfOut = java.time.format.DateTimeFormatter.ofPattern("yyyy-MM-dd")
                    val startDate = try { java.time.Instant.parse(r.start_time).atZone(java.time.ZoneId.systemDefault()).toLocalDate().format(dfOut) } catch (_: Exception) { "" }
                    val endDate = try { java.time.Instant.parse(r.end_time).atZone(java.time.ZoneId.systemDefault()).toLocalDate().format(dfOut) } catch (_: Exception) { startDate }
                    Booking(
                        bikeName = bike?.name ?: (r.bike_id ?: "Bike"),
                        renterName = UserManager.getCurrentUserName().ifEmpty { "Guest" },
                        location = bike?.getFullAddress() ?: "Chennai",
                        startDate = startDate,
                        endDate = endDate,
                        pickupTime = "",
                        dropoffTime = "",
                        price = r.total_amount ?: (bike?.price ?: 0),
                        imageRes = (bike?.getBikeImageRes() ?: R.drawable.unicorn_standard_bike),
                        status = r.status ?: "Active",
                        pickupMode = bike?.pickupMode ?: "manual",
                        lastKnownLocation = bike?.location ?: "Chennai",
                        bookingCode = (100000..999999).random().toString(),
                        userName = UserManager.getCurrentUserName(),
                        mobileNumber = UserManager.getCurrentUser()?.phone ?: "",
                        email = UserManager.getCurrentUser()?.email ?: ""
                    )
                }
                // Merge without duplicating existing local entries
                val existingKeys = BookingRepository.allBookings.map { it.bikeName + it.startDate + it.endDate }.toSet()
                val newOnes = mapped.filter { (it.bikeName + it.startDate + it.endDate) !in existingKeys }
                if (newOnes.isNotEmpty()) {
                    BookingRepository.allBookings.addAll(0, newOnes)
                    updateCurrentBooking()
                    updatePastBookings()
                }
            }

            override fun onFailure(call: retrofit2.Call<List<ApiBooking>>, t: Throwable) {
                // ignore - offline mode shows local-only
            }
        })
    }

    private fun openMap(label: String) {
        val uri = android.net.Uri.parse("geo:0,0?q=" + android.net.Uri.encode(label))
        val intent = android.content.Intent(android.content.Intent.ACTION_VIEW, uri)
            .setPackage("com.google.android.apps.maps")
        if (intent.resolveActivity(requireContext().packageManager) != null) startActivity(intent)
    }
    
    private fun cancelCurrentBooking() {
        val currentBooking = BookingRepository.allBookings.find { it.status == "Active" }
        currentBooking?.let { booking ->
            AlertDialog.Builder(requireContext())
                .setTitle("Cancel Booking")
                .setMessage("Are you sure you want to cancel this booking?")
                .setPositiveButton("Yes") { dialog, _ ->
                    // Try cancel on backend if we have an id
                    val apiId = booking.apiId
                    if (!apiId.isNullOrEmpty()) {
                        ApiClient.apiService.cancelBooking(apiId, mapOf("reason" to "user_cancelled")).enqueue(object : retrofit2.Callback<Map<String, Any>> {
                            override fun onResponse(
                                call: retrofit2.Call<Map<String, Any>>, response: retrofit2.Response<Map<String, Any>>
                            ) { finalizeLocalCancel(booking, dialog) }
                            override fun onFailure(call: retrofit2.Call<Map<String, Any>>, t: Throwable) { finalizeLocalCancel(booking, dialog) }
                        })
                    } else {
                        finalizeLocalCancel(booking, dialog)
                    }
                }
                .setNegativeButton("No") { dialog, _ ->
                    dialog.dismiss()
                }
                .show()
        }
    }

    private fun finalizeLocalCancel(booking: Booking, dialog: android.content.DialogInterface) {
        val index = BookingRepository.allBookings.indexOfFirst {
            it.bikeName == booking.bikeName && it.startDate == booking.startDate
        }
        if (index != -1) {
            BookingRepository.allBookings[index] = booking.copy(status = "Cancelled")
        }
        updateCurrentBooking()
        updatePastBookings()
        Toast.makeText(requireContext(), "Booking cancelled", Toast.LENGTH_SHORT).show()
        dialog.dismiss()
    }
}

// Adapter for past bookings
class PastBookingsAdapter(
    private var bookings: List<Booking>
) : RecyclerView.Adapter<PastBookingsAdapter.BookingViewHolder>() {
    
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): BookingViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_booking_card, parent, false)
        return BookingViewHolder(view)
    }
    
    override fun onBindViewHolder(holder: BookingViewHolder, position: Int) {
        holder.bind(bookings[position])
    }
    
    override fun getItemCount() = bookings.size
    
    fun updateList(newList: List<Booking>) {
        bookings = newList
        notifyDataSetChanged()
    }
    
    inner class BookingViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        fun bind(booking: Booking) {
            itemView.findViewById<TextView>(R.id.tvBookingBikeName).text = booking.bikeName
            itemView.findViewById<TextView>(R.id.tvBookingLocation).text = booking.location
            // Load image and enrich specs for display
            val bike = BikeRepository.allBikes.find { it.name == booking.bikeName }?.withDefaultsForKnownBike()
            val iv = itemView.findViewById<ImageView>(R.id.ivBookingBike)
            if (bike != null) {
                iv.setImageResource(bike.getBikeImageRes())
            } else {
                iv.setImageResource(booking.imageRes)
            }
            itemView.findViewById<TextView>(R.id.tvBookingDates).text = "${booking.startDate} - ${booking.endDate}"
            itemView.findViewById<TextView>(R.id.tvBookingStatus).text = booking.status
            itemView.findViewById<TextView>(R.id.tvBookingPrice).text = "₹${booking.price}"
            // Owner details in details section
            val owner = if (!bike?.ownerPhone.isNullOrEmpty()) "Owner: ${bike?.ownerPhone}" else "Owner: Not provided"
            itemView.findViewById<TextView>(R.id.tvDetailsRenter).text = owner
            itemView.findViewById<TextView?>(R.id.tvBookingOwner)?.text = owner

            // Owner call/message buttons
            val phone = bike?.ownerPhone ?: ""
            itemView.findViewById<Button?>(R.id.btnCallOwner)?.setOnClickListener {
                if (phone.isNotEmpty()) {
                    val dial = android.content.Intent(android.content.Intent.ACTION_DIAL, android.net.Uri.parse("tel:${phone}"))
                    itemView.context.startActivity(dial)
                } else {
                    android.widget.Toast.makeText(itemView.context, "Owner number not provided", android.widget.Toast.LENGTH_SHORT).show()
                }
            }
            itemView.findViewById<Button?>(R.id.btnMessageOwner)?.setOnClickListener {
                if (phone.isNotEmpty()) {
                    val sms = android.content.Intent(android.content.Intent.ACTION_SENDTO, android.net.Uri.parse("smsto:${phone}"))
                    sms.putExtra("sms_body", "Hi, regarding my booking for ${booking.bikeName}.")
                    itemView.context.startActivity(sms)
                } else {
                    android.widget.Toast.makeText(itemView.context, "Owner number not provided", android.widget.Toast.LENGTH_SHORT).show()
                }
            }

            // Enable cancel/end buttons for Active bookings
            val btnCancel = itemView.findViewById<Button?>(R.id.btnCancelBooking)
            val btnEnd = itemView.findViewById<Button?>(R.id.btnEndRide)
            val isActive = booking.status == "Active"
            btnCancel?.visibility = if (isActive) View.VISIBLE else View.GONE
            btnEnd?.visibility = if (isActive) View.VISIBLE else View.GONE
            btnCancel?.setOnClickListener {
                androidx.appcompat.app.AlertDialog.Builder(itemView.context)
                    .setTitle("Cancel Booking")
                    .setMessage("Are you sure you want to cancel this booking?")
                    .setPositiveButton("Yes") { d, _ ->
                        BookingRepository.allBookings.removeIf {
                            it.bikeName == booking.bikeName && it.startDate == booking.startDate && it.endDate == booking.endDate
                        }
                        android.widget.Toast.makeText(itemView.context, "Booking cancelled", android.widget.Toast.LENGTH_SHORT).show()
                        (itemView.context as? androidx.fragment.app.FragmentActivity)?.supportFragmentManager?.fragments?.forEach { (it as? BookingListFragment)?.updateBookings() }
                        d.dismiss()
                    }
                    .setNegativeButton("No") { d, _ -> d.dismiss() }
                    .show()
            }
            btnEnd?.setOnClickListener {
                val idx = BookingRepository.allBookings.indexOfFirst { it.bikeName == booking.bikeName && it.startDate == booking.startDate && it.endDate == booking.endDate }
                if (idx != -1) {
                    BookingRepository.allBookings[idx] = BookingRepository.allBookings[idx].copy(status = "Completed")
                    android.widget.Toast.makeText(itemView.context, itemView.context.getString(R.string.end_ride_success), android.widget.Toast.LENGTH_SHORT).show()
                    (itemView.context as? androidx.fragment.app.FragmentActivity)?.supportFragmentManager?.fragments?.forEach { (it as? BookingListFragment)?.updateBookings() }
                }
            }
        }
    }
}

// Fragment to show booking list
class BookingListFragment : Fragment() {
    private var isCurrent: Boolean = true
    private val dateFormatIn = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
    private val dateFormatOut = SimpleDateFormat("dd MMM yyyy", Locale.getDefault())
    private lateinit var recyclerView: RecyclerView
    private lateinit var emptyState: TextView
    private lateinit var bookingAdapter: BookingAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        isCurrent = arguments?.getBoolean(ARG_IS_CURRENT) ?: true
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_booking_list, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        recyclerView = view.findViewById(R.id.rvBookings)
        emptyState = view.findViewById(R.id.tvEmptyBookings)
        recyclerView.layoutManager = LinearLayoutManager(requireContext())
        updateBookings()
    }

    fun updateBookings() {
        val bookings = if (isCurrent) BookingRepository.allBookings.filter { it.status == "Active" } else BookingRepository.allBookings.filter { it.status == "Completed" }
        bookingAdapter = BookingAdapter(bookings, dateFormatIn, dateFormatOut, ::onBookingReturned)
        recyclerView.adapter = bookingAdapter
        emptyState?.visibility = if (bookings.isEmpty()) View.VISIBLE else View.GONE
    }

    private fun onBookingReturned(booking: Booking) {
        // Mark as completed
        val idx = BookingRepository.allBookings.indexOfFirst { it.bikeName == booking.bikeName && it.startDate == booking.startDate && it.endDate == booking.endDate }
        if (idx != -1) {
            BookingRepository.allBookings[idx] = BookingRepository.allBookings[idx].copy(status = "Completed")
        }
        // Notify admin/owner (mock)
        val isLate = try {
            val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
            val endDate = sdf.parse(booking.endDate)
            val now = java.util.Date()
            endDate != null && now.after(endDate)
        } catch (e: Exception) { false }
        val msg = if (isLate) {
            "Bike '${booking.bikeName}' was returned late! Admin/owner notified."
        } else {
            "Bike '${booking.bikeName}' was returned. Admin/owner notified."
        }
        AlertDialog.Builder(requireContext())
            .setTitle("Admin/Owner Notification")
            .setMessage(msg)
            .setPositiveButton("OK") { d, _ -> d.dismiss() }
            .show()
        // Refresh list
        updateBookings()
    }

    companion object {
        private const val ARG_IS_CURRENT = "is_current"
        fun newInstance(isCurrent: Boolean): BookingListFragment {
            val fragment = BookingListFragment()
            val args = Bundle()
            args.putBoolean(ARG_IS_CURRENT, isCurrent)
            fragment.arguments = args
            return fragment
        }
    }
}

// Booking data model
// (Removed duplicate Booking data class, now using Booking from Booking.kt)

// Add a simple in-memory review store
private val bookingReviews = mutableMapOf<String, Pair<Float, String>>()

// Shared in-memory booking list for demo
// private val allBookings = mutableListOf(
//     Booking("Marina Cruiser", "Marina Beach", "2024-07-10", "2024-07-12", 240, R.drawable.ic_launcher_foreground, "Active", "manual", "Guindy, Chennai"),
//     Booking("E-Bike Pro", "T. Nagar", "2024-07-13", "2024-07-15", 360, R.drawable.ic_launcher_foreground, "Active", "smart_lock", "T. Nagar, Chennai"),
//     Booking("Scooty Zip", "Velachery", "2024-07-16", "2024-07-18", 180, R.drawable.ic_launcher_foreground, "Active", "station", "Velachery, Chennai"),
//     Booking("Classic Hero", "Adyar", "2024-06-01", "2024-06-03", 220, R.drawable.ic_launcher_foreground, "Completed", "manual", "Adyar, Chennai"),
//     Booking("Scooty Zip", "Velachery", "2024-05-20", "2024-05-21", 110, R.drawable.ic_launcher_foreground, "Completed", "station", "Velachery, Chennai")
// )

// RecyclerView Adapter
class BookingAdapter(
    private val bookings: List<Booking>,
    private val dateFormatIn: SimpleDateFormat,
    private val dateFormatOut: SimpleDateFormat,
    private val onBookingReturned: (Booking) -> Unit
) : RecyclerView.Adapter<BookingAdapter.BookingViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): BookingViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_booking_card, parent, false)
        return BookingViewHolder(view, dateFormatIn, dateFormatOut, onBookingReturned)
    }

    override fun onBindViewHolder(holder: BookingViewHolder, position: Int) {
        holder.bind(bookings[position])
    }

    override fun getItemCount(): Int = bookings.size

    class BookingViewHolder(
        itemView: View,
        private val dateFormatIn: SimpleDateFormat,
        private val dateFormatOut: SimpleDateFormat,
        private val onBookingReturned: (Booking) -> Unit
    ) : RecyclerView.ViewHolder(itemView) {

        fun bind(booking: Booking) {
            val context = itemView.context
            val prefs = context.getSharedPreferences("metro_ride_prefs", Context.MODE_PRIVATE)
            val role = prefs.getString("role", "user")

            itemView.findViewById<TextView>(R.id.tvBookingBikeName).text = booking.bikeName
            itemView.findViewById<TextView>(R.id.tvBookingLocation).text = booking.location

            val dateStr = try {
                val start = dateFormatIn.parse(booking.startDate)
                val end = dateFormatIn.parse(booking.endDate)
                if (start != null && end != null) {
                    "${dateFormatOut.format(start)} - ${dateFormatOut.format(end)}"
                } else {
                    "${booking.startDate} - ${booking.endDate}"
                }
            } catch (e: ParseException) {
                "${booking.startDate} - ${booking.endDate}"
            }

            itemView.findViewById<TextView>(R.id.tvBookingDates).text = dateStr

            val statusView = itemView.findViewById<TextView>(R.id.tvBookingStatus)
            statusView.text = booking.status
            statusView.setTextColor(if (booking.status == "Active") 0xFF4CAF50.toInt() else 0xFF888888.toInt())

            itemView.findViewById<TextView>(R.id.tvBookingPrice).text = "₹${booking.price}"
            itemView.findViewById<ImageView>(R.id.ivBookingBike).setImageResource(booking.imageRes)

            // Set booking code in main card
            // Booking code removed from card UI

            // Set up details section
            setupDetailsSection(booking)

            val btnCancel = itemView.findViewById<Button>(R.id.btnCancelBooking)
            val btnEndRide = itemView.findViewById<Button>(R.id.btnEndRide)
            // Report theft removed per request

            // Show actions for Active bookings without requiring expand
            if (role == "user") {
                btnCancel?.visibility = if (booking.status == "Active") View.VISIBLE else View.GONE
                btnEndRide?.visibility = if (booking.status == "Active") View.VISIBLE else View.GONE
            } else {
                btnCancel?.visibility = View.GONE
                btnEndRide?.visibility = View.GONE
            }

            btnCancel.setOnClickListener {
                val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
                val startDate = try { sdf.parse(booking.startDate) } catch (e: Exception) { null }
                val now = java.util.Date()
                val hoursBeforeStart = if (startDate != null) ((startDate.time - now.time) / (1000 * 60 * 60)).toInt() else 0
                val canCancel = booking.status == "Active"
                if (!canCancel) return@setOnClickListener
                AlertDialog.Builder(context)
                    .setTitle("Cancel Booking")
                    .setMessage("Are you sure you want to cancel this booking?")
                    .setPositiveButton("Yes") { dialog, _ ->
                        // Remove from active bookings
                        BookingRepository.allBookings.removeIf {
                            it.bikeName == booking.bikeName && it.startDate == booking.startDate && it.endDate == booking.endDate
                        }
                        // Refund logic
                        val refundMsg = when {
                            hoursBeforeStart > 3 -> "Full refund will be issued."
                            hoursBeforeStart in 1..3 -> "50% refund will be issued."
                            else -> "No refund as ride has started or is about to start."
                        }
                        Toast.makeText(context, "Booking cancelled! $refundMsg", Toast.LENGTH_LONG).show()
                        onBookingReturned(booking) // Refresh UI
                        dialog.dismiss()
                    }
                    .setNegativeButton("No") { dialog, _ ->
                        dialog.dismiss()
                    }
                    .show()
            }

            btnEndRide.setOnClickListener {
                showEndRideDialog(context, booking)
            }

            // Make the entire card clickable to toggle details
            itemView.setOnClickListener {
                toggleDetails(booking)
            }
        }

        private fun setupDetailsSection(booking: Booking) {
            val layoutDetails = itemView.findViewById<View>(R.id.layoutDetails)
            val tvDetailsPickupMode = itemView.findViewById<TextView>(R.id.tvDetailsPickupMode)
            val tvDetailsLastLocation = itemView.findViewById<TextView>(R.id.tvDetailsLastLocation)
            val tvDetailsRenter = itemView.findViewById<TextView>(R.id.tvDetailsRenter)
            val tvDetailsBookingCode = itemView.findViewById<TextView>(R.id.tvDetailsBookingCode)
            val layoutReview = itemView.findViewById<View>(R.id.layoutReview)

            // Set details
            tvDetailsPickupMode.text = itemView.context.getString(R.string.pickup_mode, booking.pickupMode.replaceFirstChar { it.uppercase() })
            tvDetailsLastLocation.text = itemView.context.getString(R.string.last_location, booking.lastKnownLocation)
            tvDetailsRenter.text = itemView.context.getString(R.string.renter, booking.renterName)
            val bookingCodeValue = if (booking.bookingCode.isNotEmpty()) booking.bookingCode else (100000..999999).random().toString()
            tvDetailsBookingCode.text = bookingCodeValue

            // Show review section for completed rides
            if (booking.status == "Completed") {
                layoutReview.visibility = View.VISIBLE
                setupReviewSection(booking)
            } else {
                layoutReview.visibility = View.GONE
            }
        }

        private fun setupReviewSection(booking: Booking) {
            val ratingBar = itemView.findViewById<RatingBar>(R.id.ratingBar)
            val etReview = itemView.findViewById<EditText>(R.id.etReview)
            val btnSubmitReview = itemView.findViewById<Button>(R.id.btnSubmitReview)

            // Load previous review if exists
            val reviewKey = booking.bikeName + booking.startDate + booking.endDate
            val prevReview = bookingReviews[reviewKey]
            if (prevReview != null) {
                ratingBar.rating = prevReview.first
                etReview.setText(prevReview.second)
            }

            btnSubmitReview.setOnClickListener {
                val rating = ratingBar.rating
                val review = etReview.text.toString()
                bookingReviews[reviewKey] = rating to review
                Toast.makeText(itemView.context, "Thanks for rating $rating stars!", Toast.LENGTH_SHORT).show()
                btnSubmitReview.isEnabled = false
                btnSubmitReview.text = itemView.context.getString(R.string.review_submitted)
            }
        }

        private fun toggleDetails(booking: Booking) {
            val layoutDetails = itemView.findViewById<View>(R.id.layoutDetails)
            if (layoutDetails.visibility == View.VISIBLE) {
                layoutDetails.visibility = View.GONE
            } else {
                layoutDetails.visibility = View.VISIBLE
            }
        }

        private fun showEndRideDialog(context: android.content.Context, booking: Booking) {
            // Check if late
            val dateTimeFormats = listOf(
                SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()),
                SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
            )
            var endDate: Date? = null
            for (fmt in dateTimeFormats) {
                try {
                    endDate = fmt.parse(booking.endDate)
                    if (endDate != null) break
                } catch (_: Exception) {}
            }
            val now = Date()
            val isLate = endDate != null && now.after(endDate)
            // Grace period: 10 minutes
            val graceMillis = 10 * 60 * 1000
            val lateMillis = if (isLate) (now.time - endDate!!.time) else 0L
            val lateHours = if (isLate && lateMillis > graceMillis) Math.ceil(lateMillis / 3600000.0).toInt() else 0
            var lateFee = 0
            var lateMsg = ""
            if (lateHours > 0) {
                if (lateHours <= 2) {
                    lateFee = lateHours * booking.price // Use hourly price for up to 2 hours
                    lateMsg = "\n\nYour ride is late by $lateHours hour(s)! Late fee: ₹$lateFee (hourly price x $lateHours)"
                } else if (lateHours <= 5) {
                    lateFee = (lateHours * 50).coerceAtMost(1000) // 50/hr, max 1000
                    lateMsg = "\n\nYour ride is late by $lateHours hour(s)! Late fee: ₹$lateFee (₹50 x $lateHours)"
                } else {
                    val extraHours = lateHours - 5
                    lateFee = 1000 + (extraHours * booking.price * 2)
                    lateMsg = "\n\nYour ride is late by $lateHours hour(s)! Late fee: ₹1000 for first 5 hours + ₹${booking.price * 2} x $extraHours for remaining $extraHours hour(s). Total: ₹$lateFee"
                }
            }
            val builder = AlertDialog.Builder(context)
            val locationMsg = "\nLast Known Location: ${booking.lastKnownLocation}"
            when (booking.pickupMode) {
                "manual" -> {
                    builder.setTitle(context.getString(R.string.end_ride_manual))
                        .setMessage("Please meet the owner at the pickup location to return the bike.$lateMsg$locationMsg")
                        .setPositiveButton(context.getString(R.string.end_ride_generic)) { d, _ ->
                            endRide(booking)
                            d.dismiss()
                        }
                }
                "smart_lock" -> {
                    builder.setTitle(context.getString(R.string.end_ride_smart_lock))
                        .setMessage("Lock the bike using the app.$lateMsg$locationMsg")
                        .setPositiveButton(context.getString(R.string.lock_end_ride)) { d, _ ->
                            smartLockStatus[booking.bikeName] = false
                            endRide(booking)
                            d.dismiss()
                        }
                }
                "station" -> {
                    builder.setTitle(context.getString(R.string.end_ride_station))
                        .setMessage("Return the bike to the nearest station and lock it.$lateMsg$locationMsg")
                        .setPositiveButton(context.getString(R.string.return_at_station)) { d, _ ->
                            endRide(booking)
                            d.dismiss()
                        }
                }
                else -> {
                    builder.setTitle(context.getString(R.string.end_ride_generic))
                        .setMessage("End ride process not specified.$lateMsg$locationMsg")
                        .setPositiveButton(context.getString(R.string.end_ride_generic)) { d, _ ->
                            endRide(booking)
                            d.dismiss()
                        }
                }
            }
            if (lateFee > 0) {
                builder.setNegativeButton(context.getString(R.string.pay_late_fee)) { d, _ ->
                    Toast.makeText(context, context.getString(R.string.late_fee_paid), Toast.LENGTH_SHORT).show()
                    d.dismiss()
                }
            }
            builder.show()
        }

        private fun endRide(booking: Booking) {
            // Mark as completed
            val idx = BookingRepository.allBookings.indexOfFirst { 
                it.bikeName == booking.bikeName && it.startDate == booking.startDate && it.endDate == booking.endDate 
            }
            if (idx != -1) {
                BookingRepository.allBookings[idx] = BookingRepository.allBookings[idx].copy(status = "Completed")
            }
            
            Toast.makeText(itemView.context, itemView.context.getString(R.string.end_ride_success), Toast.LENGTH_SHORT).show()
            onBookingReturned(booking) // Refresh UI to move to past section
        }
    }

    companion object {
        private var smartLockStatus = mutableMapOf<String, Boolean>() // bikeName -> unlocked
    }
}
