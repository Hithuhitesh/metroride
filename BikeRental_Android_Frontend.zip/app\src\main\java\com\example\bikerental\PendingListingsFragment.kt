package com.example.bikerental

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class PendingListingsFragment : Fragment() {
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_pending_listings, container, false)
        val recyclerView = view.findViewById<RecyclerView>(R.id.rvPendingListings)
        recyclerView.layoutManager = LinearLayoutManager(requireContext())
        recyclerView.adapter = PendingListingsAdapter(getMockPendingListings())
        return view
    }

    private fun getMockPendingListings(): List<PendingListing> = listOf(
        PendingListing(R.drawable.unicorn_standard_bike, "Marina Cruiser", "Standard", "Marina Beach", "user1@email.com"),
        PendingListing(R.drawable.unicorn_standard_bike, "E-Bike Pro", "Electric", "T. Nagar", "user2@email.com")
    )

    data class PendingListing(val photoRes: Int, val name: String, val type: String, val location: String, val user: String)

    inner class PendingListingsAdapter(private val items: List<PendingListing>) : RecyclerView.Adapter<PendingListingsAdapter.ViewHolder>() {
        inner class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
            val ivPhoto: ImageView = view.findViewById(R.id.ivBikePhoto)
            val tvName: TextView = view.findViewById(R.id.tvBikeName)
            val tvType: TextView = view.findViewById(R.id.tvBikeType)
            val tvLocation: TextView = view.findViewById(R.id.tvBikeLocation)
            val tvUser: TextView = view.findViewById(R.id.tvUserWhoListed)
            val btnApprove: Button = view.findViewById(R.id.btnApprove)
            val btnReject: Button = view.findViewById(R.id.btnReject)
        }
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
            val v = LayoutInflater.from(parent.context).inflate(R.layout.item_pending_listing, parent, false)
            return ViewHolder(v)
        }
        override fun onBindViewHolder(holder: ViewHolder, position: Int) {
            val item = items[position]
            holder.ivPhoto.setImageResource(item.photoRes)
            holder.tvName.text = item.name
            holder.tvType.text = item.type
            holder.tvLocation.text = item.location
            holder.tvUser.text = "Listed by: ${item.user}"
            holder.btnApprove.setOnClickListener {
                Toast.makeText(requireContext(), "Approved ${item.name}", Toast.LENGTH_SHORT).show()
            }
            holder.btnReject.setOnClickListener {
                Toast.makeText(requireContext(), "Rejected ${item.name}", Toast.LENGTH_SHORT).show()
            }
        }
        override fun getItemCount() = items.size
    }
}


