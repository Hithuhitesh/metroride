package com.example.bikerental

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class ViolationsFinesFragment : Fragment() {
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_violations_fines, container, false)
        val recyclerView = view.findViewById<RecyclerView>(R.id.rvViolationsFines)
        recyclerView.layoutManager = LinearLayoutManager(requireContext())
        recyclerView.adapter = ViolationsFinesAdapter(getMockViolations())
        return view
    }

    private fun getMockViolations(): List<Violation> = listOf(
        Violation("Alice", "Marina Cruiser", "Late Return", 100, "Unpaid"),
        Violation("Bob", "E-Bike Pro", "Damage", 250, "Paid")
    )

    data class Violation(val renterName: String, val bikeName: String, val type: String, val fineAmount: Int, var paymentStatus: String)

    inner class ViolationsFinesAdapter(private val items: List<Violation>) : RecyclerView.Adapter<ViolationsFinesAdapter.ViewHolder>() {
        inner class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
            val tvRenterName: TextView = view.findViewById(R.id.tvRenterName)
            val tvBikeName: TextView = view.findViewById(R.id.tvBikeName)
            val tvType: TextView = view.findViewById(R.id.tvType)
            val tvFineAmount: TextView = view.findViewById(R.id.tvFineAmount)
            val tvPaymentStatus: TextView = view.findViewById(R.id.tvPaymentStatus)
            val btnMarkPaid: Button = view.findViewById(R.id.btnMarkPaid)
        }
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
            val v = LayoutInflater.from(parent.context).inflate(R.layout.item_violation_fine, parent, false)
            return ViewHolder(v)
        }
        override fun onBindViewHolder(holder: ViewHolder, position: Int) {
            val item = items[position]
            holder.tvRenterName.text = "Renter: ${item.renterName}"
            holder.tvBikeName.text = "Bike: ${item.bikeName}"
            holder.tvType.text = "Type: ${item.type}"
            holder.tvFineAmount.text = "Fine: ₹${item.fineAmount}"
            holder.tvPaymentStatus.text = "Status: ${item.paymentStatus}"
            holder.btnMarkPaid.visibility = if (item.paymentStatus == "Unpaid") View.VISIBLE else View.GONE
            holder.btnMarkPaid.setOnClickListener {
                Toast.makeText(requireContext(), "Marked as Paid", Toast.LENGTH_SHORT).show()
                holder.tvPaymentStatus.text = "Status: Paid"
                holder.btnMarkPaid.visibility = View.GONE
            }
        }
        override fun getItemCount() = items.size
    }
} 