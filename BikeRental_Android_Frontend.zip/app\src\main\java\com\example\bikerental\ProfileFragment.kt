package com.example.bikerental

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Switch
import android.widget.Toast
import android.widget.TextView
import android.widget.Button
import androidx.fragment.app.Fragment
import android.widget.ImageView
import android.app.Activity
import android.content.Intent
import android.net.Uri
import androidx.activity.result.contract.ActivityResultContracts

class ProfileFragment : Fragment() {
    private var avatarUri: Uri? = null
    private lateinit var avatarImageView: ImageView
    private lateinit var cameraOverlay: ImageView
    private var pickImageLauncher: androidx.activity.result.ActivityResultLauncher<Intent>? = null
    private var isFragmentActive = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        pickImageLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (!isFragmentActive || !isAdded) return@registerForActivityResult
            
            if (result.resultCode == Activity.RESULT_OK && result.data != null) {
                val uri = result.data!!.data
                if (uri != null) {
                    avatarUri = uri
                    try {
                        if (::avatarImageView.isInitialized) {
                            avatarImageView.setImageURI(uri)
                        }
                    } catch (e: Exception) {
                        android.util.Log.e("ProfileFragment", "Error setting image: ${e.message}")
                    }
                } else {
                    Toast.makeText(requireContext(), "Failed to get image", Toast.LENGTH_SHORT).show()
                }
            } else {
                Toast.makeText(requireContext(), "Image selection cancelled", Toast.LENGTH_SHORT).show()
            }
        }
    }
    
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_profile, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        isFragmentActive = true
        
        try {
            android.util.Log.d("ProfileFragment", "ProfileFragment onViewCreated started")
            
            // Initialize UserManager
            UserManager.initialize(requireContext())
            
            // Get user information from UserManager and SharedPreferences to ensure consistency
            val currentUser = UserManager.getCurrentUser()
            val prefs = requireContext().getSharedPreferences("metro_ride_prefs", 0)
            val sharedPrefsRole = prefs.getString("role", "user") ?: "user"
            val userManagerRole = UserManager.getCurrentUserRole()
            
            // Use SharedPreferences role as the source of truth since it's updated during role switching
            val role = sharedPrefsRole
            val userName = UserManager.getCurrentUserName()
            val userEmail = UserManager.getCurrentUserEmail()

            android.util.Log.d("ProfileFragment", "User info - Name: $userName, Email: $userEmail, Role: $role (SharedPrefs: $sharedPrefsRole, UserManager: $userManagerRole)")
            android.util.Log.d("ProfileFragment", "ProfileFragment loaded for role: $role")
            
            // Initialize avatar elements
            avatarImageView = view.findViewById(R.id.ivProfileAvatar)
            cameraOverlay = view.findViewById(R.id.ivCameraOverlay)
            
            val avatarClickListener = View.OnClickListener {
                if (!isFragmentActive || !isAdded) return@OnClickListener
                try {
                    val intent = Intent(Intent.ACTION_PICK)
                    intent.type = "image/*"
                    pickImageLauncher?.launch(intent)
                } catch (e: Exception) {
                    android.util.Log.e("ProfileFragment", "Error launching image picker: ${e.message}")
                    Toast.makeText(requireContext(), "Error opening image picker", Toast.LENGTH_SHORT).show()
                }
            }
            avatarImageView.setOnClickListener(avatarClickListener)
            cameraOverlay.setOnClickListener(avatarClickListener)

            // Update profile information
            view.findViewById<TextView>(R.id.tvUserName)?.text = userName
            view.findViewById<TextView>(R.id.tvUserEmail)?.text = userEmail
            
            // Update role indicator
            val roleIndicator = view.findViewById<TextView>(R.id.tvCurrentRole)
            roleIndicator?.text = if (role == "admin") "Admin Mode" else "User Mode"
            roleIndicator?.setTextColor(if (role == "admin") 0xFF7C3AED.toInt() else 0xFF6C6C80.toInt())

            // Switch Role Card - SIMPLE APPROACH WITHOUT ACTIVITY RESTART
            val switchRole = view.findViewById<Switch>(R.id.switchRole)
            switchRole?.let { switch ->
                switch.isChecked = role == "admin"
                switch.text = if (role == "admin") "Switch to User Mode" else "Switch to Owner Mode"
                var ignoreSwitchListener = false
                
                switch.setOnCheckedChangeListener { _, isChecked ->
                    if (!isFragmentActive || !isAdded || ignoreSwitchListener) return@setOnCheckedChangeListener
                    
                    val newRole = if (isChecked) "admin" else "user"
                    
                    try {
                        // Update user role in UserManager
                        currentUser?.let { user ->
                            val updatedUser = user.copy(role = newRole)
                            // Note: This is a simplified approach. In a real app, you'd want to update the user in the database
                            // For now, we'll just update the current session
                        }
                        
                        // Update navigation in MainActivity without automatic navigation
                        (activity as? MainActivity)?.updateNavigationForRole(newRole, false)
                        
                        // Show confirmation
                        Toast.makeText(requireContext(), "Switched to ${newRole.uppercase()} mode", Toast.LENGTH_SHORT).show()
                        
                    } catch (e: Exception) {
                        android.util.Log.e("ProfileFragment", "Error switching role: ${e.message}")
                        Toast.makeText(requireContext(), "Error switching role", Toast.LENGTH_SHORT).show()
                        // Revert the switch
                        ignoreSwitchListener = true
                        switch.isChecked = !isChecked
                        ignoreSwitchListener = false
                    }
                }
            }

            // Saved Bikes navigation (only for users)
            setupSavedBikesNavigation(view, role)

            // Setup settings with the correct role
            setupSettings(role)
            
        } catch (e: Exception) {
            android.util.Log.e("ProfileFragment", "Error in onViewCreated: ${e.message}")
            Toast.makeText(requireContext(), "Error loading profile", Toast.LENGTH_SHORT).show()
        }
    }

    private fun setupSavedBikesNavigation(view: View, role: String?) {
        val savedBikesRow = view.findViewById<View>(R.id.llSavedBikes)
        savedBikesRow?.let { row ->
            if (role == "user") {
                row.visibility = View.VISIBLE
                row.setOnClickListener {
                    if (!isFragmentActive || !isAdded) return@setOnClickListener
                    try {
                        val fragment = SavedBikesFragment()
                        requireActivity().supportFragmentManager.beginTransaction()
                            .replace(R.id.fragmentContainerView, fragment)
                            .addToBackStack(null)
                            .commit()
                    } catch (e: Exception) {
                        android.util.Log.e("ProfileFragment", "Error navigating to SavedBikes: ${e.message}")
                        Toast.makeText(requireContext(), "Error opening Saved Bikes", Toast.LENGTH_SHORT).show()
                    }
                }
            } else {
                row.visibility = View.GONE
            }
        }
    }

    private fun updateNavigationForRole(newRole: String) {
        try {
            // Update the bottom navigation based on the new role
            val bottomNav = requireActivity().findViewById<com.google.android.material.bottomnavigation.BottomNavigationView>(R.id.bottomNavigationView)
            bottomNav?.let { nav ->
                val menu = nav.menu
                
                if (newRole == "admin") {
                    // Admin navigation: My Bikes, List Your Bike, Profile
                    menu.findItem(R.id.menu_home)?.isVisible = false
                    menu.findItem(R.id.menu_rentals)?.isVisible = false
                    menu.findItem(R.id.menu_my_bikes)?.isVisible = true
                    menu.findItem(R.id.menu_list_bike)?.isVisible = true
                    menu.findItem(R.id.menu_profile)?.isVisible = true
                } else {
                    // User navigation: Home, Rentals, Profile
                    menu.findItem(R.id.menu_home)?.isVisible = true
                    menu.findItem(R.id.menu_rentals)?.isVisible = true
                    menu.findItem(R.id.menu_my_bikes)?.isVisible = false
                    menu.findItem(R.id.menu_list_bike)?.isVisible = false
                    menu.findItem(R.id.menu_profile)?.isVisible = true
                }
            }
        } catch (e: Exception) {
            android.util.Log.e("ProfileFragment", "Error updating navigation: ${e.message}")
        }
    }

    private fun navigateToDefaultFragment(newRole: String) {
        try {
            val bottomNav = requireActivity().findViewById<com.google.android.material.bottomnavigation.BottomNavigationView>(R.id.bottomNavigationView)
            
            if (newRole == "admin") {
                // Switch to My Bikes fragment for admin
                requireActivity().supportFragmentManager.beginTransaction()
                    .replace(R.id.fragmentContainerView, MyBikesFragment())
                    .commit()
                bottomNav?.selectedItemId = R.id.menu_my_bikes
            } else {
                // Switch to Home fragment for user
                requireActivity().supportFragmentManager.beginTransaction()
                    .replace(R.id.fragmentContainerView, HomeFragment())
                    .commit()
                bottomNav?.selectedItemId = R.id.menu_home
            }
        } catch (e: Exception) {
            android.util.Log.e("ProfileFragment", "Error navigating to default fragment: ${e.message}")
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        isFragmentActive = false
    }

    override fun onDestroy() {
        super.onDestroy()
        isFragmentActive = false
    }

    private fun setupSettings(role: String) {
        val view = view ?: return
        
        // Load user data from SharedPreferences
        val prefs = requireContext().getSharedPreferences("metro_ride_prefs", 0)
        val userName = prefs.getString("name", "John Doe") ?: "John Doe"
        val userEmail = prefs.getString("email", "john.doe@email.com") ?: "john.doe@email.com"
        val userPhone = prefs.getString("phone", "+91 98765 43210") ?: "+91 98765 43210"
        
        // Update user info display
        view.findViewById<TextView>(R.id.tvUserName)?.text = userName
        view.findViewById<TextView>(R.id.tvUserEmail)?.text = userEmail
        view.findViewById<TextView>(R.id.tvUserPhone)?.text = userPhone
        
        // Update role indicator
        val roleIndicator = view.findViewById<TextView>(R.id.tvCurrentRole)
        roleIndicator?.text = if (role == "admin") "Admin Mode" else "User Mode"
        roleIndicator?.setTextColor(if (role == "admin") 0xFF7C3AED.toInt() else 0xFF6C6C80.toInt())
        
        // Setup role switch
        setupRoleSwitch(view, role)
        
        // Setup visibility based on role
        setupRoleBasedVisibility(view, role)
        
        // Setup click listeners for all menu items (available for both user and admin)
        setupMenuClickListeners(view)
        
        // Setup logout button
        setupLogoutButton(view)
    }

    private fun setupRoleSwitch(view: View, currentRole: String) {
        val switchRole = view.findViewById<Switch>(R.id.switchRole)
        val tvRoleSwitch = view.findViewById<TextView>(R.id.tvRoleSwitch)
        
        switchRole?.let { switch ->
            switch.isChecked = currentRole == "admin"
            tvRoleSwitch.text = if (currentRole == "admin") "Switch to User Mode" else "Switch to Owner Mode"
            
            switch.setOnCheckedChangeListener { _, isChecked ->
                val newRole = if (isChecked) "admin" else "user"
                
                // Show authentication dialog before switching roles
                val dialog = RoleSwitchDialogFragment.newInstance(currentRole, newRole)
                dialog.show(requireActivity().supportFragmentManager, "RoleSwitchDialog")
            }
        }
    }
    
    private fun setupMenuClickListeners(view: View) {
        // Get current role from SharedPreferences
        val prefs = requireContext().getSharedPreferences("metro_ride_prefs", 0)
        val currentRole = prefs.getString("role", "user") ?: "user"
        
        // Saved Bikes (only for users)
        view.findViewById<View>(R.id.llSavedBikes)?.setOnClickListener {
            if (currentRole == "user") {
                try {
                    val fragment = SavedBikesFragment()
                    requireActivity().supportFragmentManager.beginTransaction()
                        .replace(R.id.fragmentContainerView, fragment)
                        .addToBackStack(null)
                        .commit()
                } catch (e: Exception) {
                    android.util.Log.e("ProfileFragment", "Error navigating to SavedBikes: ${e.message}")
                    Toast.makeText(requireContext(), "Error opening Saved Bikes", Toast.LENGTH_SHORT).show()
                }
            } else {
                Toast.makeText(requireContext(), "Saved Bikes not available for admin", Toast.LENGTH_SHORT).show()
            }
        }
        
        // Help Center (available for both user and admin)
        view.findViewById<View>(R.id.llHelpCenter)?.setOnClickListener {
            showHelpCenter()
        }
        
        // Contact Us (available for both user and admin)
        view.findViewById<View>(R.id.llContactUs)?.setOnClickListener {
            showContactUs()
        }
        
        // About Metro Ride (available for both user and admin)
        view.findViewById<View>(R.id.llAbout)?.setOnClickListener {
            showAboutMetroRide()
        }
        
        // Terms & Conditions (available for both user and admin)
        view.findViewById<View>(R.id.llTerms)?.setOnClickListener {
            showTermsAndConditions()
        }
        
        // Privacy & Security
        view.findViewById<View>(R.id.llPrivacy)?.setOnClickListener {
            Toast.makeText(requireContext(), "Privacy & Security - Coming Soon!", Toast.LENGTH_SHORT).show()
        }
        
        // Edit Profile
        view.findViewById<Button>(R.id.btnEditProfile)?.setOnClickListener {
            Toast.makeText(requireContext(), "Edit Profile - Coming Soon!", Toast.LENGTH_SHORT).show()
        }
        
        // Logout is handled by setupLogoutButton function
    }

    private fun setupLogoutButton(view: View) {
        val logoutButton = view.findViewById<Button>(R.id.btnLogout)
        logoutButton?.setOnClickListener {
            if (!isFragmentActive || !isAdded) return@setOnClickListener
            
            try {
                // Show confirmation dialog
                androidx.appcompat.app.AlertDialog.Builder(requireContext())
                    .setTitle("Logout")
                    .setMessage("Are you sure you want to logout?")
                    .setPositiveButton("Logout") { _, _ ->
                        performLogout()
                    }
                    .setNegativeButton("Cancel", null)
                    .show()
            } catch (e: Exception) {
                android.util.Log.e("ProfileFragment", "Error showing logout dialog: ${e.message}")
                Toast.makeText(requireContext(), "Error showing logout dialog", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun performLogout() {
        try {
            // Logout using UserManager
            UserManager.logoutUser()
            
            // Show success message
            Toast.makeText(requireContext(), "Logged out successfully", Toast.LENGTH_SHORT).show()
            
            // Navigate back to login screen
            val intent = Intent(requireContext(), LoginActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            startActivity(intent)
            
        } catch (e: Exception) {
            android.util.Log.e("ProfileFragment", "Error during logout: ${e.message}")
            Toast.makeText(requireContext(), "Error during logout", Toast.LENGTH_SHORT).show()
        }
    }
    
    // Methods for role switching callbacks
    fun onRoleSwitched(newRole: String) {
        try {
            // Save the new role and admin flag to SharedPreferences
            val prefs = requireContext().getSharedPreferences("metro_ride_prefs", 0)
            prefs.edit()
                .putString("role", newRole)
                .putBoolean("is_admin", newRole == "admin")
                .apply()
            
            // Update the switch text
            val switchRole = view?.findViewById<Switch>(R.id.switchRole)
            val tvRoleSwitch = view?.findViewById<TextView>(R.id.tvRoleSwitch)
            
            switchRole?.isChecked = newRole == "admin"
            tvRoleSwitch?.text = if (newRole == "admin") "Switch to User Mode" else "Switch to Owner Mode"
            
            // Update navigation visibility based on new role (without automatic navigation)
            updateNavigationForRole(newRole)
            
        } catch (e: Exception) {
            android.util.Log.e("ProfileFragment", "Error updating UI after role switch: ${e.message}")
        }
    }
    
    fun onRoleSwitchFailed() {
        try {
            // Revert the switch to its previous state
            val switchRole = view?.findViewById<Switch>(R.id.switchRole)
            val tvRoleSwitch = view?.findViewById<TextView>(R.id.tvRoleSwitch)
            
            val prefs = requireContext().getSharedPreferences("metro_ride_prefs", 0)
            val currentRole = prefs.getString("role", "user") ?: "user"
            
            switchRole?.isChecked = currentRole == "admin"
            tvRoleSwitch?.text = if (currentRole == "admin") "Switch to User Mode" else "Switch to Owner Mode"
            
        } catch (e: Exception) {
            android.util.Log.e("ProfileFragment", "Error reverting role switch: ${e.message}")
        }
    }
    
    private fun setupRoleBasedVisibility(view: View, role: String) {
        // Show/hide Saved Bikes based on role
        val savedBikesRow = view.findViewById<View>(R.id.llSavedBikes)
        savedBikesRow?.visibility = if (role == "user") View.VISIBLE else View.GONE
    }
    
    private fun showHelpCenter() {
        val helpItems = arrayOf(
            "How to rent a bike?",
            "How to list your bike?",
            "Payment issues",
            "Booking problems",
            "Account settings"
        )
        
        androidx.appcompat.app.AlertDialog.Builder(requireContext())
            .setTitle("Help Center")
            .setItems(helpItems) { _, which ->
                val helpTopic = helpItems[which]
                showHelpDetails(helpTopic)
            }
            .setPositiveButton("Close", null)
            .show()
    }
    
    private fun showHelpDetails(topic: String) {
        val helpContent = when (topic) {
            "How to rent a bike?" -> "1. Browse available bikes on the home screen\n2. Select a bike that suits your needs\n3. Choose rental duration (hourly/daily)\n4. Complete payment\n5. Pick up your bike from the owner"
            "How to list your bike?" -> "1. Go to 'List Your Bike' section\n2. Fill in bike details and pricing\n3. Add photos and location\n4. Submit for approval\n5. Start earning from rentals"
            "Payment issues" -> "For payment issues, please contact our support team at support@metroride.com or call +91-98765-43210"
            "Booking problems" -> "If you're having trouble with bookings, try:\n• Refreshing the app\n• Checking your internet connection\n• Contacting the bike owner directly"
            "Account settings" -> "To change account settings:\n• Go to Profile section\n• Click on Edit button\n• Update your information\n• Save changes"
            else -> "For more help, please contact our support team."
        }
        
        androidx.appcompat.app.AlertDialog.Builder(requireContext())
            .setTitle(topic)
            .setMessage(helpContent)
            .setPositiveButton("Got it", null)
            .show()
    }
    
    private fun showContactUs() {
        val contactOptions = arrayOf("Call Support", "Email Support", "Live Chat")
        
        androidx.appcompat.app.AlertDialog.Builder(requireContext())
            .setTitle("Contact Us")
            .setItems(contactOptions) { _, which ->
                when (which) {
                    0 -> {
                        // Call support
                        try {
                            val intent = Intent(Intent.ACTION_DIAL)
                            intent.data = android.net.Uri.parse("tel:+919876543210")
                            startActivity(intent)
                        } catch (e: Exception) {
                            Toast.makeText(requireContext(), "Unable to make call", Toast.LENGTH_SHORT).show()
                        }
                    }
                    1 -> {
                        // Email support
                        try {
                            val intent = Intent(Intent.ACTION_SENDTO)
                            intent.data = android.net.Uri.parse("mailto:support@metroride.com")
                            intent.putExtra(Intent.EXTRA_SUBJECT, "Metro Ride Support")
                            startActivity(intent)
                        } catch (e: Exception) {
                            Toast.makeText(requireContext(), "Unable to send email", Toast.LENGTH_SHORT).show()
                        }
                    }
                    2 -> {
                        Toast.makeText(requireContext(), "Live chat feature coming soon!", Toast.LENGTH_SHORT).show()
                    }
                }
            }
            .setPositiveButton("Cancel", null)
            .show()
    }
    
    private fun showAboutMetroRide() {
        val aboutContent = """
            Metro Ride is your trusted platform for bike rentals in the city.
            
            Our Mission:
            To provide safe, convenient, and affordable bike rental services to everyone.
            
            Features:
            • Easy bike rental booking
            • Secure payment system
            • Real-time tracking
            • 24/7 customer support
            • Wide range of vehicles
            
            Version: 1.0.0
            © 2024 Metro Ride. All rights reserved.
        """.trimIndent()
        
        androidx.appcompat.app.AlertDialog.Builder(requireContext())
            .setTitle("About Metro Ride")
            .setMessage(aboutContent)
            .setPositiveButton("Close", null)
            .show()
    }
    
    private fun showTermsAndConditions() {
        val termsContent = """
            Terms and Conditions for Metro Ride
            
            1. Service Usage:
            • Users must be 18+ years old
            • Valid ID proof required for verification
            • Follow traffic rules and safety guidelines
            
            2. Booking and Payment:
            • Full payment required before booking
            • Cancellation policy applies
            • Refunds processed within 3-5 business days
            
            3. Bike Rental:
            • Return bike in same condition
            • Report any damages immediately
            • Fuel charges not included
            
            4. Liability:
            • Users responsible for traffic violations
            • Metro Ride not liable for accidents
            • Insurance coverage as per policy
            
            5. Privacy:
            • Personal data used for service provision
            • No sharing with third parties
            • Secure data storage practices
            
            Last updated: January 2024
        """.trimIndent()
        
        androidx.appcompat.app.AlertDialog.Builder(requireContext())
            .setTitle("Terms & Conditions")
            .setMessage(termsContent)
            .setPositiveButton("Close", null)
            .show()
    }
} 