package com.example.bikerental

import android.content.Context
import android.content.SharedPreferences
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

data class LocalUser(
    val id: String,
    val name: String,
    val email: String,
    val password: String,
    val phone: String,
    val role: String,
    val isLoggedIn: Boolean = false
)

object UserManager {
    private const val PREF_NAME = "metro_ride_users"
    private const val USERS_KEY = "users"
    private const val CURRENT_USER_KEY = "current_user"
    private const val TOKEN_KEY = "auth_token"
    
    private lateinit var prefs: SharedPreferences
    private val gson = Gson()
    
    fun initialize(context: Context) {
        try {
            prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
            android.util.Log.d("UserManager", "UserManager initialized successfully")
        } catch (e: Exception) {
            android.util.Log.e("UserManager", "Error initializing UserManager: ${e.message}", e)
            throw e
        }
    }
    
    private fun getUsers(): MutableList<LocalUser> {
        return try {
            val usersJson = prefs.getString(USERS_KEY, "[]")
            val type = object : TypeToken<MutableList<LocalUser>>() {}.type
            gson.fromJson(usersJson, type) ?: mutableListOf()
        } catch (e: Exception) {
            android.util.Log.e("UserManager", "Error getting users: ${e.message}", e)
            mutableListOf()
        }
    }
    
    private fun saveUsers(users: List<LocalUser>) {
        try {
            val usersJson = gson.toJson(users)
            prefs.edit().putString(USERS_KEY, usersJson).apply()
        } catch (e: Exception) {
            android.util.Log.e("UserManager", "Error saving users: ${e.message}", e)
        }
    }
    
    fun registerUser(name: String, email: String, password: String, phone: String, role: String): Boolean {
        val users = getUsers()
        
        android.util.Log.d("UserManager", "Registering user: $email with role: $role")
        android.util.Log.d("UserManager", "Current users count: ${users.size}")
        
        // Check if email already exists
        if (users.any { it.email == email }) {
            android.util.Log.w("UserManager", "Email already exists: $email")
            return false // Email already exists
        }
        
        // Create new user
        val newUser = LocalUser(
            id = "user_${System.currentTimeMillis()}",
            name = name,
            email = email,
            password = password,
            phone = phone,
            role = role,
            isLoggedIn = true
        )
        
        android.util.Log.d("UserManager", "Created new user: ${newUser.name} (${newUser.email})")
        
        // Add to users list
        users.add(newUser)
        saveUsers(users)
        
        android.util.Log.d("UserManager", "Saved users. New count: ${getUsers().size}")
        
        // Set as current user
        setCurrentUser(newUser)
        
        android.util.Log.d("UserManager", "Registration successful for: $email")
        return true
    }
    
    // Backend authentication
    fun loginWithBackend(email: String, password: String, callback: (Boolean, String?) -> Unit) {
        val loginRequest = LoginRequest(email = email, password = password)
        
        ApiClient.apiService.login(loginRequest).enqueue(object : retrofit2.Callback<LoginResponse> {
            override fun onResponse(call: retrofit2.Call<LoginResponse>, response: retrofit2.Response<LoginResponse>) {
                if (response.isSuccessful && response.body()?.success == true) {
                    val loginResponse = response.body()!!
                    val apiUser = loginResponse.user
                    val token = loginResponse.token
                    
                    if (apiUser != null && token != null) {
                        // Save token
                        prefs.edit().putString(TOKEN_KEY, token).apply()
                        
                        // Convert API user to local user and save
                        val user = LocalUser(
                            id = apiUser.id,
                            name = apiUser.name,
                            email = apiUser.email,
                            password = "", // Don't store password locally
                            phone = apiUser.phone,
                            role = apiUser.role,
                            isLoggedIn = true
                        )
                        setCurrentUser(user)
                        
                        android.util.Log.d("UserManager", "Backend login successful for: ${user.email}")
                        callback(true, null)
                    } else {
                        callback(false, "Invalid response from server")
                    }
                } else {
                    val error = response.body()?.error ?: "Login failed"
                    android.util.Log.d("UserManager", "Backend login failed: $error")
                    callback(false, error)
                }
            }
            
            override fun onFailure(call: retrofit2.Call<LoginResponse>, t: Throwable) {
                android.util.Log.d("UserManager", "Backend login network error: ${t.message}")
                // Fallback to local login
                val success = loginUserLocal(email, password, "user")
                callback(success, if (success) null else "Network error, tried local login")
            }
        })
    }
    
    fun registerWithBackend(name: String, email: String, password: String, phone: String, callback: (Boolean, String?) -> Unit) {
        val loginRequest = LoginRequest(email = email, password = password, name = name, phone = phone)
        
        ApiClient.apiService.login(loginRequest).enqueue(object : retrofit2.Callback<LoginResponse> {
            override fun onResponse(call: retrofit2.Call<LoginResponse>, response: retrofit2.Response<LoginResponse>) {
                if (response.isSuccessful && response.body()?.success == true) {
                    val loginResponse = response.body()!!
                    val apiUser = loginResponse.user
                    val token = loginResponse.token
                    
                    if (apiUser != null && token != null) {
                        // Save token
                        prefs.edit().putString(TOKEN_KEY, token).apply()
                        
                        // Convert API user to local user and save
                        val user = LocalUser(
                            id = apiUser.id,
                            name = apiUser.name,
                            email = apiUser.email,
                            password = "", // Don't store password locally
                            phone = apiUser.phone,
                            role = apiUser.role,
                            isLoggedIn = true
                        )
                        setCurrentUser(user)
                        
                        android.util.Log.d("UserManager", "Backend registration successful for: ${user.email}")
                        callback(true, null)
                    } else {
                        callback(false, "Invalid response from server")
                    }
                } else {
                    val error = response.body()?.error ?: "Registration failed"
                    android.util.Log.d("UserManager", "Backend registration failed: $error")
                    callback(false, error)
                }
            }
            
            override fun onFailure(call: retrofit2.Call<LoginResponse>, t: Throwable) {
                android.util.Log.d("UserManager", "Backend registration network error: ${t.message}")
                // Fallback to local registration
                val success = registerUser(name, email, password, phone, "user")
                callback(success, if (success) null else "Network error, tried local registration")
            }
        })
    }
    
    fun getAuthToken(): String? {
        return prefs.getString(TOKEN_KEY, null)
    }
    
    fun loginUser(email: String, password: String, role: String): Boolean {
        return loginUserLocal(email, password, role)
    }
    
    private fun loginUserLocal(email: String, password: String, role: String): Boolean {
        val users = getUsers()
        
        android.util.Log.d("UserManager", "Login attempt for: $email with role: $role")
        android.util.Log.d("UserManager", "Total users in database: ${users.size}")
        users.forEach { user ->
            android.util.Log.d("UserManager", "User in DB: ${user.email} (${user.name}) - Role: ${user.role}")
        }
        
        // First, try to find user with exact email, password, and role match
        var user = users.find { 
            it.email == email && it.password == password && it.role == role 
        }
        
        if (user != null) {
            android.util.Log.d("UserManager", "Found user with exact role match")
        } else {
            android.util.Log.d("UserManager", "No exact role match found, trying email/password only")
        }
        
        // If not found with exact role match, try to find user with just email and password
        if (user == null) {
            user = users.find { 
                it.email == email && it.password == password 
            }
            
            // If found with different role, log a warning but allow login
            if (user != null) {
                android.util.Log.w("UserManager", "User found with different role. Expected: $role, Actual: ${user.role}")
            }
        }
        
        if (user != null) {
            // Update login status
            val updatedUser = user.copy(isLoggedIn = true)
            val updatedUsers = users.map { if (it.id == user.id) updatedUser else it }
            saveUsers(updatedUsers)
            
            // Set as current user
            setCurrentUser(updatedUser)
            
            // Also update the role in SharedPreferences to match the actual user role
            val prefs = prefs
            prefs.edit()
                .putString("role", user.role)
                .putBoolean("is_admin", user.role == "admin")
                .apply()
            
            android.util.Log.d("UserManager", "Login successful for user: ${user.name} with role: ${user.role}")
            return true
        }
        
        android.util.Log.d("UserManager", "Login failed - no user found with email: $email")
        return false
    }
    
    fun logoutUser() {
        val currentUser = getCurrentUser()
        if (currentUser != null) {
            val users = getUsers()
            val updatedUsers = users.map { 
                if (it.id == currentUser.id) it.copy(isLoggedIn = false) else it 
            }
            saveUsers(updatedUsers)
        }
        
        // Clear current user and token
        prefs.edit()
            .remove(CURRENT_USER_KEY)
            .remove(TOKEN_KEY)
            .apply()
    }
    
    fun getCurrentUser(): LocalUser? {
        val userJson = prefs.getString(CURRENT_USER_KEY, null)
        return if (userJson != null) {
            gson.fromJson(userJson, LocalUser::class.java)
        } else {
            null
        }
    }
    
    private fun setCurrentUser(user: LocalUser) {
        val userJson = gson.toJson(user)
        prefs.edit().putString(CURRENT_USER_KEY, userJson).apply()
    }
    
    fun isLoggedIn(): Boolean {
        return getCurrentUser() != null
    }
    
    fun getCurrentUserRole(): String {
        return getCurrentUser()?.role ?: "user"
    }
    
    fun getCurrentUserEmail(): String {
        return getCurrentUser()?.email ?: ""
    }
    
    fun getCurrentUserName(): String {
        return getCurrentUser()?.name ?: ""
    }
    
    fun getAllUsers(): List<LocalUser> {
        return getUsers()
    }
    
    fun debugPrintAllUsers() {
        val users = getUsers()
        android.util.Log.d("UserManager", "=== All Registered Users ===")
        if (users.isEmpty()) {
            android.util.Log.d("UserManager", "No users found in database")
        } else {
            users.forEach { user ->
                android.util.Log.d("UserManager", "User: ${user.name} (${user.email}) - Role: ${user.role}")
            }
        }
        android.util.Log.d("UserManager", "=== End Users List ===")
    }
    
    fun deleteUser(userId: String): Boolean {
        val users = getUsers()
        val userToDelete = users.find { it.id == userId }
        
        if (userToDelete != null) {
            users.removeAll { it.id == userId }
            saveUsers(users)
            
            // If deleted user was current user, logout
            if (getCurrentUser()?.id == userId) {
                logoutUser()
            }
            
            return true
        }
        
        return false
    }
    
    fun updateUserProfile(userId: String, name: String, phone: String): Boolean {
        val users = getUsers()
        val userIndex = users.indexOfFirst { it.id == userId }
        
        if (userIndex != -1) {
            val updatedUser = users[userIndex].copy(name = name, phone = phone)
            users[userIndex] = updatedUser
            saveUsers(users)
            
            // Update current user if it's the same user
            if (getCurrentUser()?.id == userId) {
                setCurrentUser(updatedUser)
            }
            
            return true
        }
        
        return false
    }
    
    fun changePassword(userId: String, newPassword: String): Boolean {
        val users = getUsers()
        val userIndex = users.indexOfFirst { it.id == userId }
        
        if (userIndex != -1) {
            val updatedUser = users[userIndex].copy(password = newPassword)
            users[userIndex] = updatedUser
            saveUsers(users)
            
            // Update current user if it's the same user
            if (getCurrentUser()?.id == userId) {
                setCurrentUser(updatedUser)
            }
            
            return true
        }
        
        return false
    }

    // Function to create demo users for testing
    fun createDemoUsers() {
        try {
            val users = getUsers()
            
            // Only create demo users if no users exist
            if (users.isEmpty()) {
                // Create demo user account
                val demoUser = LocalUser(
                    id = "demo_user_001",
                    name = "Demo User",
                    email = "user@demo.com",
                    password = "user123",
                    phone = "+91 9876543210",
                    role = "user",
                    isLoggedIn = false
                )
                
                // Create demo admin account
                val demoAdmin = LocalUser(
                    id = "demo_admin_001",
                    name = "Demo Admin",
                    email = "admin@demo.com",
                    password = "admin123",
                    phone = "+91 9876543211",
                    role = "admin",
                    isLoggedIn = false
                )
                
                users.add(demoUser)
                users.add(demoAdmin)
                saveUsers(users)
                
                android.util.Log.d("UserManager", "Demo users created successfully")
            } else {
                android.util.Log.d("UserManager", "Users already exist, skipping demo creation")
            }
        } catch (e: Exception) {
            android.util.Log.e("UserManager", "Error creating demo users: ${e.message}", e)
            // Don't throw - just log the error
        }
    }

    // Function to get demo user credentials for testing
    fun getDemoCredentials(role: String): Pair<String, String>? {
        val users = getUsers()
        val demoUser = users.find { it.role == role }
        return if (demoUser != null) {
            Pair(demoUser.email, demoUser.password)
        } else {
            null
        }
    }
    
    // Function to validate credentials without logging in
    fun validateCredentials(email: String, password: String): Boolean {
        val users = getUsers()
        
        // Find user with matching email and password (any role)
        val user = users.find { 
            it.email == email && it.password == password 
        }
        
        android.util.Log.d("UserManager", "Validating credentials for email: $email, found user: ${user != null}")
        if (user != null) {
            android.util.Log.d("UserManager", "User found: ${user.name} with role: ${user.role}")
        }
        
        return user != null
    }
    
    // Function to clear all user data (useful for troubleshooting)
    fun clearAllUserData() {
        try {
            // Clear all users
            saveUsers(mutableListOf())
            
            // Clear current user
            prefs.edit().remove(CURRENT_USER_KEY).apply()
            
            // Clear role preferences
            prefs.edit()
                .remove("role")
                .remove("is_admin")
                .apply()
            
            android.util.Log.d("UserManager", "All user data cleared successfully")
        } catch (e: Exception) {
            android.util.Log.e("UserManager", "Error clearing user data: ${e.message}", e)
        }
    }
} 