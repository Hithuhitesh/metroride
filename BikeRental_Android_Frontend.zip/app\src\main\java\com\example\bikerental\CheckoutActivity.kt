package com.example.bikerental

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class CheckoutActivity : AppCompatActivity() {
    private var bike: Bike? = null
    private var isHourly: Boolean = true
    private var hours: Int = 1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_checkout)

        bike = intent.getParcelableExtra("bike")
        isHourly = intent.getBooleanExtra("isHourly", true)
        hours = intent.getIntExtra("selectedHours", 1)

        val ivBike = findViewById<ImageView>(R.id.ivBikeImage)
        val tvName = findViewById<TextView>(R.id.tvBikeName)
        val tvType = findViewById<TextView>(R.id.tvBikeType)
        val tvLocation = findViewById<TextView>(R.id.tvBikeLocation)
        val btnMaps = findViewById<Button>(R.id.btnOpenMaps)

        val etUser = findViewById<EditText>(R.id.etUserName)
        val etLicense = findViewById<EditText>(R.id.etLicense)
        val etMobile = findViewById<EditText>(R.id.etMobile)
        val etEmail = findViewById<EditText>(R.id.etEmail)
        val btnNext = findViewById<Button>(R.id.btnNext)

        bike?.let { b ->
            ivBike.setImageResource(b.getBikeImageRes())
            tvName.text = b.name
            tvType.text = b.type
            tvLocation.text = b.location
            btnMaps.setOnClickListener {
                val uri = Uri.parse("geo:0,0?q=" + Uri.encode(b.location))
                startActivity(Intent(Intent.ACTION_VIEW, uri))
            }
        }

        btnNext.setOnClickListener {
            val name = etUser.text.toString().trim()
            val lic = etLicense.text.toString().trim()
            val mob = etMobile.text.toString().trim()
            val email = etEmail.text.toString().trim()
            if (name.isEmpty() || lic.isEmpty() || mob.length < 10) {
                android.widget.Toast.makeText(this, "Please enter valid details", android.widget.Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            val i = Intent(this, PaymentActivity::class.java)
            i.putExtra("bike", bike)
            i.putExtra("isHourly", isHourly)
            i.putExtra("selectedHours", hours)
            i.putExtra("userName", name)
            i.putExtra("licenseNumber", lic)
            i.putExtra("mobileNumber", mob)
            i.putExtra("email", email)
            startActivity(i)
            finish()
        }
    }
}












