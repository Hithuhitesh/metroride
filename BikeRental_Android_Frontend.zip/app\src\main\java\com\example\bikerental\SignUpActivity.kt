package com.example.bikerental

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.bikerental.databinding.ActivitySignupBinding

class SignUpActivity : AppCompatActivity() {
    private lateinit var binding: ActivitySignupBinding
    private var currentRole: String = "user"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySignupBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Initialize UserManager
        UserManager.initialize(this)

        // Get the role from intent
        currentRole = intent.getStringExtra("role") ?: "user"
        
        // Add entrance animations
        addEntranceAnimations()

        setupClickListeners()
        updateUIForRole()
    }

    private fun updateUIForRole() {
        val roleText = if (currentRole == "admin") "Admin" else "User"
        binding.tvRoleIndicator.text = "$roleText Account"
        binding.tvSignUpSubtitle.text = "Create your $roleText account to continue"
    }

    private fun setupClickListeners() {
        binding.btnCreateAccount.setOnClickListener {
            if (validateForm()) {
                performSignUp()
            }
        }

        binding.tvBackToLogin.setOnClickListener {
            // Go back to login page
            val intent = Intent(this, LoginActivity::class.java)
            intent.putExtra("role", currentRole)
            startActivity(intent)
            finish()
        }
    }

    private fun validateForm(): Boolean {
        val name = binding.etName.text.toString().trim()
        val email = binding.etEmail.text.toString().trim()
        val password = binding.etPassword.text.toString().trim()
        val phone = binding.etPhone.text.toString().trim()

        var isValid = true

        if (name.isEmpty()) {
            binding.etName.error = "Name is required"
            isValid = false
        }

        if (email.isEmpty()) {
            binding.etEmail.error = "Email is required"
            isValid = false
        } else if (!android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            binding.etEmail.error = "Please enter a valid email"
            isValid = false
        }

        if (password.isEmpty()) {
            binding.etPassword.error = "Password is required"
            isValid = false
        } else if (password.length < 6) {
            binding.etPassword.error = "Password must be at least 6 characters"
            isValid = false
        }

        // Phone number is optional, but if provided, it should be valid
        if (phone.isNotEmpty() && phone.length < 10) {
            binding.etPhone.error = "Please enter a valid phone number"
            isValid = false
        }

        return isValid
    }

    private fun performSignUp() {
        val name = binding.etName.text.toString().trim()
        val email = binding.etEmail.text.toString().trim()
        val password = binding.etPassword.text.toString().trim()
        val phone = binding.etPhone.text.toString().trim()

        // Use UserManager for registration
        if (UserManager.registerUser(name, email, password, phone, currentRole)) {
            // Registration successful
            Toast.makeText(this, "Account created successfully! Welcome, $name!", Toast.LENGTH_SHORT).show()
            startActivity(Intent(this, MainActivity::class.java))
            finish()
        } else {
            // Registration failed - email already exists
            Toast.makeText(this, "An account with this email already exists", Toast.LENGTH_SHORT).show()
        }
    }

    private fun addEntranceAnimations() {
        // Simple fade in for the card
        binding.root.findViewById<androidx.cardview.widget.CardView>(R.id.cardView)?.alpha = 0f
        binding.root.findViewById<androidx.cardview.widget.CardView>(R.id.cardView)?.animate()?.alpha(1f)?.setDuration(800)?.start()
    }
} 