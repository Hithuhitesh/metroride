package com.example.bikerental

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.viewpager2.widget.ViewPager2
import com.google.android.material.tabs.TabLayout
import com.google.android.material.tabs.TabLayoutMediator
import androidx.fragment.app.FragmentActivity
import androidx.viewpager2.adapter.FragmentStateAdapter
import android.app.AlertDialog
import com.example.bikerental.BookingRepository
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class AdminDashboardFragment : Fragment() {
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_admin_dashboard, container, false)
        val tabLayout = view.findViewById<TabLayout>(R.id.tabLayout)
        val viewPager = view.findViewById<ViewPager2>(R.id.viewPager)
        viewPager.adapter = AdminPagerAdapter(this)
        val tabTitles = listOf(
            "Pending Listings",
            "Booking History",
            "Theft Reports",
            "Earnings Dashboard",
            "Violations & Fines",
            "Manage Listings",
            "Maintenance"
        )
        TabLayoutMediator(tabLayout, viewPager) { tab, position ->
            tab.text = tabTitles[position]
        }.attach()
        return view
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        // Overdue return alert for admins
        val overdue = BookingRepository.allBookings.filter {
            try {
                val fmt = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
                val end = fmt.parse(it.endDate)
                it.status == "Active" && end != null && Date().after(end)
            } catch (_: Exception) { false }
        }
        if (overdue.isNotEmpty()) {
            val msg = overdue.joinToString("\n\n") { b ->
                "Bike: ${b.bikeName}\nRenter: ${b.renterName}\nDue: ${b.endDate}"
            }
            AlertDialog.Builder(requireContext())
                .setTitle("Overdue Bikes Alert!")
                .setMessage("The following bikes are overdue and not returned in time:\n\n$msg")
                .setPositiveButton("OK") { d, _ -> d.dismiss() }
                .show()
        }
    }
}

class AdminPagerAdapter(fragment: Fragment) : FragmentStateAdapter(fragment) {
    override fun getItemCount() = 7
    override fun createFragment(position: Int): Fragment = when (position) {
        0 -> PendingListingsFragment()
        1 -> BookingHistoryFragment()
        2 -> TheftReportsFragment()
        3 -> EarningsDashboardFragment()
        4 -> ViolationsFinesFragment()
        5 -> MyBikesFragment()
        6 -> MaintenanceBikeManagerFragment()
        else -> Fragment()
    }
} 