package com.example.bikerental

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class LocationSuggestionAdapter(
    private var suggestions: List<LocationSuggestion>,
    private val onItemClick: (LocationSuggestion) -> Unit
) : RecyclerView.Adapter<LocationSuggestionAdapter.ViewHolder>() {

    data class LocationSuggestion(
        val name: String,
        val type: String,
        val fullAddress: String
    )

    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val tvLocationName: TextView = itemView.findViewById(R.id.tvLocationName)
        val tvLocationType: TextView = itemView.findViewById(R.id.tvLocationType)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_location_suggestion, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val suggestion = suggestions[position]
        holder.tvLocationName.text = suggestion.name
        holder.tvLocationType.text = suggestion.type
        
        holder.itemView.setOnClickListener {
            onItemClick(suggestion)
        }
    }

    override fun getItemCount(): Int = suggestions.size

    fun updateSuggestions(newSuggestions: List<LocationSuggestion>) {
        suggestions = newSuggestions
        notifyDataSetChanged()
    }
} 