package com.example.bikerental

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import android.widget.Button
import androidx.appcompat.app.AlertDialog
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.switchmaterial.SwitchMaterial

class MyBikesFragment : Fragment() {
    private lateinit var adapter: MyBikesAdapter
    private var allBikes = listOf<Bike>()
    private var filteredBikes = listOf<Bike>()
    
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return try {
        val view = inflater.inflate(R.layout.fragment_my_bikes, container, false)
        val recyclerView = view.findViewById<RecyclerView>(R.id.rvMyBikes)
            recyclerView.layoutManager = LinearLayoutManager(requireContext())

            // Set test user email for demo purposes
            setTestUserEmail()

            // Filter buttons
            val btnAll = view.findViewById<View>(R.id.btnAllAdmin)
            val btnActive = view.findViewById<View>(R.id.btnActiveAdmin)
            val btnMaintenance = view.findViewById<View>(R.id.btnMaintenanceAdmin)
            val btnBooked = view.findViewById<View>(R.id.btnBookedAdmin)
            val chipButtons = listOf(btnAll, btnActive, btnMaintenance, btnBooked)
            
            // Get all bikes
            allBikes = getAllBikes()
            filteredBikes = allBikes
            
            android.util.Log.d("MyBikesFragment", "Total bikes loaded: ${allBikes.size}")
            android.util.Log.d("MyBikesFragment", "Filtered bikes: ${filteredBikes.size}")
            
            val isAdmin = UserManager.getCurrentUserRole() == "admin"
            adapter = MyBikesAdapter(filteredBikes) { bike -> showBikeDetailsDialog(bike) }
            recyclerView.adapter = adapter
            if (isAdmin) {
                // swap item layout by attaching a simple view holder factory through adapter: using the existing adapter inflates item_bike_card by default.
                // Instead, we set a different layout manager to fake a table: keep same adapter but inflate admin row by detecting admin in bind (already handled).
            }

            // Update stats
            updateStats()

            fun setActiveChip(active: View) {
                chipButtons.forEach { btn ->
                    val isSelected = btn == active
                    btn.isSelected = isSelected
                    if (isSelected) {
                        btn.setBackgroundResource(R.drawable.bg_chip_selected)
                        (btn as? androidx.appcompat.widget.AppCompatButton)?.setTextColor(resources.getColor(android.R.color.white))
                    } else {
                        btn.setBackgroundResource(R.drawable.bg_chip_unselected)
                        (btn as? androidx.appcompat.widget.AppCompatButton)?.setTextColor(resources.getColor(R.color.purple))
                    }
                }
            }

            fun filterBikes(status: String) {
                filteredBikes = when (status) {
                    "All" -> allBikes
                    "Active" -> allBikes.filter { !it.underMaintenance }
                    "Maintenance" -> allBikes.filter { it.underMaintenance }
                    "Booked" -> allBikes.filter { bike ->
                        // Check if bike is currently booked (you can implement your own booking logic)
                        false // For now, return empty list - implement based on your booking system
                    }
                    else -> allBikes
                }
                adapter.updateList(filteredBikes)
            }

            (btnAll as androidx.appcompat.widget.AppCompatButton).setOnClickListener {
                filterBikes("All")
                setActiveChip(btnAll)
            }
            (btnActive as androidx.appcompat.widget.AppCompatButton).setOnClickListener {
                filterBikes("Active")
                setActiveChip(btnActive)
            }
            (btnMaintenance as androidx.appcompat.widget.AppCompatButton).setOnClickListener {
                filterBikes("Maintenance")
                setActiveChip(btnMaintenance)
            }
            (btnBooked as androidx.appcompat.widget.AppCompatButton).setOnClickListener {
                filterBikes("Booked")
                setActiveChip(btnBooked)
            }

            setActiveChip(btnAll)

            // Floating Action Button for adding new bike
            view.findViewById<com.google.android.material.floatingactionbutton.FloatingActionButton>(R.id.fabAddBike)?.setOnClickListener {
                showAddBikeDialog()
            }


            view
        } catch (e: Exception) {
            android.util.Log.e("MyBikesFragment", "Error in onCreateView: ${e.message}")
            // Return a simple error view
            val errorView = TextView(requireContext())
            errorView.text = "Error loading bikes. Please try again."
            errorView.gravity = android.view.Gravity.CENTER
            errorView.setTextColor(android.graphics.Color.RED)
            errorView
        }
    }

    // Set test user email for demo purposes
    private fun setTestUserEmail() {
        // Initialize UserManager if not already done
        UserManager.initialize(requireContext())
        
        // Check if we have a logged-in user
        if (!UserManager.isLoggedIn()) {
            // Create a demo admin user if no user is logged in
            UserManager.registerUser(
                name = "Demo Admin",
                email = "admin@example.com",
                password = "admin123",
                phone = "+91 9876543210",
                role = "admin"
            )
        }
    }

    // Get bikes from repository filtered by current user
    private fun getAllBikes(): List<Bike> {
        // Initialize UserManager if not already done
        UserManager.initialize(requireContext())
        
        val userEmail = UserManager.getCurrentUserEmail()
        val isAdmin = UserManager.getCurrentUserRole() == "admin"
        
        android.util.Log.d("MyBikesFragment", "Getting bikes for user: $userEmail, isAdmin: $isAdmin")
        
        // For admin users, show all bikes (limit to 3 for demo)
        // For regular users, filter by owner ID
        val bikes = if (isAdmin) {
            BikeRepository.allBikes
        } else {
            BikeRepository.allBikes.filter { it.ownerId == userEmail }
        }
        // Deduplicate by registration number if present, else by id
        val unique = LinkedHashMap<String, Bike>()
        for (b in bikes) {
            val key = if (b.registrationNumber.isNotBlank()) b.registrationNumber else b.id
            if (!unique.containsKey(key)) unique[key] = b
        }
        var deduped = unique.values.toList()
        // For admins, limit to 3 bikes to reflect realistic inventory on demo
        if (isAdmin) {
            deduped = deduped.take(3)
        }
        
        android.util.Log.d("MyBikesFragment", "Found ${bikes.size} bikes for user: $userEmail")
        bikes.forEach { bike ->
            android.util.Log.d("MyBikesFragment", "Bike: ${bike.name} - Owner: ${bike.ownerId}")
        }
        
        // If no bikes found for admin, show admin bikes as fallback
        if (isAdmin && bikes.isEmpty()) {
            android.util.Log.d("MyBikesFragment", "No bikes found for admin, showing admin bikes as fallback")
            val adminBikes = BikeRepository.allBikes.filter { it.ownerId == "admin@demo.com" }
            android.util.Log.d("MyBikesFragment", "Fallback: Found ${adminBikes.size} admin bikes")
            return adminBikes
        }
        
        return deduped
    }

    private fun updateStats() {
        try {
            // Stats should represent what is actually shown in the list
            val source = if (filteredBikes.isNotEmpty()) filteredBikes else allBikes
            val totalBikes = source.size
            val availableBikes = source.count { !it.underMaintenance }
            val maintenanceBikes = source.count { it.underMaintenance }

            view?.findViewById<TextView>(R.id.tvTotalBikes)?.text = totalBikes.toString()
            view?.findViewById<TextView>(R.id.tvAvailableBikes)?.text = availableBikes.toString()
            view?.findViewById<TextView>(R.id.tvMaintenanceBikes)?.text = maintenanceBikes.toString()
        } catch (e: Exception) {
            android.util.Log.e("MyBikesFragment", "Error updating stats: ${e.message}")
        }
    }
    
    private fun showBikeDetailsDialog(bike: Bike) {
        try {
            val dialogView = LayoutInflater.from(requireContext()).inflate(R.layout.dialog_bike_details, null)
            
            // Set bike image
            dialogView.findViewById<ImageView>(R.id.ivBikeImage).setImageResource(bike.getBikeImageRes())
            
            // Set basic info
            dialogView.findViewById<TextView>(R.id.tvBikeName).text = bike.name
            dialogView.findViewById<TextView>(R.id.tvBikeType).text = bike.type.uppercase()
            dialogView.findViewById<TextView>(R.id.tvBikePrice).text = bike.getFormattedPrice() + "/hour"
            
            // Set status and rating
            val statusText = dialogView.findViewById<TextView>(R.id.tvStatus)
            if (bike.underMaintenance) {
                statusText.text = "MAINTENANCE"
                statusText.setBackgroundResource(R.drawable.bg_status_maintenance)
                statusText.setTextColor(0xFFE65100.toInt())
            } else {
                statusText.text = "AVAILABLE"
                statusText.setBackgroundResource(R.drawable.bg_status_available)
                statusText.setTextColor(0xFF10B981.toInt())
            }
            
            dialogView.findViewById<TextView>(R.id.tvRating).text = "⭐ ${bike.rating} (${bike.reviewCount} reviews)"
            
            // Set details
            dialogView.findViewById<TextView>(R.id.tvLocation).text = bike.getFullAddress()
            dialogView.findViewById<TextView>(R.id.tvModel).text = "${bike.year} ${bike.model}"
            dialogView.findViewById<TextView>(R.id.tvFuelType).text = bike.fuelType
            dialogView.findViewById<TextView>(R.id.tvDeposit).text = bike.getFormattedDeposit()
            
            // Set features
            val helmetText = dialogView.findViewById<TextView>(R.id.tvHelmet)
            val insuranceText = dialogView.findViewById<TextView>(R.id.tvInsurance)
            
            if (bike.helmetProvided) {
                helmetText.text = "🪖 Helmet: Included"
                helmetText.setTextColor(0xFF10B981.toInt())
                helmetText.setBackgroundResource(R.drawable.bg_feature_available)
            } else {
                helmetText.text = "🪖 Helmet: Not Included"
                helmetText.setTextColor(0xFFEF4444.toInt())
                helmetText.setBackgroundResource(R.drawable.bg_status_maintenance)
            }
            
            if (bike.insuranceIncluded) {
                insuranceText.text = "🛡️ Insurance: Included"
                insuranceText.setTextColor(0xFF10B981.toInt())
                insuranceText.setBackgroundResource(R.drawable.bg_feature_available)
            } else {
                insuranceText.text = "🛡️ Insurance: Not Included"
                insuranceText.setTextColor(0xFFEF4444.toInt())
                insuranceText.setBackgroundResource(R.drawable.bg_status_maintenance)
            }
            
            // Set description
            dialogView.findViewById<TextView>(R.id.tvDescription).text = bike.description
            
            // Create dialog
            val dialog = AlertDialog.Builder(requireContext())
                .setView(dialogView)
                .create()
            
            // Set button click listeners
            dialogView.findViewById<Button>(R.id.btnEdit).setOnClickListener {
                dialog.dismiss()
                showEditBikeDialog(bike)
            }
            
            dialogView.findViewById<Button>(R.id.btnToggleMaintenance).setOnClickListener {
                bike.toggleMaintenance()
                Toast.makeText(
                    requireContext(), 
                    if (bike.underMaintenance) "${bike.name} is now under maintenance" else "${bike.name} is now available",
                    Toast.LENGTH_SHORT
                ).show()
                adapter.notifyDataSetChanged()
                updateStats()
                dialog.dismiss()
            }

            dialogView.findViewById<Button>(R.id.btnDelete).setOnClickListener {
                showDeleteConfirmationDialog(bike, dialog)
            }
            
            dialog.show()
        } catch (e: Exception) {
            android.util.Log.e("MyBikesFragment", "Error showing bike details dialog: ${e.message}")
            Toast.makeText(requireContext(), "Error loading bike details", Toast.LENGTH_SHORT).show()
        }
    }

    private fun showEditBikeDialog(bike: Bike) {
        val dialogView = LayoutInflater.from(requireContext()).inflate(R.layout.dialog_edit_bike, null)
        
        // Populate fields with current bike data
        dialogView.findViewById<TextInputEditText>(R.id.etBikeName).setText(bike.name)
        dialogView.findViewById<TextInputEditText>(R.id.etBikeType).setText(bike.type)
        dialogView.findViewById<TextInputEditText>(R.id.etPrice).setText(bike.price.toString())
        dialogView.findViewById<TextInputEditText>(R.id.etAddress).setText(bike.address)
        dialogView.findViewById<TextInputEditText>(R.id.etCity).setText(bike.city)
        dialogView.findViewById<TextInputEditText>(R.id.etPincode).setText(bike.pincode)
        dialogView.findViewById<TextInputEditText>(R.id.etLandmark).setText(bike.landmark)
        dialogView.findViewById<TextInputEditText>(R.id.etYear).setText(bike.year.toString())
        dialogView.findViewById<TextInputEditText>(R.id.etModel).setText(bike.model)
        dialogView.findViewById<TextInputEditText>(R.id.etFuelType).setText(bike.fuelType)
        dialogView.findViewById<TextInputEditText>(R.id.etDepositAmount).setText(bike.depositAmount.toString())
        dialogView.findViewById<TextInputEditText>(R.id.etDescription).setText(bike.description)
        
        // Set switches
        dialogView.findViewById<SwitchMaterial>(R.id.switchHelmet).isChecked = bike.helmetProvided
        dialogView.findViewById<SwitchMaterial>(R.id.switchInsurance).isChecked = bike.insuranceIncluded
        
        // Create dialog
        val dialog = AlertDialog.Builder(requireContext())
            .setView(dialogView)
            .create()
        
        // Set button click listeners
        dialogView.findViewById<Button>(R.id.btnCancel).setOnClickListener {
            dialog.dismiss()
        }
        
        dialogView.findViewById<Button>(R.id.btnSave).setOnClickListener {
            // Validate and save changes
            val bikeName = dialogView.findViewById<TextInputEditText>(R.id.etBikeName).text.toString()
            val bikeType = dialogView.findViewById<TextInputEditText>(R.id.etBikeType).text.toString()
            val priceStr = dialogView.findViewById<TextInputEditText>(R.id.etPrice).text.toString()
            val address = dialogView.findViewById<TextInputEditText>(R.id.etAddress).text.toString()
            val city = dialogView.findViewById<TextInputEditText>(R.id.etCity).text.toString()
            val pincode = dialogView.findViewById<TextInputEditText>(R.id.etPincode).text.toString()
            val landmark = dialogView.findViewById<TextInputEditText>(R.id.etLandmark).text.toString()
            val yearStr = dialogView.findViewById<TextInputEditText>(R.id.etYear).text.toString()
            val model = dialogView.findViewById<TextInputEditText>(R.id.etModel).text.toString()
            val fuelType = dialogView.findViewById<TextInputEditText>(R.id.etFuelType).text.toString()
            val depositStr = dialogView.findViewById<TextInputEditText>(R.id.etDepositAmount).text.toString()
            val description = dialogView.findViewById<TextInputEditText>(R.id.etDescription).text.toString()
            val helmetProvided = dialogView.findViewById<SwitchMaterial>(R.id.switchHelmet).isChecked
            val insuranceIncluded = dialogView.findViewById<SwitchMaterial>(R.id.switchInsurance).isChecked
            
            // Validate required fields
            if (bikeName.isBlank() || bikeType.isBlank() || priceStr.isBlank()) {
                Toast.makeText(requireContext(), "Please fill in all required fields", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            
            try {
                val price = priceStr.toInt()
                val year = yearStr.toIntOrNull() ?: 0
                val deposit = depositStr.toIntOrNull() ?: 0
                
                // Update bike object
                bike.name = bikeName
                bike.type = bikeType
                bike.price = price
                bike.address = address
                bike.city = city
                bike.pincode = pincode
                bike.landmark = landmark
                bike.year = year
                bike.model = model
                bike.fuelType = fuelType
                bike.depositAmount = deposit
                bike.description = description
                bike.helmetProvided = helmetProvided
                bike.insuranceIncluded = insuranceIncluded
                
                // Update the bike in repository
                val bikeIndex = BikeRepository.allBikes.indexOfFirst { it.id == bike.id }
                if (bikeIndex != -1) {
                    BikeRepository.allBikes[bikeIndex] = bike
                }
                
                Toast.makeText(requireContext(), "Bike details updated successfully!", Toast.LENGTH_SHORT).show()
                adapter.notifyDataSetChanged()
                updateStats()
                dialog.dismiss()
                
            } catch (e: NumberFormatException) {
                Toast.makeText(requireContext(), "Please enter valid numbers for price and year", Toast.LENGTH_SHORT).show()
            }
        }
        
        dialog.show()
    }

    private fun showAddBikeDialog() {
        val dialogView = LayoutInflater.from(requireContext()).inflate(R.layout.dialog_edit_bike, null)
        
        // Clear all fields for new bike
        dialogView.findViewById<TextInputEditText>(R.id.etBikeName).setText("")
        dialogView.findViewById<TextInputEditText>(R.id.etBikeType).setText("")
        dialogView.findViewById<TextInputEditText>(R.id.etPrice).setText("")
        dialogView.findViewById<TextInputEditText>(R.id.etAddress).setText("")
        dialogView.findViewById<TextInputEditText>(R.id.etCity).setText("Chennai")
        dialogView.findViewById<TextInputEditText>(R.id.etPincode).setText("")
        dialogView.findViewById<TextInputEditText>(R.id.etLandmark).setText("")
        dialogView.findViewById<TextInputEditText>(R.id.etYear).setText("2023")
        dialogView.findViewById<TextInputEditText>(R.id.etModel).setText("")
        dialogView.findViewById<TextInputEditText>(R.id.etFuelType).setText("Petrol")
        dialogView.findViewById<TextInputEditText>(R.id.etDepositAmount).setText("1000")
        dialogView.findViewById<TextInputEditText>(R.id.etDescription).setText("")
        
        // Set default switches
        dialogView.findViewById<SwitchMaterial>(R.id.switchHelmet).isChecked = true
        dialogView.findViewById<SwitchMaterial>(R.id.switchInsurance).isChecked = false
        
        // Create dialog
        val dialog = AlertDialog.Builder(requireContext())
            .setView(dialogView)
            .create()
        
        // Set button click listeners
        dialogView.findViewById<Button>(R.id.btnCancel).setOnClickListener {
            dialog.dismiss()
        }
        
        dialogView.findViewById<Button>(R.id.btnSave).setOnClickListener {
            // Validate and save new bike
            val bikeName = dialogView.findViewById<TextInputEditText>(R.id.etBikeName).text.toString()
            val bikeType = dialogView.findViewById<TextInputEditText>(R.id.etBikeType).text.toString()
            val priceStr = dialogView.findViewById<TextInputEditText>(R.id.etPrice).text.toString()
            val address = dialogView.findViewById<TextInputEditText>(R.id.etAddress).text.toString()
            val city = dialogView.findViewById<TextInputEditText>(R.id.etCity).text.toString()
            val pincode = dialogView.findViewById<TextInputEditText>(R.id.etPincode).text.toString()
            val landmark = dialogView.findViewById<TextInputEditText>(R.id.etLandmark).text.toString()
            val yearStr = dialogView.findViewById<TextInputEditText>(R.id.etYear).text.toString()
            val model = dialogView.findViewById<TextInputEditText>(R.id.etModel).text.toString()
            val fuelType = dialogView.findViewById<TextInputEditText>(R.id.etFuelType).text.toString()
            val depositStr = dialogView.findViewById<TextInputEditText>(R.id.etDepositAmount).text.toString()
            val description = dialogView.findViewById<TextInputEditText>(R.id.etDescription).text.toString()
            val helmetProvided = dialogView.findViewById<SwitchMaterial>(R.id.switchHelmet).isChecked
            val insuranceIncluded = dialogView.findViewById<SwitchMaterial>(R.id.switchInsurance).isChecked
            
            // Validate required fields
            if (bikeName.isBlank() || bikeType.isBlank() || priceStr.isBlank()) {
                Toast.makeText(requireContext(), "Please fill in all required fields", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            
            try {
                val price = priceStr.toInt()
                val year = yearStr.toIntOrNull() ?: 2023
                val deposit = depositStr.toIntOrNull() ?: 1000
                
                // Create new bike
                val newBike = Bike(
                    id = "bike_${System.currentTimeMillis()}",
                    name = bikeName,
                    type = bikeType,
                    location = city,
                    price = price,
                    rating = 4.0f,
                    reviewCount = 0,
                    pickupMode = "manual",
                    ownerId = "user@example.com",
                    ratings = mutableListOf(),
                    underMaintenance = false,
                    address = address,
                    city = city,
                    pincode = pincode,
                    landmark = landmark,
                    year = year,
                    model = model,
                    fuelType = fuelType,
                    helmetProvided = helmetProvided,
                    insuranceIncluded = insuranceIncluded,
                    depositAmount = deposit,
                    description = description,
                    ownerPhone = "+91 9876543210"
                )
                
                // Add to repository
                BikeRepository.allBikes.add(newBike)
                
                // Update lists
                allBikes = getAllBikes()
                filteredBikes = allBikes
                adapter.updateList(filteredBikes)
                updateStats()
                
                Toast.makeText(requireContext(), "New bike added successfully!", Toast.LENGTH_SHORT).show()
                dialog.dismiss()
                
            } catch (e: NumberFormatException) {
                Toast.makeText(requireContext(), "Please enter valid numbers for price and year", Toast.LENGTH_SHORT).show()
            }
        }
        
        dialog.show()
    }

    private fun showDeleteConfirmationDialog(bike: Bike, parentDialog: AlertDialog) {
        AlertDialog.Builder(requireContext())
            .setTitle("Delete Bike")
            .setMessage("Are you sure you want to delete ${bike.name}? This action cannot be undone.")
            .setPositiveButton("Delete") { _, _ ->
                // Remove bike from repository
                BikeRepository.allBikes.removeAll { it.id == bike.id }
                
                // Update the filtered list
                allBikes = getAllBikes()
                filteredBikes = allBikes
                adapter.updateList(filteredBikes)
                updateStats()
                
                Toast.makeText(requireContext(), "${bike.name} has been deleted", Toast.LENGTH_SHORT).show()
                parentDialog.dismiss()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
}

class MyBikesAdapter(
    private var bikes: List<Bike>,
    private val onBikeClick: (Bike) -> Unit
) : RecyclerView.Adapter<MyBikesAdapter.BikeViewHolder>() {
    
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): BikeViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_bike_card, parent, false)
        return BikeViewHolder(view)
    }
    
    override fun onBindViewHolder(holder: BikeViewHolder, position: Int) {
        holder.bind(bikes[position])
    }
    
    override fun getItemCount() = bikes.size

    fun updateList(newList: List<Bike>) {
        bikes = newList
        notifyDataSetChanged()
    }

    inner class BikeViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        fun bind(bike: Bike) {
            // Regular bike card view for all users
            itemView.findViewById<ImageView>(R.id.ivBikeImage).setImageResource(bike.getBikeImageRes())
            itemView.findViewById<TextView>(R.id.tvBikeName).text = bike.name
            itemView.findViewById<TextView>(R.id.tvBikeType).text = bike.type.uppercase()
            
            val statusText = itemView.findViewById<TextView>(R.id.tvStatus)
            if (bike.underMaintenance) {
                statusText.text = "MAINTENANCE"
                statusText.setBackgroundResource(R.drawable.bg_status_maintenance)
                statusText.setTextColor(0xFFE65100.toInt())
            } else {
                statusText.text = "AVAILABLE"
                statusText.setBackgroundResource(R.drawable.bg_status_available)
                statusText.setTextColor(0xFF10B981.toInt())
            }
            
            itemView.setOnClickListener { onBikeClick(bike) }
        }
    }
} 