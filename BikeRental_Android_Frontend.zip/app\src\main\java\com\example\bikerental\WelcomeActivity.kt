package com.example.bikerental

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import com.example.bikerental.databinding.ActivityWelcomeBinding
import android.widget.Toast
import android.content.SharedPreferences
import android.os.Handler
import android.os.Looper

class WelcomeActivity : AppCompatActivity() {
    private lateinit var binding: ActivityWelcomeBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityWelcomeBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Start animations
        startAnimations()

        // Set up button click listeners
        setupClickListeners()
    }

    private fun startAnimations() {
        // Simple fade in for logo (using system animation)
        binding.logo.alpha = 0f
        binding.logo.animate().alpha(1f).setDuration(1000).start()
    }

    private fun setupClickListeners() {
        binding.btnGetStarted.setOnClickListener {
            // Navigate to role selection
            val intent = Intent(this, RoleSelectActivity::class.java)
            startActivity(intent)
            finish()
        }

        binding.btnLearnMore.setOnClickListener {
            // Show learn more dialog
            Toast.makeText(this, "Learn more about Metro Ride!", Toast.LENGTH_SHORT).show()
        }
    }
} 