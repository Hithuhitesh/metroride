package com.example.bikerental

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.bikerental.databinding.ActivityRoleSelectBinding

class RoleSelectActivity : AppCompatActivity() {
    private lateinit var binding: ActivityRoleSelectBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRoleSelectBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnContinueUser.setOnClickListener {
            // Navigate to login page for users
            val intent = Intent(this, LoginActivity::class.java)
            intent.putExtra("role", "user")
            startActivity(intent)
            finish()
        }
        binding.btnContinueAdmin.setOnClickListener {
            // Navigate to login page for admins
            val intent = Intent(this, LoginActivity::class.java)
            intent.putExtra("role", "admin")
            startActivity(intent)
            finish()
        }
    }
} 