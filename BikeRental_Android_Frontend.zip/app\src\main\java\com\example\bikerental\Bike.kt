package com.example.bikerental

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class Bike(
    val id: String,
    var name: String,
    var type: String = "Bike",
    var location: String = "Chennai",
    var price: Int = 50,
    val imageRes: Int = android.R.drawable.ic_menu_mylocation,
    val rating: Float = 4.2f,
    val reviewCount: Int = 15,
    val pickupMode: String = "manual", // "manual", "smart_lock", or "station"
    val ownerId: String = "",
    val ratings: MutableList<Float> = mutableListOf(),
    var underMaintenance: Boolean = false,
    val imageUrl: String? = null,
    
    // Essential Location Information
    var address: String = "",
    var city: String = "",
    var pincode: String = "",
    var landmark: String = "",
    
    // Basic Bike Details
    var year: Int = 0,
    var model: String = "",
    var fuelType: String = "", // "Petrol", "Electric", "Hybrid"
    // Real-world important specs
    var engineCc: Int? = null,           // for ICE bikes
    var batteryCapacityKwh: Float? = null, // for EVs
    var engineType: String = "",         // e.g., V-Twin, Single-cylinder
    var fuelCapacityLiters: Float? = null, // e.g., 13.1 L
    var topSpeedKmph: Int? = null,        // e.g., 180 kmph
    var powerHp: Float? = null,
    var torqueNm: Float? = null,
    var rangeKm: Int? = null,            // EV real-world range
    var mileageKmpl: Float? = null,      // for ICE
    
    // Simple Safety Features
    var helmetProvided: Boolean = false,
    var insuranceIncluded: Boolean = false,
    
    // Basic Rental Info
    var depositAmount: Int = 0,
    var description: String = "",
    val ownerPhone: String = "",
    // Admin/host management fields
    var registrationNumber: String = "",
    var availabilityStatus: String = "Inactive", // Available, Rented, Inactive
    var verificationStatus: String = "Pending" // Pending, Approved, Blocked
) : Parcelable {
    fun withDefaultsForKnownBike(): Bike {
        // Return a copy enriched with known real-world specs when missing
        val b = this.copy()
        when (name.lowercase()) {
            "ather 450x" -> {
                if (b.model.isEmpty()) b.model = "450X Gen 3"
                if (b.year == 0) b.year = 2023
                if (b.fuelType.isEmpty()) b.fuelType = "Electric"
                if (b.batteryCapacityKwh == null) b.batteryCapacityKwh = 3.7f
                if (b.rangeKm == null) b.rangeKm = 146
                if (b.topSpeedKmph == null) b.topSpeedKmph = 90
                if (b.powerHp == null) b.powerHp = 8.7f
                if (b.torqueNm == null) b.torqueNm = 26f
            }
            "tvs jupiter" -> {
                if (b.model.isEmpty()) b.model = "Jupiter 110"
                if (b.year == 0) b.year = 2022
                if (b.fuelType.isEmpty()) b.fuelType = "Petrol"
                if (b.engineCc == null) b.engineCc = 109
                if (b.mileageKmpl == null) b.mileageKmpl = 45f
                if (b.fuelCapacityLiters == null) b.fuelCapacityLiters = 6.0f
                if (b.topSpeedKmph == null) b.topSpeedKmph = 85
            }
            "bajaj pulsar 150" -> {
                if (b.model.isEmpty()) b.model = "Pulsar 150"
                if (b.year == 0) b.year = 2022
                if (b.fuelType.isEmpty()) b.fuelType = "Petrol"
                if (b.engineCc == null) b.engineCc = 149
                if (b.powerHp == null) b.powerHp = 14.0f
                if (b.torqueNm == null) b.torqueNm = 13.2f
                if (b.mileageKmpl == null) b.mileageKmpl = 47f
                if (b.topSpeedKmph == null) b.topSpeedKmph = 110
            }
            "yamaha mt-15" -> {
                if (b.model.isEmpty()) b.model = "MT-15 V2"
                if (b.year == 0) b.year = 2023
                if (b.fuelType.isEmpty()) b.fuelType = "Petrol"
                if (b.engineCc == null) b.engineCc = 155
                if (b.powerHp == null) b.powerHp = 18.4f
                if (b.torqueNm == null) b.torqueNm = 14.1f
                if (b.mileageKmpl == null) b.mileageKmpl = 45f
                if (b.topSpeedKmph == null) b.topSpeedKmph = 130
            }
            "suzuki access 125" -> {
                if (b.model.isEmpty()) b.model = "Access 125"
                if (b.year == 0) b.year = 2023
                if (b.fuelType.isEmpty()) b.fuelType = "Petrol"
                if (b.engineCc == null) b.engineCc = 124
                if (b.mileageKmpl == null) b.mileageKmpl = 45f
                if (b.fuelCapacityLiters == null) b.fuelCapacityLiters = 5.0f
            }
            "hero splendor plus" -> {
                if (b.model.isEmpty()) b.model = "Splendor Plus"
                if (b.year == 0) b.year = 2022
                if (b.fuelType.isEmpty()) b.fuelType = "Petrol"
                if (b.engineCc == null) b.engineCc = 97
                if (b.mileageKmpl == null) b.mileageKmpl = 60f
                if (b.topSpeedKmph == null) b.topSpeedKmph = 90
            }
            "bajaj avenger" -> {
                if (b.model.isEmpty()) b.model = "Avenger 220 Cruise"
                if (b.year == 0) b.year = 2021
                if (b.fuelType.isEmpty()) b.fuelType = "Petrol"
                if (b.engineCc == null) b.engineCc = 220
                if (b.powerHp == null) b.powerHp = 19.0f
                if (b.torqueNm == null) b.torqueNm = 17.5f
            }
            "bajaj avenger street 160" -> {
                if (b.model.isEmpty()) b.model = "Avenger Street 160"
                if (b.year == 0) b.year = 2022
                if (b.fuelType.isEmpty()) b.fuelType = "Petrol"
                if (b.engineCc == null) b.engineCc = 160
                if (b.powerHp == null) b.powerHp = 15.0f
                if (b.torqueNm == null) b.torqueNm = 13.7f
                if (b.topSpeedKmph == null) b.topSpeedKmph = 105
            }
            "honda unicorn 150" -> {
                if (b.model.isEmpty()) b.model = "Unicorn 150"
                if (b.year == 0) b.year = 2022
                if (b.fuelType.isEmpty()) b.fuelType = "Petrol"
                if (b.engineCc == null) b.engineCc = 149
                if (b.engineType.isEmpty()) b.engineType = "Single-cylinder, Air-cooled"
                if (b.fuelCapacityLiters == null) b.fuelCapacityLiters = 13.0f
                if (b.mileageKmpl == null) b.mileageKmpl = 50f
                if (b.topSpeedKmph == null) b.topSpeedKmph = 101
                if (b.powerHp == null) b.powerHp = 12.7f
                if (b.torqueNm == null) b.torqueNm = 13f
            }
            "ola s1 pro" -> {
                if (b.model.isEmpty()) b.model = "S1 Pro Gen2"
                if (b.year == 0) b.year = 2023
                if (b.fuelType.isEmpty()) b.fuelType = "Electric"
                if (b.batteryCapacityKwh == null) b.batteryCapacityKwh = 4.0f
                if (b.rangeKm == null) b.rangeKm = 181
                if (b.topSpeedKmph == null) b.topSpeedKmph = 116
                if (b.powerHp == null) b.powerHp = 11.0f
                if (b.torqueNm == null) b.torqueNm = 58f
            }
            "felo electric" -> {
                if (b.fuelType.isEmpty()) b.fuelType = "Electric"
                if (b.rangeKm == null) b.rangeKm = 120
                if (b.batteryCapacityKwh == null) b.batteryCapacityKwh = 3.5f
            }
            "honda activa 6g" -> {
                if (b.model.isEmpty()) b.model = "Activa 6G"
                if (b.year == 0) b.year = 2023
                if (b.fuelType.isEmpty()) b.fuelType = "Petrol"
                if (b.engineCc == null) b.engineCc = 109
                if (b.mileageKmpl == null) b.mileageKmpl = 45f
                if (b.fuelCapacityLiters == null) b.fuelCapacityLiters = 5.3f
            }
            "vespa sprint" -> {
                if (b.fuelType.isEmpty()) b.fuelType = "Petrol"
                if (b.engineCc == null) b.engineCc = 124
                if (b.mileageKmpl == null) b.mileageKmpl = 40f
            }
            "royal enfield classic 350" -> {
                if (b.model.isEmpty()) b.model = "Classic 350"
                if (b.year == 0) b.year = 2022
                if (b.fuelType.isEmpty()) b.fuelType = "Petrol"
                if (b.engineCc == null) b.engineCc = 349
                if (b.engineType.isEmpty()) b.engineType = "Single-cylinder, Air-oil cooled"
                if (b.mileageKmpl == null) b.mileageKmpl = 35f
                if (b.topSpeedKmph == null) b.topSpeedKmph = 120
                if (b.powerHp == null) b.powerHp = 20.2f
                if (b.torqueNm == null) b.torqueNm = 27f
                if (b.fuelCapacityLiters == null) b.fuelCapacityLiters = 13.0f
            }
            "royal enfield classic 650" -> {
                if (b.fuelType.isEmpty()) b.fuelType = "Petrol"
                if (b.engineCc == null) b.engineCc = 648
                if (b.topSpeedKmph == null) b.topSpeedKmph = 160
            }
            "ktm rc 390" -> {
                if (b.fuelType.isEmpty()) b.fuelType = "Petrol"
                if (b.engineCc == null) b.engineCc = 373
                if (b.powerHp == null) b.powerHp = 43.5f
                if (b.torqueNm == null) b.torqueNm = 37f
                if (b.topSpeedKmph == null) b.topSpeedKmph = 170
            }
            "ktm 390 adventure" -> {
                if (b.fuelType.isEmpty()) b.fuelType = "Petrol"
                if (b.engineCc == null) b.engineCc = 373
                if (b.powerHp == null) b.powerHp = 43.5f
                if (b.torqueNm == null) b.torqueNm = 37f
            }
            "harley davidson street 750" -> {
                if (b.model.isEmpty()) b.model = "Street 750"
                if (b.year == 0) b.year = 2020
                if (b.fuelType.isEmpty()) b.fuelType = "Petrol"
                if (b.engineCc == null) b.engineCc = 749
                if (b.engineType.isEmpty()) b.engineType = "V-Twin, Liquid-cooled"
                if (b.topSpeedKmph == null) b.topSpeedKmph = 190
                if (b.powerHp == null) b.powerHp = 47f
                if (b.torqueNm == null) b.torqueNm = 59f
                if (b.fuelCapacityLiters == null) b.fuelCapacityLiters = 13.1f
            }
        }
        // Ensure common defaults
        if (b.depositAmount == 0) b.depositAmount = 5000
        if (!b.helmetProvided) b.helmetProvided = true
        if (!b.insuranceIncluded) b.insuranceIncluded = true
        return b
    }
    fun formattedSpecsLine(): String {
        val parts = mutableListOf<String>()
        if (year > 0) parts.add(year.toString())
        if (model.isNotEmpty()) parts.add(model)
        if (fuelType.isNotEmpty()) parts.add(fuelType)
        engineCc?.let { parts.add("${it}cc") }
        batteryCapacityKwh?.let { parts.add("${it}kWh") }
        powerHp?.let { parts.add("${it}hp") }
        mileageKmpl?.let { parts.add("${it} kmpl") }
        rangeKm?.let { parts.add("${it} km range") }
        return parts.joinToString(" • ")
    }
    fun averageRating(): Float = if (ratings.isNotEmpty()) ratings.sum() / ratings.size else 0f
    fun reviewCount(): Int = ratings.size
    fun toggleMaintenance() { underMaintenance = !underMaintenance }
    
    fun getFullAddress(): String {
        val parts = mutableListOf<String>()
        if (address.isNotEmpty()) parts.add(address)
        if (landmark.isNotEmpty()) parts.add("Near $landmark")
        if (city.isNotEmpty()) parts.add(city)
        if (pincode.isNotEmpty()) parts.add(pincode)
        return if (parts.isNotEmpty()) parts.joinToString(", ") else location
    }
    
    fun getFormattedPrice(): String {
        return "₹$price"
    }
    
    fun getFormattedDeposit(): String {
        return if (depositAmount > 0) "₹$depositAmount" else "No deposit"
    }
    
    fun getBikeImageRes(): Int {
        return when (name.lowercase()) {
            "ather 450x" -> R.drawable.olas1pro_electric
            "tvs jupiter" -> R.drawable.activa_scooty
            "bajaj pulsar 150" -> R.drawable.unicorn_standard_bike
            "yamaha mt-15" -> R.drawable.ktmrc_sports_bike
            "suzuki access 125" -> R.drawable.activa_scooty
            "hero splendor plus" -> R.drawable.unicorn_standard_bike
            "bajaj avenger" -> R.drawable.re350_classic
            "bajaj avenger street 160" -> R.drawable.re350_classic
            // Standard bikes
            "honda unicorn 150" -> R.drawable.unicorn_standard_bike
            
            // Electric bikes
            "ola s1 pro" -> R.drawable.olas1pro_electric
            "felo electric" -> R.drawable.felo_electric
            
            // Scooters
            "honda activa 6g" -> R.drawable.activa_scooty
            "vespa sprint" -> R.drawable.vespa_scooter
            
            // Classic bikes
            "royal enfield classic 350" -> R.drawable.re350_classic
            "royal enfield classic 650" -> R.drawable.re650_classic
            
            // Sports bikes
            "ktm rc 390" -> R.drawable.ktmrc_sports_bike
            
            // Adventure bikes
            "ktm 390 adventure" -> R.drawable.ktm390_adventure
            
            // Luxury bikes
            "harley davidson street 750" -> R.drawable.harley_luxury
            
            // Fallback based on type
            else -> when (type.lowercase()) {
                "scooter" -> R.drawable.activa_scooty
                "electric" -> R.drawable.olas1pro_electric
                "sports" -> R.drawable.ktmrc_sports_bike
                "classic" -> R.drawable.re350_classic
                "adventure" -> R.drawable.ktm390_adventure
                "luxury" -> R.drawable.harley_luxury
                "standard" -> R.drawable.unicorn_standard_bike
                else -> R.drawable.unicorn_standard_bike
            }
        }
    }
} 