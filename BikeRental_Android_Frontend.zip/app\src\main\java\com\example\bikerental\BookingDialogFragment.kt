package com.example.bikerental

import android.app.DatePickerDialog
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.DialogFragment
import com.example.bikerental.databinding.FragmentBookingDialogBinding
import java.text.SimpleDateFormat
import java.util.*
import android.app.Dialog
import android.view.Window
import android.widget.LinearLayout
import android.widget.EditText
import android.graphics.Bitmap
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.example.bikerental.BookingRepository
import com.example.bikerental.Booking

class BookingDialogFragment : DialogFragment() {
    private var _binding: FragmentBookingDialogBinding? = null
    private val binding get() = _binding!!
    
    private var selectedBike: Bike? = null
    private var isHourlyRate = true
    private var hourlyRate = 12
    private var dailyRate = 100
    private var selectedHours = 1
    private var startDate: Date? = null
    private var endDate: Date? = null
    private var pickupTime: String? = null
    private var dropoffTime: String? = null
    private var discountPercentage = 0
    private val dateFormat = SimpleDateFormat("dd MMM yyyy", Locale.getDefault())
    private var isBikeUnlocked = false // NEW: Track smart lock status
    private var bookingOtp: String? = null // Store OTP for use after payment

    companion object {
        private const val ARG_BIKE = "bike"
        
        fun newInstance(bike: Bike): BookingDialogFragment {
            val fragment = BookingDialogFragment()
            val args = Bundle()
            args.putParcelable(ARG_BIKE, bike)
            fragment.arguments = args
            return fragment
        }
    }
    
    fun setBookingDetails(hours: Int, isHourly: Boolean, startDateStr: String?, endDateStr: String?, pickupTimeStr: String?, dropoffTimeStr: String?) {
        selectedHours = hours
        isHourlyRate = isHourly
        pickupTime = pickupTimeStr
        dropoffTime = dropoffTimeStr
        
        if (startDateStr != null) {
            try {
                startDate = dateFormat.parse(startDateStr)
            } catch (e: Exception) {
                // Handle parsing error
            }
        }
        
        if (endDateStr != null) {
            try {
                endDate = dateFormat.parse(endDateStr)
            } catch (e: Exception) {
                // Handle parsing error
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {
            selectedBike = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                it.getParcelable(ARG_BIKE, Bike::class.java)
            } else {
                @Suppress("DEPRECATION")
                it.getParcelable(ARG_BIKE)
            }
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentBookingDialogBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupBikeInfo()
        setupClickListeners()
        setupPickupModeUI() // NEW: Setup pickup mode UI
    }

    private fun setupPickupModeUI() {
        // Add owner actions and maps in existing layout
        binding.btnContactOwner.setOnClickListener {
            val phone = "+919876543210"
            val items = arrayOf("Call", "Message")
            androidx.appcompat.app.AlertDialog.Builder(requireContext())
                .setTitle("Contact Owner")
                .setItems(items) { d, which ->
                    if (which == 0) {
                        startActivity(android.content.Intent(android.content.Intent.ACTION_DIAL, android.net.Uri.parse("tel:$phone")))
                    } else {
                        val sms = android.content.Intent(android.content.Intent.ACTION_SENDTO, android.net.Uri.parse("smsto:$phone"))
                        startActivity(sms)
                    }
                    d.dismiss()
                }
                .show()
        }
        val openMaps: (Bike) -> Unit = { b ->
            val query = listOf(b.address, b.location, b.city, b.pincode).filter { it.isNotBlank() }.joinToString(", ")
            val uri = android.net.Uri.parse("geo:0,0?q=" + android.net.Uri.encode(query))
            val intent = android.content.Intent(android.content.Intent.ACTION_VIEW, uri)
                .setPackage("com.google.android.apps.maps")
            if (intent.resolveActivity(requireContext().packageManager) != null) startActivity(intent)
        }
        binding.ivMapPreview.setOnClickListener { selectedBike?.let(openMaps) }
        binding.btnOpenInMaps.setOnClickListener { selectedBike?.let(openMaps) }
        view?.findViewById<Button>(R.id.btnViewMap)?.setOnClickListener { selectedBike?.let(openMaps) }
    }

    private fun setupBikeInfo() {
        selectedBike?.let { bike ->
            // Set bike name
            binding.tvBikeName.text = bike.name
            view?.findViewById<TextView>(R.id.tvBikePrice)?.text = "₹${bike.price}/hour"
            view?.findViewById<TextView>(R.id.tvBikeRating)?.text = "${String.format("%.1f", bike.rating)} (${bike.reviewCount} reviews)"
            
            // Set bike type badge
            binding.tvBikeType.text = bike.type.uppercase()
            view?.findViewById<TextView>(R.id.tvBikeType)?.text = "${bike.type} • ${if (bike.year>0) bike.year else "-"}"
            
            // Set precise address and location details
            val addressParts = listOf(bike.address, bike.location, bike.city, bike.pincode).filter { it.isNotEmpty() }
            val fullAddress = addressParts.joinToString(", ")
            binding.tvBikeAddress.text = fullAddress
            view?.findViewById<TextView>(R.id.tvFullAddress)?.text = fullAddress
            view?.findViewById<TextView>(R.id.tvBikeLocation)?.text = if (bike.address.isNotEmpty()) bike.address else bike.location
            view?.findViewById<TextView>(R.id.tvBikeLandmark)?.text = if (bike.landmark.isNotEmpty()) "Near ${bike.landmark}" else ""
            
            // Set landmark if available
            if (bike.landmark.isNotEmpty()) {
                binding.llLandmark.visibility = View.VISIBLE
                binding.tvBikeLandmark.text = bike.landmark
            } else {
                binding.llLandmark.visibility = View.GONE
            }
            
            // Specs summary under description
            if (bike.description.isNotEmpty()) {
                binding.llDescription.visibility = View.VISIBLE
                binding.tvBikeDescription.text = bike.description
            } else {
                binding.llDescription.visibility = View.GONE
            }

            // Fill specs card fields
            try {
                binding.tvSpecModel.text = "Model: ${bike.model.ifEmpty { bike.name }}"
                binding.tvSpecYear.text = if (bike.year > 0) "Year: ${bike.year}" else "Year: -"
                val fuel = when {
                    bike.fuelType.isNotEmpty() -> bike.fuelType
                    bike.batteryCapacityKwh != null -> "Electric"
                    else -> "-"
                }
                binding.tvSpecFuel.text = "Fuel: $fuel"
                val engBat = listOfNotNull(
                    bike.engineCc?.let { "Engine: ${it}cc ${bike.engineType}".trim() },
                    bike.batteryCapacityKwh?.let { "Battery: ${it}kWh" }
                ).joinToString("  •  ")
                binding.tvSpecEngBat.text = engBat
                val powTq = listOfNotNull(
                    bike.powerHp?.let { "Power: ${it}hp" },
                    bike.torqueNm?.let { "Torque: ${it}Nm" }
                ).joinToString("  •  ")
                binding.tvSpecPowerTorque.text = powTq
                val rngMil = listOfNotNull(
                    bike.rangeKm?.let { "Range: ${it} km" },
                    bike.mileageKmpl?.let { "Mileage: ${it} kmpl" }
                ).joinToString("  •  ")
                binding.tvSpecRangeMileage.text = rngMil
                // Extra specs rendered into deposit/safety rows
                val fuelCap = bike.fuelCapacityLiters?.let { "Fuel Capacity: ${"%.1f".format(it)} L" }
                val topSpeed = bike.topSpeedKmph?.let { "Top Speed: ${it} kmph" }
                val extras = listOfNotNull(fuelCap, topSpeed).joinToString("  •  ")
                if (extras.isNotEmpty()) {
                    binding.tvSpecDeposit.text = extras
                } else {
                    binding.tvSpecDeposit.text = "Deposit: ${bike.getFormattedDeposit()}"
                }
                binding.tvSpecDeposit.text = "Deposit: ${bike.getFormattedDeposit()}"
                val safety = mutableListOf<String>()
                if (bike.helmetProvided) safety.add("Helmet")
                if (bike.insuranceIncluded) safety.add("Insurance")
                binding.tvSpecSafety.text = if (safety.isNotEmpty()) "Includes: ${safety.joinToString(", ")}" else "Includes: -"
                // Mirror into redesigned spec rows if present
                view?.findViewById<TextView>(R.id.tvBikeSpecType)?.text = bike.type.ifEmpty { "-" }
                view?.findViewById<TextView>(R.id.tvBikeSpecFuel)?.text = fuel
                view?.findViewById<TextView>(R.id.tvBikeSpecYear)?.text = if (bike.year>0) "${bike.year}" else "-"
                view?.findViewById<TextView>(R.id.tvBikeSpecEngine)?.text = when {
                    bike.engineCc != null -> "${bike.engineCc}cc ${bike.engineType}".trim()
                    bike.batteryCapacityKwh != null -> "${bike.batteryCapacityKwh} kWh"
                    else -> "-"
                }
                view?.findViewById<TextView>(R.id.tvBikeSpecFuelCapacity)?.text = bike.fuelCapacityLiters?.let { "${"%.1f".format(it)} L" } ?: "-"
                view?.findViewById<TextView>(R.id.tvBikeSpecMileage)?.text = bike.mileageKmpl?.let { "${it} kmpl" } ?: bike.rangeKm?.let { "${it} km" } ?: "-"
                view?.findViewById<TextView>(R.id.tvBikeSpecTopSpeed)?.text = bike.topSpeedKmph?.let { "${it} kmph" } ?: "-"
                view?.findViewById<TextView>(R.id.tvBikeSpecDeposit)?.text = bike.getFormattedDeposit()
            } catch (_: Exception) {}
            
            // Set bike image based on bike name
            val bikeImageRes = bike.getBikeImageRes()
            binding.ivBikeImage.setImageResource(bikeImageRes)
            
            // Set pricing
            hourlyRate = bike.price
            dailyRate = bike.price * 8 // 8 hours = 1 day
            // pricing selector removed in redesign
            view?.findViewById<TextView>(R.id.tvHourlyRate)?.text = "₹${hourlyRate}/hr"
            view?.findViewById<TextView>(R.id.tvDailyRate)?.text = "₹${dailyRate}/day"
            view?.findViewById<TextView>(R.id.tvHourlyPrice)?.text = "₹${hourlyRate}/hour"
            view?.findViewById<TextView>(R.id.tvDailyPrice)?.text = "₹${dailyRate}/day"
            view?.findViewById<TextView>(R.id.tvSelectedBookingType)?.text = if (isHourlyRate) "Hourly Booking Selected" else "Daily Booking Selected"
            
            // Set rental duration (default values - in real app these would come from bike data)
            binding.tvRentalDuration.text = "1-24 hours"
            
            // Set pickup mode
            val pickupModeText = when (bike.pickupMode) {
                "manual" -> "Manual pickup"
                "station" -> "Station pickup"
                else -> "Manual pickup"
            }
            binding.tvPickupMode.text = pickupModeText
            
            // Set owner name based on bike location
            val ownerNames = mapOf(
                "Marina Beach" to "Rahul Kumar",
                "T. Nagar" to "Priya Sharma",
                "Velachery" to "Arun Kumar",
                "Adyar" to "Meera Patel",
                "Guindy" to "Suresh Reddy",
                "Anna Nagar" to "Lakshmi Devi"
            )
            binding.tvOwnerName.text = ownerNames[bike.location] ?: "Bike Owner"
            // Set owner phone
            binding.tvOwnerPhone.text = "Phone: ${if (bike.ownerPhone.isNotEmpty()) bike.ownerPhone else "Not provided"}"
            
            // Set favorite button state
            val isSaved = SavedBikesManager.isBikeSaved(bike.id)
            binding.btnFavorite.tag = isSaved
            binding.btnFavorite.setImageResource(
                if (isSaved) android.R.drawable.btn_star_big_on 
                else android.R.drawable.btn_star_big_off
            )
            
            // Initialize with hourly rate selected by default
            selectHourlyRate()
        }
    }

    private fun setupClickListeners() {
        // Back button
        binding.btnBack.setOnClickListener {
            dismiss()
        }
        
        // Favorite button
        binding.btnFavorite.setOnClickListener {
            toggleFavorite()
        }
        
        // Pricing selector removed in redesigned dialog
        
        // Hourly selection removed in redesigned dialog (no +/- hours controls)
        
        // Date selection buttons
        binding.btnStartDate.setOnClickListener {
            showDatePicker(true)
        }
        
        binding.btnEndDate.setOnClickListener {
            showDatePicker(false)
        }
        
        // Contact owner
        binding.btnContactOwner.setOnClickListener {
            contactOwner()
        }
        
        // Payment button -> route directly to price breakdown (PaymentActivity)
        binding.btnPayment.setOnClickListener {
            val ctx = requireContext()
            val intent = android.content.Intent(ctx, PaymentActivity::class.java)
            selectedBike?.let { bike ->
                intent.putExtra("bike", bike)
                intent.putExtra("selectedHours", selectedHours)
                intent.putExtra("isHourly", isHourlyRate)
                intent.putExtra("userName", "")
                intent.putExtra("licenseNumber", "")
                intent.putExtra("mobileNumber", "")
                intent.putExtra("email", "")
            }
            startActivity(intent)
        }

        // View full terms button
        binding.btnViewFullTerms.setOnClickListener {
            showFullTermsDialog()
        }

        // Smart Lock and Station unlock functionality removed as UI elements were removed
        // These features can be re-implemented in future versions
    }

    private fun toggleFavorite() {
        selectedBike?.let { bike ->
            val isFavorite = binding.btnFavorite.tag as? Boolean ?: false
            if (isFavorite) {
                // Remove from saved bikes
                SavedBikesManager.removeBike(bike.id)
                binding.btnFavorite.setImageResource(android.R.drawable.btn_star_big_off)
                binding.btnFavorite.tag = false
                Toast.makeText(requireContext(), R.string.removed_from_favorites, Toast.LENGTH_SHORT).show()
            } else {
                // Add to saved bikes
                SavedBikesManager.saveBike(bike)
                binding.btnFavorite.setImageResource(android.R.drawable.btn_star_big_on)
                binding.btnFavorite.tag = true
                Toast.makeText(requireContext(), R.string.added_to_favorites, Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun selectHourlyRate() {
        isHourlyRate = true
        binding.layoutDateSelection.visibility = View.GONE
    }

    private fun selectDailyRate() {
        isHourlyRate = false
        binding.layoutDateSelection.visibility = View.VISIBLE
    }

    // Hourly display removed

    private fun showDatePicker(isStartDate: Boolean) {
        val calendar = Calendar.getInstance()
        
        // Set minimum date to today for start date
        if (isStartDate) {
            calendar.add(Calendar.DAY_OF_MONTH, 1) // Start from tomorrow
        } else {
            // For end date, set minimum to start date + 1 day
            startDate?.let { start ->
                calendar.time = start
                calendar.add(Calendar.DAY_OF_MONTH, 1)
            } ?: run {
                calendar.add(Calendar.DAY_OF_MONTH, 2) // At least 1 day after today
            }
        }
        
        val datePickerDialog = DatePickerDialog(
            requireContext(),
            { _, year, month, dayOfMonth ->
                val selectedCalendar = Calendar.getInstance()
                selectedCalendar.set(year, month, dayOfMonth)
                val selectedDate = selectedCalendar.time
                
                if (isStartDate) {
                    startDate = selectedDate
                    binding.btnStartDate.text = dateFormat.format(selectedDate)
                } else {
                    endDate = selectedDate
                    binding.btnEndDate.text = dateFormat.format(selectedDate)
                }
                
                updateDurationAndDiscount()
            },
            calendar.get(Calendar.YEAR),
            calendar.get(Calendar.MONTH),
            calendar.get(Calendar.DAY_OF_MONTH)
        )
        
        datePickerDialog.show()
    }

    private fun updateDurationAndDiscount() {
        if (startDate != null && endDate != null) {
            val diffInMillis = endDate!!.time - startDate!!.time
            val diffInDays = (diffInMillis / (24 * 60 * 60 * 1000)).toInt()
            
            if (diffInDays > 0) {
                binding.tvDateDuration.text = "Duration: $diffInDays day${if (diffInDays > 1) "s" else ""}"
                
                // Calculate discount based on duration
                discountPercentage = when {
                    diffInDays >= 7 -> 15 // 15% off for 1 week or more
                    diffInDays >= 5 -> 12 // 12% off for 5+ days
                    diffInDays >= 3 -> 10 // 10% off for 3+ days
                    else -> 0
                }
                
                // Removed special offers section in simplified dialog
            }
        }
    }

    private fun contactOwner() {
        selectedBike?.let { bike ->
            val ownerNames = mapOf(
                "Marina Beach" to "Rahul Kumar",
                "T. Nagar" to "Priya Sharma",
                "Velachery" to "Arun Kumar",
                "Adyar" to "Meera Patel",
                "Guindy" to "Suresh Reddy",
                "Anna Nagar" to "Lakshmi Devi"
            )
            val ownerName = ownerNames[bike.location] ?: "Bike Owner"
            
            AlertDialog.Builder(requireContext())
                .setTitle("Contact Owner")
                .setMessage("Would you like to contact $ownerName?\n\nPhone: +91 98765 43210\nEmail: ${ownerName.lowercase().replace(" ", ".")}@metro-ride.com")
                .setPositiveButton("Call") { dialog, _ ->
                    Toast.makeText(requireContext(), "Calling $ownerName...", Toast.LENGTH_SHORT).show()
                    dialog.dismiss()
                }
                .setNegativeButton("Message") { dialog, _ ->
                    Toast.makeText(requireContext(), "Opening chat with $ownerName...", Toast.LENGTH_SHORT).show()
                    dialog.dismiss()
                }
                .setNeutralButton("Cancel") { dialog, _ ->
                    dialog.dismiss()
                }
                .show()
        }
    }



    private fun showFullTermsDialog() {
        val termsText = """
            COMPLETE TERMS AND CONDITIONS
            
            1. RENTAL AGREEMENT
            By proceeding with this booking, you agree to be bound by these terms and conditions and acknowledge that you have read and understood them.
            
            2. ELIGIBILITY REQUIREMENTS
            - You must be at least 18 years old
            - You must possess a valid driving license
            - You must have a valid government-issued ID
            - You must have a valid credit/debit card
            
            4. FUEL POLICY
            - Basic fuel will be provided with the bike
            - You can refuel the bike yourself if needed
            - Return the bike with the same fuel level as received
            - Fuel charges will be applied if returned with less fuel
            - Fuel receipts must be provided for reimbursement
            
            5. DAMAGE POLICY
            - You are responsible for any damage during the rental period
            - Report any damage immediately to customer support
            - Damage assessment will be conducted upon return
            - Charges will be applied based on damage assessment
            
            6. LATE RETURNS
            - Additional charges apply for late returns
            - 1-2 hours late: 50% of hourly rate
            - 2+ hours late: Full daily rate
            - No-show: Full rental amount + late fees
            
            7. CANCELLATION POLICY
            - Free cancellation up to 2 hours before pickup time
            - 50% refund for cancellations 2-24 hours before pickup
            - No refund for cancellations within 2 hours of pickup
            - Weather-related cancellations are handled case-by-case
            
            8. SAFETY REQUIREMENTS
            - Follow all traffic rules and regulations
            - Wear appropriate safety gear (helmet mandatory)
            - Do not operate the bike under the influence
            - Maintain safe driving practices at all times
            
            9. MAINTENANCE AND ISSUES
            - Report any mechanical issues immediately
            - Do not attempt to repair the bike yourself
            - Contact customer support for assistance
            - Emergency roadside assistance is available 24/7
            
            10. PRIVACY AND DATA PROTECTION
            - Your personal information is protected as per our privacy policy
            - We collect necessary information for rental purposes
            - Data is stored securely and used only for service provision
            - You can request data deletion at any time
            
            11. PROHIBITED USES
            - No racing or stunt driving
            - No off-road use unless specified
            - No carrying more passengers than allowed
            - No commercial use without prior approval
            
            By accepting these terms, you acknowledge that you have read, understood, and agree to be bound by all the conditions stated above.
        """.trimIndent()

        AlertDialog.Builder(requireContext())
            .setTitle(getString(R.string.complete_terms_title))
            .setMessage(termsText)
            .setPositiveButton(getString(R.string.close)) { dialog, _ ->
                dialog.dismiss()
            }
            .show()
    }

    private fun proceedToPayment() {
        if (isHourlyRate) {
            // Handle hourly payment
            val total = hourlyRate * selectedHours
            
            selectedBike?.let { bike ->
                AlertDialog.Builder(requireContext())
                    .setTitle("Payment Confirmation")
                    .setMessage("Bike: ${bike.name}\n" +
                            "Duration: ${selectedHours} hour${if (selectedHours > 1) "s" else ""}\n" +
                            "Rate: ₹${hourlyRate}/hour\n" +
                            "Location: ${bike.location}\n\n" +
                            "Total Amount: ₹$total\n\nProceed to payment?")
                    .setPositiveButton("Pay Now") { dialog, _ ->
                        processPayment()
                        dialog.dismiss()
                    }
                    .setNegativeButton("Cancel") { dialog, _ ->
                        dialog.dismiss()
                    }
                    .show()
            }
        } else {
            // Handle daily payment
            if (startDate == null || endDate == null) {
                Toast.makeText(requireContext(), "Please select start and end dates", Toast.LENGTH_SHORT).show()
                return
            }
            
            val diffInMillis = endDate!!.time - startDate!!.time
            val diffInDays = (diffInMillis / (24 * 60 * 60 * 1000)).toInt()
            
            if (diffInDays <= 0) {
                Toast.makeText(requireContext(), "End date must be after start date", Toast.LENGTH_SHORT).show()
                return
            }
            
            val totalBeforeDiscount = dailyRate * diffInDays
            val discountAmount = (totalBeforeDiscount * discountPercentage) / 100
            val finalTotal = totalBeforeDiscount - discountAmount
            
            selectedBike?.let { bike ->
                val discountText = if (discountPercentage > 0) "\nDiscount: ₹$discountAmount" else ""
                
                AlertDialog.Builder(requireContext())
                    .setTitle("Payment Confirmation")
                    .setMessage("Bike: ${bike.name}\n" +
                            "Start Date: ${dateFormat.format(startDate!!)}\n" +
                            "End Date: ${dateFormat.format(endDate!!)}\n" +
                            "Duration: $diffInDays day${if (diffInDays > 1) "s" else ""}\n" +
                            "Rate: ₹${dailyRate}/day\n" +
                            "Location: ${bike.location}\n" +
                            "Subtotal: ₹$totalBeforeDiscount" +
                            discountText +
                            "\n\nTotal Amount: ₹$finalTotal\n\nProceed to payment?")
                    .setPositiveButton("Pay Now") { dialog, _ ->
                        processPayment()
                        dialog.dismiss()
                    }
                    .setNegativeButton("Cancel") { dialog, _ ->
                        dialog.dismiss()
                    }
                    .show()
            }
        }
    }

    private fun routeToCheckout() {
        val ctx = requireContext()
        val intent = android.content.Intent(ctx, CheckoutActivity::class.java)
        // Pass selected context
        intent.putExtra("bike", selectedBike)
        intent.putExtra("isHourly", isHourlyRate)
        intent.putExtra("selectedHours", selectedHours)
        startActivity(intent)
    }

    private fun processPayment() {
        // Show loading state
        binding.btnPayment.text = "Processing..."
        binding.btnPayment.isEnabled = false
        
        // Simulate payment processing
        binding.btnPayment.postDelayed({
            showPaymentSuccess()
        }, 2000)
    }

    private fun showPaymentSuccess() {
        selectedBike?.let { bike ->
            // Generate a random booking code/OTP for manual pickup
            val bookingCode = (100000..999999).random().toString()
            bookingOtp = bookingCode
            // Example pickup location
            val pickupLocation = bike.location + ", Chennai"

            // Add booking to active rentals
            val now = Date()
            val endDate = if (isHourlyRate) {
                // Add selectedHours to now
                Date(now.time + selectedHours * 60 * 60 * 1000)
            } else {
                // Use selected start and end dates
                endDate ?: now
            }
            val dateFormatDb = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.getDefault())
            val booking = com.example.bikerental.Booking(
                bikeName = bike.name,
                renterName = "User", // TODO: Replace with actual renter name if available
                location = bike.location,
                startDate = dateFormatDb.format(now),
                endDate = dateFormatDb.format(endDate),
                price = if (isHourlyRate) hourlyRate * selectedHours else dailyRate,
                imageRes = bike.imageRes,
                status = "Active",
                pickupMode = bike.pickupMode,
                lastKnownLocation = bike.location + ", Chennai",
                bookingCode = bookingCode
            )
            BookingRepository.allBookings.add(0, booking)

            // Show custom confirmation dialog
            val dialog = Dialog(requireContext())
            dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
            dialog.setContentView(R.layout.layout_booking_confirmation)
            dialog.setCancelable(false)

            // Set dialog width to match parent
            dialog.window?.setLayout(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )

            // Set values in the dialog
            dialog.findViewById<TextView>(R.id.tvBookingBikeName)?.text = getString(R.string.bike_label, bike.name)
            dialog.findViewById<TextView>(R.id.tvPickupLocation)?.text = getString(R.string.pickup_location_label, pickupLocation)
            dialog.findViewById<TextView>(R.id.tvBookingCode)?.text = bookingCode

            // Contact Support button
            dialog.findViewById<Button>(R.id.btnContactSupport)?.setOnClickListener {
                AlertDialog.Builder(requireContext())
                    .setTitle(R.string.contact_support)
                    .setMessage(R.string.call_support)
                    .setPositiveButton(R.string.ok) { d, _ -> d.dismiss() }
                    .show()
            }

            // Done button
            dialog.findViewById<Button>(R.id.btnDone)?.setOnClickListener {
                dialog.dismiss()
                dismiss() // Dismiss the BookingDialogFragment as well
            }

            dialog.show()

            // Show booking notification
            showBookingNotification(bike.name, pickupLocation)
        }
    }

    private fun showBookingNotification(bikeName: String, pickupLocation: String) {
        val channelId = "booking_updates"
        val notificationId = 1001
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val name = "Booking Updates"
            val descriptionText = "Notifications for your bike bookings"
            val importance = NotificationManager.IMPORTANCE_DEFAULT
            val channel = NotificationChannel(channelId, name, importance).apply {
                description = descriptionText
            }
            val notificationManager: NotificationManager = requireContext().getSystemService(NotificationManager::class.java)
            notificationManager.createNotificationChannel(channel)
        }
        val builder = NotificationCompat.Builder(requireContext(), channelId)
            .setSmallIcon(android.R.drawable.ic_menu_mylocation)
            .setContentTitle("Booking Confirmed!")
            .setContentText("Your bike '$bikeName' is ready at $pickupLocation.")
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
        
        try {
        with(NotificationManagerCompat.from(requireContext())) {
            notify(notificationId, builder.build())
            }
        } catch (e: SecurityException) {
            // Handle permission denied gracefully
            // Notification will not be shown
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
} 