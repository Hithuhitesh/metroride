package com.example.bikerental

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class TheftReportsFragment : Fragment() {
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_theft_reports, container, false)
        val recyclerView = view.findViewById<RecyclerView>(R.id.rvTheftReports)
        recyclerView.layoutManager = LinearLayoutManager(requireContext())
        recyclerView.adapter = TheftReportsAdapter(getMockReports())
        return view
    }

    private fun getMockReports(): List<TheftReport> = listOf(
        TheftReport("alice@email.com", "Marina Cruiser", "BK001", "Marina Beach", "Bike missing from parking lot.", "Under Review"),
        TheftReport("bob@email.com", "E-Bike Pro", "BK002", "T. Nagar", "Lock was broken, bike not found.", "Flagged")
    )

    data class TheftReport(val reportedBy: String, val bikeName: String, val bikeId: String, val location: String, val description: String, var status: String)

    inner class TheftReportsAdapter(private val items: List<TheftReport>) : RecyclerView.Adapter<TheftReportsAdapter.ViewHolder>() {
        inner class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
            val tvReportedBy: TextView = view.findViewById(R.id.tvReportedBy)
            val tvBikeDetails: TextView = view.findViewById(R.id.tvBikeDetails)
            val tvDescription: TextView = view.findViewById(R.id.tvDescription)
            val tvStatus: TextView = view.findViewById(R.id.tvStatus)
            val btnMarkResolved: Button = view.findViewById(R.id.btnMarkResolved)
            val btnFlag: Button = view.findViewById(R.id.btnFlag)
        }
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
            val v = LayoutInflater.from(parent.context).inflate(R.layout.item_theft_report, parent, false)
            return ViewHolder(v)
        }
        override fun onBindViewHolder(holder: ViewHolder, position: Int) {
            val item = items[position]
            holder.tvReportedBy.text = "Reported by: ${item.reportedBy}"
            holder.tvBikeDetails.text = "${item.bikeName} (ID: ${item.bikeId})\nLocation: ${item.location}"
            holder.tvDescription.text = item.description
            holder.tvStatus.text = "Status: ${item.status}"
            holder.btnMarkResolved.setOnClickListener {
                Toast.makeText(requireContext(), "Marked as Resolved", Toast.LENGTH_SHORT).show()
                holder.tvStatus.text = "Status: Resolved"
            }
            holder.btnFlag.setOnClickListener {
                Toast.makeText(requireContext(), "Flagged for Review", Toast.LENGTH_SHORT).show()
                holder.tvStatus.text = "Status: Flagged"
            }
        }
        override fun getItemCount() = items.size
    }
} 