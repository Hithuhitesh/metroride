package com.example.bikerental

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.bikerental.databinding.ActivityLoginBinding
import android.util.Log
import android.widget.TextView
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout

class LoginActivity : AppCompatActivity() {
    private lateinit var binding: ActivityLoginBinding
    private var currentRole: String = "user"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        try {
            binding = ActivityLoginBinding.inflate(layoutInflater)
            setContentView(binding.root)

            // Get the role from intent first
            currentRole = intent.getStringExtra("role") ?: "user"
            
            // Initialize UserManager with error handling
            try {
                UserManager.initialize(this)
                // Create demo users for testing - with error handling
                try {
                    UserManager.createDemoUsers()
                } catch (e: Exception) {
                    Log.e("LoginActivity", "Error creating demo users: ${e.message}")
                    // Continue without demo users
                }
                
                // Debug: Print all users for troubleshooting
                UserManager.debugPrintAllUsers()
                
                // Show demo credentials for testing
                val demoUserCreds = UserManager.getDemoCredentials("user")
                val demoAdminCreds = UserManager.getDemoCredentials("admin")
                if (demoUserCreds != null && demoAdminCreds != null) {
                    Log.d("LoginActivity", "Demo User: ${demoUserCreds.first} / ${demoUserCreds.second}")
                    Log.d("LoginActivity", "Demo Admin: ${demoAdminCreds.first} / ${demoAdminCreds.second}")
                }
            } catch (e: Exception) {
                Log.e("LoginActivity", "Error initializing UserManager: ${e.message}")
                // Continue without UserManager
            }
            
            // Setup UI and listeners
            try {
                updateUIForRole()
                setupClickListeners()
                addEntranceAnimations()
            } catch (e: Exception) {
                Log.e("LoginActivity", "Error setting up UI: ${e.message}")
                // Show basic UI
                showBasicUI()
            }
            
            Log.d("LoginActivity", "LoginActivity created successfully with role: $currentRole")
            
        } catch (e: Exception) {
            Log.e("LoginActivity", "Critical error in onCreate: ${e.message}", e)
            // Show a simple error screen
            showErrorScreen()
        }
    }

    private fun updateUIForRole() {
        try {
            val roleText = if (currentRole == "admin") "Admin" else "User"
            binding.tvRoleIndicator.text = "$roleText Sign In"
            binding.tvLoginSubtitle.text = "Sign in to your $roleText account"
            Log.d("LoginActivity", "UI updated for role: $currentRole")
        } catch (e: Exception) {
            Log.e("LoginActivity", "Error updating UI: ${e.message}", e)
        }
    }

    private fun setupClickListeners() {
        try {
            android.util.Log.d("LoginActivity", "Setting up click listeners...")
            
            // Simple and direct button setup
            val loginButton = findViewById<Button>(R.id.btnLogin)
            val signUpButton = findViewById<Button>(R.id.btnSignUp)
            val forgotPasswordText = findViewById<TextView>(R.id.tvForgotPassword)
            
            if (loginButton != null) {
                android.util.Log.d("LoginActivity", "Found login button, setting listener...")
                loginButton.setOnClickListener {
                    android.util.Log.d("LoginActivity", "Login button clicked!")
                    Toast.makeText(this, "Login button clicked!", Toast.LENGTH_SHORT).show()
                    if (validateLoginForm()) {
                        performLogin()
                    }
                }
            } else {
                android.util.Log.e("LoginActivity", "Login button not found!")
            }
            
            if (signUpButton != null) {
                android.util.Log.d("LoginActivity", "Found sign up button, setting listener...")
                signUpButton.setOnClickListener {
                    android.util.Log.d("LoginActivity", "Sign up button clicked!")
                    Toast.makeText(this, "Sign up button clicked!", Toast.LENGTH_SHORT).show()
                    try {
                        val intent = Intent(this, SignUpActivity::class.java)
                        intent.putExtra("role", currentRole)
                        startActivity(intent)
                    } catch (e: Exception) {
                        Log.e("LoginActivity", "Error navigating to sign up: ${e.message}", e)
                        Toast.makeText(this, "Error opening sign up screen", Toast.LENGTH_SHORT).show()
                    }
                }
            } else {
                android.util.Log.e("LoginActivity", "Sign up button not found!")
            }
            
            if (forgotPasswordText != null) {
                android.util.Log.d("LoginActivity", "Found forgot password text, setting listener...")
                forgotPasswordText.setOnClickListener {
                    android.util.Log.d("LoginActivity", "Forgot password clicked!")
                    Toast.makeText(this, "Forgot password feature coming soon!", Toast.LENGTH_SHORT).show()
                }
            } else {
                android.util.Log.e("LoginActivity", "Forgot password text not found!")
            }
            
            // Also try with binding as backup
            try {
                binding.btnLogin.setOnClickListener {
                    android.util.Log.d("LoginActivity", "Binding login button clicked!")
                    Toast.makeText(this, "Binding login clicked!", Toast.LENGTH_SHORT).show()
                    if (validateLoginForm()) {
                        performLogin()
                    }
                }
                
                binding.btnSignUp.setOnClickListener {
                    android.util.Log.d("LoginActivity", "Binding sign up button clicked!")
                    Toast.makeText(this, "Binding sign up clicked!", Toast.LENGTH_SHORT).show()
                    try {
                        val intent = Intent(this, SignUpActivity::class.java)
                        intent.putExtra("role", currentRole)
                        startActivity(intent)
                    } catch (e: Exception) {
                        Log.e("LoginActivity", "Error navigating to sign up: ${e.message}", e)
                        Toast.makeText(this, "Error opening sign up screen", Toast.LENGTH_SHORT).show()
                    }
                }
                
                binding.tvForgotPassword.setOnClickListener {
                    android.util.Log.d("LoginActivity", "Binding forgot password clicked!")
                    Toast.makeText(this, "Forgot password feature coming soon!", Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                android.util.Log.e("LoginActivity", "Error setting up binding listeners: ${e.message}")
            }
            
            Log.d("LoginActivity", "Click listeners setup completed")
        } catch (e: Exception) {
            Log.e("LoginActivity", "Error setting up click listeners: ${e.message}", e)
            Toast.makeText(this, "Error setting up buttons", Toast.LENGTH_SHORT).show()
        }
    }

    private fun validateLoginForm(): Boolean {
        try {
            val email = binding.etEmail.text.toString().trim()
            val password = binding.etPassword.text.toString().trim()

            Log.d("LoginActivity", "Validating form - Email: $email, Password length: ${password.length}")

            var isValid = true

            if (email.isEmpty()) {
                binding.etEmail.error = "Email is required"
                isValid = false
                Log.d("LoginActivity", "Email validation failed: empty")
            } else if (!android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
                binding.etEmail.error = "Please enter a valid email"
                isValid = false
                Log.d("LoginActivity", "Email validation failed: invalid format")
            }

            if (password.isEmpty()) {
                binding.etPassword.error = "Password is required"
                isValid = false
                Log.d("LoginActivity", "Password validation failed: empty")
            } else if (password.length < 6) {
                binding.etPassword.error = "Password must be at least 6 characters"
                isValid = false
                Log.d("LoginActivity", "Password validation failed: too short")
            }

            Log.d("LoginActivity", "Form validation result: $isValid")
            return isValid
        } catch (e: Exception) {
            Log.e("LoginActivity", "Error validating form: ${e.message}", e)
            return false
        }
    }

    private fun performLogin() {
        try {
            val email = binding.etEmail.text.toString().trim()
            val password = binding.etPassword.text.toString().trim()

            Log.d("LoginActivity", "Attempting login - Email: $email, Role: $currentRole")

            // Use UserManager for authentication
            if (UserManager.loginUser(email, password, currentRole)) {
                // Login successful
                val userName = UserManager.getCurrentUserName()
                val actualRole = UserManager.getCurrentUserRole()
                Log.d("LoginActivity", "Login successful for user: $userName with role: $actualRole")
                
                // Show appropriate welcome message
                val welcomeMessage = if (actualRole != currentRole) {
                    "Welcome back, $userName! (Logged in as ${if (actualRole == "admin") "Admin" else "User"})"
                } else {
                    "Welcome back, $userName!"
                }
                Toast.makeText(this, welcomeMessage, Toast.LENGTH_LONG).show()
                
                // Navigate to main activity
                val intent = Intent(this, MainActivity::class.java)
                intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                startActivity(intent)
                finish()
            } else {
                // Login failed
                Log.d("LoginActivity", "Login failed - invalid credentials")
                Toast.makeText(this, "Invalid email or password", Toast.LENGTH_SHORT).show()
            }
        } catch (e: Exception) {
            Log.e("LoginActivity", "Error during login: ${e.message}", e)
            Toast.makeText(this, "Error during login. Please try again.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun addEntranceAnimations() {
        try {
            // Simple fade in for the card
            binding.root.findViewById<androidx.cardview.widget.CardView>(R.id.cardView)?.alpha = 0f
            binding.root.findViewById<androidx.cardview.widget.CardView>(R.id.cardView)?.animate()?.alpha(1f)?.setDuration(800)?.start()
        } catch (e: Exception) {
            Log.e("LoginActivity", "Error adding animations: ${e.message}", e)
        }
    }

    private fun showBasicUI() {
        try {
            // Set basic text without binding
            val roleText = if (currentRole == "admin") "Admin" else "User"
            findViewById<TextView>(R.id.tvRoleIndicator)?.text = "$roleText Sign In"
            findViewById<TextView>(R.id.tvLoginSubtitle)?.text = "Sign in to your $roleText account"
            
            // Set up basic click listeners
            findViewById<Button>(R.id.btnLogin)?.setOnClickListener {
                Toast.makeText(this, "Login clicked", Toast.LENGTH_SHORT).show()
                // Basic login attempt
                performBasicLogin()
            }
        } catch (e: Exception) {
            Log.e("LoginActivity", "Error in showBasicUI: ${e.message}")
        }
    }

    private fun showErrorScreen() {
        try {
            // Create a simple error layout
            val errorLayout = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = android.view.Gravity.CENTER
                setBackgroundColor(0xFF7B5BE4.toInt())
                
                addView(TextView(this@LoginActivity).apply {
                    text = "Login Screen"
                    textSize = 24f
                    setTextColor(android.graphics.Color.WHITE)
                    gravity = android.view.Gravity.CENTER
                    setPadding(32, 64, 32, 32)
                })
                
                addView(Button(this@LoginActivity).apply {
                    text = "Try Again"
                    setOnClickListener {
                        recreate()
                    }
                    setPadding(32, 16, 32, 16)
                })
            }
            
            setContentView(errorLayout)
        } catch (e: Exception) {
            Log.e("LoginActivity", "Error showing error screen: ${e.message}")
            // Last resort - show system error
            Toast.makeText(this, "App error. Please restart.", Toast.LENGTH_LONG).show()
            finish()
        }
    }

    private fun performBasicLogin() {
        try {
            val email = findViewById<EditText>(R.id.etEmail)?.text.toString().trim()
            val password = findViewById<EditText>(R.id.etPassword)?.text.toString().trim()
            
            if (email.isNotEmpty() && password.isNotEmpty()) {
                Toast.makeText(this, "Login attempt with: $email", Toast.LENGTH_SHORT).show()
                // Navigate to main activity
                val intent = Intent(this, MainActivity::class.java)
                startActivity(intent)
                finish()
            } else {
                Toast.makeText(this, "Please enter email and password", Toast.LENGTH_SHORT).show()
            }
        } catch (e: Exception) {
            Log.e("LoginActivity", "Error in basic login: ${e.message}")
            Toast.makeText(this, "Login error", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onResume() {
        super.onResume()
        Log.d("LoginActivity", "LoginActivity resumed")
    }

    override fun onPause() {
        super.onPause()
        Log.d("LoginActivity", "LoginActivity paused")
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.d("LoginActivity", "LoginActivity destroyed")
    }
} 