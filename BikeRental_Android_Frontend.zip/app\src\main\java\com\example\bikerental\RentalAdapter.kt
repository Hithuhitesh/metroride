package com.example.bikerental

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import java.text.SimpleDateFormat
import java.util.*

class RentalAdapter(
    private var rentals: List<Rental>,
    private val onActionClick: (Rental) -> Unit
) : RecyclerView.Adapter<RentalAdapter.RentalViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RentalViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_rental_card, parent, false)
        return RentalViewHolder(view)
    }

    override fun onBindViewHolder(holder: RentalViewHolder, position: Int) {
        holder.bind(rentals[position])
    }

    override fun getItemCount() = rentals.size

    fun updateList(newList: List<Rental>) {
        rentals = newList
        notifyDataSetChanged()
    }

    inner class RentalViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val ivBikeImage: ImageView = itemView.findViewById(R.id.ivBikeImage)
        private val tvBikeName: TextView = itemView.findViewById(R.id.tvBikeName)
        private val tvBikeType: TextView = itemView.findViewById(R.id.tvBikeType)
        private val tvRentalPeriod: TextView = itemView.findViewById(R.id.tvRentalPeriod)
        private val tvPrice: TextView = itemView.findViewById(R.id.tvPrice)
        private val tvStatus: TextView = itemView.findViewById(R.id.tvStatus)
        private val btnAction: Button = itemView.findViewById(R.id.btnAction)

        fun bind(rental: Rental) {
            tvBikeName.text = rental.bikeName
            tvBikeType.text = rental.bikeType
            tvPrice.text = "₹${rental.price.toInt()}"
            
            // Format rental period
            val dateFormat = SimpleDateFormat("MMM dd, yyyy", Locale.getDefault())
            val periodText = "${dateFormat.format(rental.startTime)} • ${rental.duration} hours"
            tvRentalPeriod.text = periodText

            // Set status and action button
            when (rental.status) {
                RentalStatus.ACTIVE -> {
                    tvStatus.text = "Active"
                    tvStatus.setBackgroundResource(R.drawable.bg_chip_teal_filled)
                    btnAction.text = "End Ride"
                    btnAction.visibility = View.VISIBLE
                }
                RentalStatus.COMPLETED -> {
                    tvStatus.text = "Completed"
                    tvStatus.setBackgroundResource(R.drawable.bg_chip_capsule)
                    btnAction.text = "Rent Again"
                    btnAction.visibility = View.VISIBLE
                }
                RentalStatus.CANCELLED -> {
                    tvStatus.text = "Cancelled"
                    tvStatus.setBackgroundResource(R.drawable.bg_chip_capsule)
                    btnAction.visibility = View.GONE
                }
                RentalStatus.UPCOMING -> {
                    tvStatus.text = "Upcoming"
                    tvStatus.setBackgroundResource(R.drawable.bg_chip_capsule)
                    btnAction.text = "Cancel"
                    btnAction.visibility = View.VISIBLE
                }
            }

            // Set bike image based on bike name
            val bikeImageRes = when (rental.bikeName.lowercase()) {
                // Standard bikes
                "honda unicorn 150" -> R.drawable.unicorn_standard_bike
                
                // Electric bikes
                "ola s1 pro" -> R.drawable.olas1pro_electric
                "felo electric" -> R.drawable.felo_electric
                
                // Scooters
                "honda activa 6g" -> R.drawable.activa_scooty
                "vespa sprint" -> R.drawable.vespa_scooter
                
                // Classic bikes
                "royal enfield classic 350" -> R.drawable.re350_classic
                "royal enfield classic 650" -> R.drawable.re650_classic
                
                // Sports bikes
                "ktm rc 390" -> R.drawable.ktmrc_sports_bike
                
                // Adventure bikes
                "ktm 390 adventure" -> R.drawable.ktm390_adventure
                
                // Luxury bikes
                "harley davidson street 750" -> R.drawable.harley_luxury
                
                // Fallback based on type
                else -> when (rental.bikeType.lowercase()) {
                    "scooter" -> R.drawable.activa_scooty
                    "electric" -> R.drawable.olas1pro_electric
                    "sports" -> R.drawable.ktmrc_sports_bike
                    "classic" -> R.drawable.re350_classic
                    "adventure" -> R.drawable.ktm390_adventure
                    "luxury" -> R.drawable.harley_luxury
                    "standard" -> R.drawable.unicorn_standard_bike
                    else -> R.drawable.unicorn_standard_bike
                }
            }
            ivBikeImage.setImageResource(bikeImageRes)

            // Set action button click listener
            btnAction.setOnClickListener {
                onActionClick(rental)
            }
        }
    }
} 