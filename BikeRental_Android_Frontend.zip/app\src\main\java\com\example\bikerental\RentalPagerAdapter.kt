package com.example.bikerental

import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentActivity
import androidx.viewpager2.adapter.FragmentStateAdapter

class RentalPagerAdapter(activity: FragmentActivity) : FragmentStateAdapter(activity) {
    
    override fun getItemCount(): Int = 2

    override fun createFragment(position: Int): Fragment {
        return when (position) {
            0 -> RentalTabFragment.newInstance("current")
            1 -> RentalTabFragment.newInstance("past")
            else -> RentalTabFragment.newInstance("current")
        }
    }
} 