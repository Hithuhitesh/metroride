package com.example.bikerental

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.card.MaterialCardView

class PaymentActivity : AppCompatActivity() {
    private lateinit var ivBikeImage: ImageView
    private lateinit var tvBikeName: TextView
    private lateinit var tvBikeType: TextView
    private lateinit var tvBikeLocation: TextView
    private lateinit var tvBookingDate: TextView
    private lateinit var tvBookingTime: TextView
    private lateinit var tvBookingDuration: TextView
    private lateinit var ivMapPreview: ImageView
    private lateinit var tvBasePrice: TextView
    private lateinit var tvDuration: TextView
    private lateinit var tvTotalCost: TextView
    private lateinit var rgPaymentMethod: RadioGroup
    private lateinit var btnCompleteBooking: Button
    
    private var selectedBike: Bike? = null
    private var selectedHours = 1
    private var isHourly = true
    private var totalCost = 0
    private var userName: String = ""
    private var licenseNumber: String = ""
    private var mobileNumber: String = ""
    private var email: String = ""
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_payment)
        
        initializeViews()
        setupIntentData()
        setupClickListeners()
        updateUI()
    }
    
    private fun initializeViews() {
        ivBikeImage = findViewById(R.id.ivBikeImage)
        tvBikeName = findViewById(R.id.tvBikeName)
        tvBikeType = findViewById(R.id.tvBikeType)
        tvBikeLocation = findViewById(R.id.tvBikeLocation)
        tvBookingDate = findViewById(R.id.tvBookingDate)
        tvBookingTime = findViewById(R.id.tvBookingTime)
        tvBookingDuration = findViewById(R.id.tvBookingDuration)
        ivMapPreview = findViewById(R.id.ivMapPreview)
        tvBasePrice = findViewById(R.id.tvBasePrice)
        tvDuration = findViewById(R.id.tvDuration)
        tvTotalCost = findViewById(R.id.tvTotalCost)
        rgPaymentMethod = findViewById(R.id.rgPaymentMethod)
        btnCompleteBooking = findViewById(R.id.btnCompleteBooking)
    }
    
    private fun setupIntentData() {
        selectedBike = intent.getParcelableExtra("bike")
        selectedBike = selectedBike?.withDefaultsForKnownBike()
        selectedHours = intent.getIntExtra("selectedHours", 1)
        val passedIsHourly = intent.getBooleanExtra("isHourly", true)
        isHourly = passedIsHourly
        // If days were passed, convert to hours for total calculation
        val selectedDays = intent.getIntExtra("selectedDays", 0)
        if (!isHourly && selectedDays > 0) {
            selectedHours = selectedDays * 24
        }
        userName = intent.getStringExtra("userName") ?: ""
        licenseNumber = intent.getStringExtra("licenseNumber") ?: ""
        mobileNumber = intent.getStringExtra("mobileNumber") ?: ""
        email = intent.getStringExtra("email") ?: ""
        
        selectedBike?.let { bike ->
            totalCost = bike.price * selectedHours
        }
    }
    
    private fun setupClickListeners() {
        ivMapPreview.setOnClickListener {
            openMapWithLocation()
        }
        
        btnCompleteBooking.setOnClickListener {
            processPayment()
        }
    }
    
    private fun updateUI() {
        selectedBike?.let { bike ->
            // Set bike details
            ivBikeImage.setImageResource(bike.getBikeImageRes())
            tvBikeName.text = bike.name
            tvBikeType.text = bike.type
            tvBikeLocation.text = bike.location
            
            // Set booking details
            tvBookingDate.text = "Date: Today"
            tvBookingTime.text = "Time: 8:00 AM - ${8 + selectedHours}:00 AM"
            tvBookingDuration.text = if (isHourly) "Duration: $selectedHours hours" else "Duration: ${selectedHours/24} days"
            findViewById<TextView>(R.id.tvUserSummary)?.text = "User: ${userName} • License: ${licenseNumber} • Mobile: ${mobileNumber}"
            
            // Set price breakdown
            tvBasePrice.text = "₹${bike.price}"
            tvDuration.text = if (isHourly) "$selectedHours hours" else "${selectedHours/24} days"
            tvTotalCost.text = "₹$totalCost"

            // Specs card
            findViewById<TextView>(R.id.tvSpecModel)?.text = "Model: ${bike.model.ifEmpty { bike.name }}"
            findViewById<TextView>(R.id.tvSpecYear)?.text = if (bike.year > 0) "Year: ${bike.year}" else "Year: -"
            findViewById<TextView>(R.id.tvSpecFuel)?.text = "Fuel: ${bike.fuelType.ifEmpty { "-" }}"
            findViewById<TextView>(R.id.tvSpecEngBat)?.text = listOfNotNull(
                bike.engineCc?.let { "Engine: ${it}cc" },
                bike.batteryCapacityKwh?.let { "Battery: ${it}kWh" }
            ).joinToString("  •  ")
            findViewById<TextView>(R.id.tvSpecPowerTorque)?.text = listOfNotNull(
                bike.powerHp?.let { "Power: ${it}hp" },
                bike.torqueNm?.let { "Torque: ${it}Nm" }
            ).joinToString("  •  ")
            findViewById<TextView>(R.id.tvSpecRangeMileage)?.text = listOfNotNull(
                bike.rangeKm?.let { "Range: ${it} km" },
                bike.mileageKmpl?.let { "Mileage: ${it} kmpl" }
            ).joinToString("  •  ")
            findViewById<TextView>(R.id.tvSpecDeposit)?.text = "Deposit: ${bike.getFormattedDeposit()}"
            val safety = mutableListOf<String>()
            if (bike.helmetProvided) safety.add("Helmet")
            if (bike.insuranceIncluded) safety.add("Insurance")
            findViewById<TextView>(R.id.tvSpecSafety)?.text = if (safety.isNotEmpty()) "Includes: ${safety.joinToString(", ")}" else "Includes: -"
        }
    }
    
    private fun openMapWithLocation() {
        selectedBike?.let { bike ->
            val location = bike.location
            val uri = "geo:0,0?q=$location"
            val mapIntent = Intent(Intent.ACTION_VIEW, Uri.parse(uri))
            startActivity(mapIntent)
        }
    }
    
    private fun processPayment() {
        val selectedPaymentMethod = getSelectedPaymentMethod()
        
        if (selectedPaymentMethod.isEmpty()) {
            Toast.makeText(this, "Please select a payment method", Toast.LENGTH_SHORT).show()
            return
        }
        
        // Show loading state
        btnCompleteBooking.text = "Processing..."
        btnCompleteBooking.isEnabled = false
        
        // Simulate payment processing
        btnCompleteBooking.postDelayed({
            completeBooking()
        }, 2000)
    }
    
    private fun getSelectedPaymentMethod(): String {
        val selectedId = rgPaymentMethod.checkedRadioButtonId
        return when (selectedId) {
            R.id.rbCreditCard -> "Credit Card"
            R.id.rbDebitCard -> "Debit Card"
            R.id.rbUPI -> "UPI"
            R.id.rbNetBanking -> "Net Banking"
            else -> ""
        }
    }
    
    private fun completeBooking() {
        selectedBike?.let { bike ->
            // Create booking
            val booking = Booking(
                bikeName = bike.name,
                renterName = userName.ifEmpty { "User" },
                location = bike.location,
                startDate = tvBookingDate.text.toString().removePrefix("Date: "),
                endDate = tvBookingDate.text.toString().removePrefix("Date: "),
                pickupTime = "8:00 AM",
                dropoffTime = "${selectedHours + 8}:00 AM",
                price = totalCost,
                imageRes = bike.imageRes,
                status = "Active",
                pickupMode = "manual",
                lastKnownLocation = bike.location,
                bookingCode = (100000..999999).random().toString(),
                userName = userName,
                licenseNumber = licenseNumber,
                mobileNumber = mobileNumber,
                email = email
            )
            
            // Add to repository
            BookingRepository.allBookings.add(0, booking)
            
            // Show success message
            Toast.makeText(this, "Booking completed successfully!", Toast.LENGTH_LONG).show()
            
            // Navigate back to main activity
            val intent = Intent(this, MainActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP
            startActivity(intent)
            finish()
        }
    }
}

