package com.example.bikerental

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView

class RentalsPromptFragment : Fragment() {

    private lateinit var rv: RecyclerView
    private val adapter = BookingAdapter()

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater.inflate(R.layout.fragment_rentals_prompt, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        rv = view.findViewById(R.id.rvRentalsPrompt)
        rv.layoutManager = LinearLayoutManager(requireContext())
        rv.adapter = adapter
        adapter.submitList(loadBookings(requireContext()))
    }

    private fun loadBookings(context: Context): List<PromptBooking> {
        val prefs = context.getSharedPreferences("bookings", Context.MODE_PRIVATE)
        val set = prefs.getStringSet("items", emptySet()) ?: emptySet()
        val out = mutableListOf<PromptBooking>()
        for (s in set) {
            try {
                val o = org.json.JSONObject(s)
                out.add(
                    PromptBooking(
                        id = o.getString("id"),
                        bikeId = o.getString("bikeId"),
                        bikeName = o.getString("bikeName"),
                        imageRes = o.getInt("imageRes"),
                        startMs = o.getLong("startMs"),
                        endMs = o.getLong("endMs"),
                        isHourly = o.getBoolean("isHourly"),
                        hourlyRate = o.getDouble("hourlyRate"),
                        locationLabel = o.getString("locationLabel")
                    )
                )
            } catch (_: Throwable) {}
        }
        return out.sortedBy { it.startMs }
    }

    private class BookingAdapter : ListAdapter<PromptBooking, VH>(DIFF) {
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
            val v = LayoutInflater.from(parent.context).inflate(R.layout.item_booking_prompt, parent, false)
            return VH(v)
        }
        override fun onBindViewHolder(holder: VH, position: Int) {
            holder.bind(getItem(position))
        }
        private object DIFF : DiffUtil.ItemCallback<PromptBooking>() {
            override fun areItemsTheSame(oldItem: PromptBooking, newItem: PromptBooking) = oldItem.id == newItem.id
            override fun areContentsTheSame(oldItem: PromptBooking, newItem: PromptBooking) = oldItem == newItem
        }
    }

    private class VH(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val ivBike = itemView.findViewById<ImageView>(R.id.ivBike)
        private val tvName = itemView.findViewById<TextView>(R.id.tvBikeName)
        private val tvWindow = itemView.findViewById<TextView>(R.id.tvWindow)
        private val tvStatus = itemView.findViewById<TextView>(R.id.tvStatus)
        private val ivMap = itemView.findViewById<ImageView>(R.id.ivMapThumb)

        fun bind(b: PromptBooking) {
            if (b.imageRes != 0) ivBike.setImageResource(b.imageRes)
            tvName.text = b.bikeName
            tvWindow.text = formatWindowReadablePrompt(b.startMs, b.endMs, b.isHourly)
            tvStatus.text = statusFor(b)
            ivMap.setOnClickListener { openMap(itemView.context, b.locationLabel) }
            itemView.setOnClickListener {
                android.widget.Toast.makeText(itemView.context, "Booking: ${b.bikeName}", android.widget.Toast.LENGTH_SHORT).show()
            }
        }

        private fun statusFor(b: PromptBooking): String {
            val now = System.currentTimeMillis()
            return when {
                now < b.startMs -> "Upcoming"
                now in b.startMs..b.endMs -> "Ongoing"
                else -> "Completed"
            }
        }

        private fun openMap(context: Context, label: String) {
            val uri = Uri.parse("geo:0,0?q=" + Uri.encode(label))
            val intent = Intent(Intent.ACTION_VIEW, uri).setPackage("com.google.android.apps.maps")
            if (intent.resolveActivity(context.packageManager) != null) context.startActivity(intent)
        }
    }
}










