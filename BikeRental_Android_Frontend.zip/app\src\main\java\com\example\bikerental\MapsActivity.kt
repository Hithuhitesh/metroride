package com.example.bikerental

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.os.Bundle
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationCallback
import com.google.android.gms.location.LocationRequest
import com.google.android.gms.location.LocationResult
import com.google.android.gms.location.LocationServices
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.BitmapDescriptorFactory
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.Marker
import com.google.android.gms.maps.model.MarkerOptions
import com.google.android.material.floatingactionbutton.FloatingActionButton
import android.view.View
import android.widget.TextView
import kotlin.math.roundToInt

class MapsActivity : AppCompatActivity(), OnMapReadyCallback {
    
    private lateinit var mMap: GoogleMap
    private lateinit var fusedLocationClient: FusedLocationProviderClient
    private var currentLocation: LatLng? = null
    private val markers = mutableListOf<Marker>()
    private var searchQuery: String? = null
    private var currentFilter: BikeFilter = BikeFilter.ALL
    private var allBikes = listOf<BikeLocation>()
    private var isMapReady = false
    
    // Location callback for real-time updates
    private val locationCallback = object : LocationCallback() {
        override fun onLocationResult(locationResult: LocationResult) {
            locationResult.lastLocation?.let { location ->
                currentLocation = LatLng(location.latitude, location.longitude)
                updateBikeDistances()
            }
        }
    }
    
    // Enhanced sample bike locations with more realistic data
    private val sampleBikes = listOf(
        BikeLocation("Honda Activa 125", LatLng(13.0827, 80.2707), "Available", 150.0, "Near Central Station", BikeType.SCOOTER, "2022 Model, Good Condition"),
        BikeLocation("TVS Jupiter Classic", LatLng(13.0827, 80.2807), "Available", 120.0, "Near Marina Beach", BikeType.SCOOTER, "2021 Model, Excellent"),
        BikeLocation("Bajaj Pulsar 150", LatLng(13.0727, 80.2707), "Available", 200.0, "Near Phoenix Market City", BikeType.STANDARD, "2023 Model, Like New"),
        BikeLocation("Hero Splendor Plus", LatLng(13.0927, 80.2607), "Available", 100.0, "Near Anna Nagar Park", BikeType.STANDARD, "2020 Model, Well Maintained"),
        BikeLocation("Yamaha FZ-S V3", LatLng(13.0827, 80.2907), "Available", 180.0, "Near Anna University", BikeType.SPORTS, "2023 Model, Premium"),
        BikeLocation("Ola S1 Pro", LatLng(13.0527, 80.2707), "Available", 250.0, "Near Tidel Park", BikeType.ELECTRIC, "2023 Model, Electric"),
        BikeLocation("Felo F3", LatLng(13.1127, 80.2707), "Available", 220.0, "Near Chennai Airport", BikeType.ELECTRIC, "2023 Model, Electric"),
        BikeLocation("KTM Duke 200", LatLng(13.0627, 80.2807), "Available", 300.0, "Near Race Course", BikeType.SPORTS, "2022 Model, Performance"),
        BikeLocation("Royal Enfield Classic 350", LatLng(13.1027, 80.2507), "Available", 350.0, "Near Fort St. George", BikeType.STANDARD, "2023 Model, Classic"),
        BikeLocation("Ather 450X", LatLng(13.0727, 80.2907), "Available", 280.0, "Near Express Avenue", BikeType.ELECTRIC, "2023 Model, Electric"),
        BikeLocation("Vespa LX 125", LatLng(13.0527, 80.2507), "Available", 160.0, "Near Spencer Plaza", BikeType.SCOOTER, "2022 Model, Stylish"),
        BikeLocation("Honda CB Shine", LatLng(13.0927, 80.2807), "Available", 140.0, "Near Egmore Station", BikeType.STANDARD, "2021 Model, Reliable"),
        BikeLocation("TVS Apache RTR 160", LatLng(13.0627, 80.2607), "Available", 190.0, "Near Chepauk Stadium", BikeType.SPORTS, "2023 Model, Sporty"),
        BikeLocation("Bajaj Chetak", LatLng(13.0727, 80.2907), "Available", 240.0, "Near Connemara Library", BikeType.ELECTRIC, "2023 Model, Electric"),
        BikeLocation("Hero Xtreme 160R", LatLng(13.0827, 80.2507), "Available", 170.0, "Near High Court", BikeType.SPORTS, "2022 Model, Performance")
    )
    
    // Permission launcher
    private val locationPermissionRequest = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        when {
            permissions.getOrDefault(Manifest.permission.ACCESS_FINE_LOCATION, false) -> {
                enableMyLocation()
            }
            permissions.getOrDefault(Manifest.permission.ACCESS_COARSE_LOCATION, false) -> {
                enableMyLocation()
            }
            else -> {
                Toast.makeText(this, "Location permission is required to show nearby bikes", Toast.LENGTH_LONG).show()
                // Show bikes anyway with default location
                showBikesWithDefaultLocation()
            }
        }
    }
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_maps)
        
        // Get search query from intent
        searchQuery = intent.getStringExtra("search_query")
        
        // Initialize location services
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)
        
        // Initialize all bikes list
        allBikes = sampleBikes
        
        // Initialize map
        val mapFragment = supportFragmentManager.findFragmentById(R.id.map) as SupportMapFragment
        mapFragment.getMapAsync(this)
        
        // Setup FAB for location
        findViewById<FloatingActionButton>(R.id.fabMyLocation).setOnClickListener {
            moveToCurrentLocation()
        }
        
        // Setup FAB for refresh
        findViewById<FloatingActionButton>(R.id.fabRefresh).setOnClickListener {
            refreshBikes()
        }
        
        // Setup search and filter buttons
        findViewById<View>(R.id.llSearch).setOnClickListener {
            showSearchDialog()
        }
        
        findViewById<View>(R.id.llFilter).setOnClickListener {
            showFilterDialog()
        }
        
        // Show initial bikes count
        updateBikeCount()
    }
    
    override fun onMapReady(googleMap: GoogleMap) {
        mMap = googleMap
        isMapReady = true
        
        try {
            // Set map properties
            mMap.uiSettings.isZoomControlsEnabled = true
            mMap.uiSettings.isCompassEnabled = true
            mMap.uiSettings.isMyLocationButtonEnabled = false
            mMap.uiSettings.isMapToolbarEnabled = true
            
            // Check location permission
            when {
                ContextCompat.checkSelfPermission(
                    this,
                    Manifest.permission.ACCESS_FINE_LOCATION
                ) == PackageManager.PERMISSION_GRANTED -> {
                    enableMyLocation()
                }
                shouldShowRequestPermissionRationale(Manifest.permission.ACCESS_FINE_LOCATION) -> {
                    Toast.makeText(this, "Location permission is needed to show nearby bikes", Toast.LENGTH_LONG).show()
                    requestLocationPermission()
                }
                else -> {
                    requestLocationPermission()
                }
            }
            
            // Add bike markers
            addBikeMarkers()
            
            // Set map click listener
            mMap.setOnMapClickListener { latLng ->
                showBikeDetailsDialog(latLng)
            }
            
            // Set marker click listener
            mMap.setOnMarkerClickListener { marker ->
                showBikeMarkerInfo(marker)
                true
            }
            
            // Move to default location if no current location
            if (currentLocation == null) {
                moveToDefaultLocation()
            }
            
        } catch (e: Exception) {
            Toast.makeText(this, "Error initializing map: ${e.message}", Toast.LENGTH_LONG).show()
            // Fallback: show bikes without map
            showBikesWithDefaultLocation()
        }
    }
    
    private fun enableMyLocation() {
        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_FINE_LOCATION
            ) == PackageManager.PERMISSION_GRANTED
        ) {
            try {
                mMap.isMyLocationEnabled = true
                
                // Get current location
                fusedLocationClient.lastLocation.addOnSuccessListener { location: Location? ->
                    location?.let {
                        currentLocation = LatLng(it.latitude, it.longitude)
                        moveToCurrentLocation()
                        startLocationUpdates()
                    } ?: run {
                        // If no location available, use default
                        moveToDefaultLocation()
                    }
                }
            } catch (e: Exception) {
                Toast.makeText(this, "Error enabling location: ${e.message}", Toast.LENGTH_SHORT).show()
                moveToDefaultLocation()
            }
        }
    }
    
    private fun startLocationUpdates() {
        try {
            val locationRequest = LocationRequest.Builder(10000) // 10 seconds
                .setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY)
                .build()
            
            if (ContextCompat.checkSelfPermission(
                    this,
                    Manifest.permission.ACCESS_FINE_LOCATION
                ) == PackageManager.PERMISSION_GRANTED
            ) {
                fusedLocationClient.requestLocationUpdates(
                    locationRequest,
                    locationCallback,
                    mainLooper
                )
            }
        } catch (e: Exception) {
            Toast.makeText(this, "Error starting location updates: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }
    
    private fun requestLocationPermission() {
        locationPermissionRequest.launch(
            arrayOf(
                Manifest.permission.ACCESS_FINE_LOCATION,
                Manifest.permission.ACCESS_COARSE_LOCATION
            )
        )
    }
    
    private fun moveToCurrentLocation() {
        currentLocation?.let { location ->
            try {
                mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(location, 15f))
                updateBikeDistances()
            } catch (e: Exception) {
                Toast.makeText(this, "Error moving to current location", Toast.LENGTH_SHORT).show()
            }
        } ?: run {
            moveToDefaultLocation()
        }
    }
    
    private fun moveToDefaultLocation() {
        try {
            // Move to Chennai center
            val chennai = LatLng(13.0827, 80.2707)
            mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(chennai, 12f))
            updateBikeDistances()
        } catch (e: Exception) {
            Toast.makeText(this, "Error moving to default location", Toast.LENGTH_SHORT).show()
        }
    }
    
    private fun showBikesWithDefaultLocation() {
        // Show bikes even without location permission
        updateBikeDistances()
        moveToDefaultLocation()
    }
    
    private fun updateBikeDistances() {
        currentLocation?.let { userLocation ->
            allBikes = allBikes.map { bike ->
                val distance = calculateDistance(userLocation, bike.location)
                bike.copy(distance = distance)
            }.sortedBy { it.distance }
        } ?: run {
            // If no current location, keep original order
            allBikes = sampleBikes
        }
        
        if (isMapReady) {
            addBikeMarkers()
        }
        updateBikeCount()
    }
    
    private fun calculateDistance(from: LatLng, to: LatLng): Float {
        return MapUtils.calculateDistance(from, to)
    }
    
    private fun addBikeMarkers() {
        try {
            // Clear existing markers
            markers.forEach { it.remove() }
            markers.clear()
            
            // Filter bikes based on search query and current filter
            val filteredBikes = allBikes.filter { bike ->
                val matchesSearch = searchQuery.isNullOrEmpty() ||
                        bike.name.contains(searchQuery!!, ignoreCase = true) ||
                        bike.description.contains(searchQuery!!, ignoreCase = true) ||
                        bike.details.contains(searchQuery!!, ignoreCase = true)
                
                val matchesFilter = when (currentFilter) {
                    BikeFilter.ALL -> true
                    BikeFilter.ELECTRIC -> bike.type == BikeType.ELECTRIC
                    BikeFilter.SCOOTER -> bike.type == BikeType.SCOOTER
                    BikeFilter.SPORTS -> bike.type == BikeType.SPORTS
                    BikeFilter.STANDARD -> bike.type == BikeType.STANDARD
                }
                
                matchesSearch && matchesFilter
            }
            
            // Add bike markers
            filteredBikes.forEach { bike ->
                val distanceText = if (bike.distance > 0) {
                    " (${MapUtils.formatDistance(bike.distance)})"
                } else ""
                
                val marker = mMap.addMarker(
                    MarkerOptions()
                        .position(bike.location)
                        .title(bike.name)
                        .snippet("₹${bike.price}/hour • ${bike.status}$distanceText")
                        .icon(BitmapDescriptorFactory.fromResource(R.drawable.ic_bike_marker))
                )
                marker?.let { markers.add(it) }
            }
            
            updateBikeCount(filteredBikes.size)
            
        } catch (e: Exception) {
            Toast.makeText(this, "Error adding bike markers: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }
    
    private fun updateBikeCount(count: Int = allBikes.size) {
        findViewById<TextView>(R.id.tvBikeCount).text = "$count bikes available"
    }
    
    private fun refreshBikes() {
        Toast.makeText(this, "Refreshing nearby bikes...", Toast.LENGTH_SHORT).show()
        updateBikeDistances()
    }
    
    private fun showBikeMarkerInfo(marker: Marker) {
        val bike = allBikes.find { it.location == marker.position }
        bike?.let {
            val dialog = BikeInfoDialog.newInstance(it)
            dialog.show(supportFragmentManager, "BikeInfoDialog")
        }
    }
    
    private fun showBikeDetailsDialog(location: LatLng) {
        val options = arrayOf("Add My Bike Here", "View Area Info", "Get Directions", "Cancel")
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle("Location Options")
            .setItems(options) { _, which ->
                when (which) {
                    0 -> {
                        // Navigate to add bike activity
                        val intent = Intent(this, ListYourBikeFragment::class.java)
                        intent.putExtra("latitude", location.latitude)
                        intent.putExtra("longitude", location.longitude)
                        startActivity(intent)
                    }
                    1 -> {
                        showAreaInfo(location)
                    }
                    2 -> {
                        getDirections(location)
                    }
                }
            }
            .show()
    }
    
    private fun getDirections(location: LatLng) {
        try {
            val uri = "google.navigation:q=${location.latitude},${location.longitude}"
            val intent = Intent(Intent.ACTION_VIEW, android.net.Uri.parse(uri))
            intent.setPackage("com.google.android.apps.maps")
            
            if (intent.resolveActivity(packageManager) != null) {
                startActivity(intent)
            } else {
                Toast.makeText(this, "Google Maps app not found", Toast.LENGTH_SHORT).show()
            }
        } catch (e: Exception) {
            Toast.makeText(this, "Error opening directions: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }
    
    private fun showAreaInfo(location: LatLng) {
        val areaInfo = MapUtils.getAreaInfo(location)
        
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle("Area Information")
            .setMessage(areaInfo)
            .setPositiveButton("OK", null)
            .show()
    }
    
    private fun showSearchDialog() {
        val searchDialog = SearchLocationDialog()
        searchDialog.setOnLocationSelectedListener { query ->
            searchQuery = query
            addBikeMarkers()
            Toast.makeText(this, "Searching for: $query", Toast.LENGTH_SHORT).show()
        }
        searchDialog.show(supportFragmentManager, "SearchDialog")
    }
    
    private fun showFilterDialog() {
        val filterOptions = arrayOf("All Bikes", "Electric", "Scooter", "Sports", "Standard", "Cancel")
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle("Filter Bikes")
            .setItems(filterOptions) { _, which ->
                currentFilter = when (which) {
                    0 -> BikeFilter.ALL
                    1 -> BikeFilter.ELECTRIC
                    2 -> BikeFilter.SCOOTER
                    3 -> BikeFilter.SPORTS
                    4 -> BikeFilter.STANDARD
                    else -> currentFilter
                }
                
                if (which < 5) {
                    addBikeMarkers()
                    Toast.makeText(this, "Filter applied: ${filterOptions[which]}", Toast.LENGTH_SHORT).show()
                }
            }
            .show()
    }
    
    override fun onDestroy() {
        super.onDestroy()
        try {
            fusedLocationClient.removeLocationUpdates(locationCallback)
        } catch (e: Exception) {
            // Ignore errors when removing updates
        }
    }
    
    // Data class for bike location
    data class BikeLocation(
        val name: String,
        val location: LatLng,
        val status: String,
        val price: Double,
        val description: String,
        val type: BikeType,
        val details: String = "",
        val distance: Float = 0f
    )
    
    // Bike types enum
    enum class BikeType {
        ELECTRIC, SCOOTER, SPORTS, STANDARD
    }
    
    // Filter enum
    enum class BikeFilter {
        ALL, ELECTRIC, SCOOTER, SPORTS, STANDARD
    }
    
    // Dialog for bike information
    class BikeInfoDialog : androidx.fragment.app.DialogFragment() {
        
        companion object {
            fun newInstance(bike: BikeLocation): BikeInfoDialog {
                val dialog = BikeInfoDialog()
                val args = Bundle()
                args.putString("name", bike.name)
                args.putString("status", bike.status)
                args.putDouble("price", bike.price)
                args.putString("description", bike.description)
                args.putString("type", bike.type.name)
                args.putFloat("distance", bike.distance)
                args.putString("details", bike.details)
                dialog.arguments = args
                return dialog
            }
        }
        
        override fun onCreateDialog(savedInstanceState: Bundle?): androidx.appcompat.app.AlertDialog {
            val name = arguments?.getString("name") ?: ""
            val status = arguments?.getString("status") ?: ""
            val price = arguments?.getDouble("price") ?: 0.0
            val description = arguments?.getString("description") ?: ""
            val type = arguments?.getString("type") ?: ""
            val distance = arguments?.getFloat("distance") ?: 0f
            val details = arguments?.getString("details") ?: ""
            
            val distanceText = if (distance > 0) {
                "📍 Distance: ${MapUtils.formatDistance(distance)} away\n"
            } else ""
            
            val message = """
                🏍️ $name
                🏷️ Type: $type
                
                📍 Location: $description
                $distanceText💰 Price: ₹$price/hour
                ✅ Status: $status
                
                📋 Details: $details
                
                🕐 Available: 24/7
                ⭐ Rating: 4.5/5
                
                Would you like to book this bike?
            """.trimIndent()
            
            return androidx.appcompat.app.AlertDialog.Builder(requireContext())
                .setTitle("Bike Details")
                .setMessage(message)
                .setPositiveButton("Book Now") { _, _ ->
                    // Navigate to booking
                    val intent = Intent(requireContext(), BookingDialogFragment::class.java)
                    intent.putExtra("bike_name", name)
                    intent.putExtra("bike_price", price)
                    startActivity(intent)
                }
                .setNegativeButton("Get Directions") { _, _ ->
                    // Get directions to bike location
                    val intent = Intent(Intent.ACTION_VIEW)
                    intent.data = android.net.Uri.parse("google.navigation:q=${description}")
                    intent.setPackage("com.google.android.apps.maps")
                    startActivity(intent)
                }
                .setNeutralButton("Cancel", null)
                .create()
        }
    }
    
    // Search location dialog
    class SearchLocationDialog : androidx.fragment.app.DialogFragment() {
        private var onLocationSelectedListener: ((String) -> Unit)? = null
        
        fun setOnLocationSelectedListener(listener: (String) -> Unit) {
            onLocationSelectedListener = listener
        }
        
        override fun onCreateDialog(savedInstanceState: Bundle?): androidx.appcompat.app.AlertDialog {
            val locations = MapUtils.getPopularLocations().toTypedArray()
            
            return androidx.appcompat.app.AlertDialog.Builder(requireContext())
                .setTitle("Search Location")
                .setItems(locations) { _, which ->
                    val selectedLocation = if (which == locations.size - 1) "" else locations[which]
                    onLocationSelectedListener?.invoke(selectedLocation)
                }
                .setNegativeButton("Cancel", null)
                .create()
        }
    }
} 