package com.example.bikerental

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.chip.Chip
import com.google.android.material.chip.ChipGroup
import androidx.appcompat.app.AlertDialog

class BrowseBikesFragment : Fragment() {
    private lateinit var tvSelectedLocation: TextView
    private lateinit var tvSelectedDate: TextView
    private lateinit var tvSelectedTime: TextView
    private lateinit var etSearch: EditText
    private lateinit var btnFilter: Button
    private lateinit var chipGroupFilters: ChipGroup
    private lateinit var tvResultsCount: TextView
    private lateinit var rvBikes: RecyclerView
    private lateinit var tvNoResults: LinearLayout
    
    private lateinit var bikeAdapter: BrowseBikeAdapter
    private var allBikes: List<Bike> = emptyList()
    private var filteredBikes: List<Bike> = emptyList()
    private var isHourly = false
    private var duration = 2
    private var selectedLocation = "Chennai"
    private var selectedDate = ""
    private var selectedTime = ""
    
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_browse_bikes, container, false)
    }
    
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        
        initializeViews(view)
        setupArguments()
        setupRecyclerView()
        setupSearchAndFilters()
        loadBikes()
        updateSelectionSummary()
    }
    
    private fun initializeViews(view: View) {
        tvSelectedLocation = view.findViewById(R.id.tvSelectedLocation)
        tvSelectedDate = view.findViewById(R.id.tvSelectedDate)
        tvSelectedTime = view.findViewById(R.id.tvSelectedTime)
        etSearch = view.findViewById(R.id.etSearch)
        btnFilter = view.findViewById(R.id.btnFilter)
        chipGroupFilters = view.findViewById(R.id.chipGroupFilters)
        tvResultsCount = view.findViewById(R.id.tvResultsCount)
        rvBikes = view.findViewById(R.id.rvBikes)
        tvNoResults = view.findViewById(R.id.tvNoResults)
    }
    
    private fun setupArguments() {
        arguments?.let { args ->
            isHourly = args.getBoolean("isHourly", false)
            duration = args.getInt("duration", 2)
            selectedLocation = args.getString("location", "Chennai")
            selectedDate = args.getString("date") ?: args.getString("startDate") ?: ""
            selectedTime = args.getString("startTime") ?: args.getString("pickupTime") ?: ""
        }
    }
    
    private fun setupRecyclerView() {
        rvBikes.layoutManager = GridLayoutManager(requireContext(), 2)
        bikeAdapter = BrowseBikeAdapter(emptyList()) { bike ->
            showBookingDialog(bike)
        }
        rvBikes.adapter = bikeAdapter
    }
    
    private fun setupSearchAndFilters() {
        // Search functionality
        etSearch.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: android.text.Editable?) {
                filterBikes()
            }
        })
        
        // Filter button
        btnFilter.setOnClickListener {
            showFilterDialog()
        }
        
        // Setup filter chips
        setupFilterChips()
    }
    
    private fun setupFilterChips() {
        val filterTypes = listOf("All", "Standard", "Scooter", "Electric", "Sports", "Classic", "Adventure", "Luxury")
        
        filterTypes.forEach { type ->
            val chip = Chip(requireContext())
            chip.text = type
            chip.isCheckable = true
            chip.isChecked = type == "All"
            chip.setOnClickListener {
                filterBikesByType(type)
            }
            chipGroupFilters.addView(chip)
        }
    }
    
    private fun loadBikes() {
        allBikes = getAllBikes()
        filteredBikes = filterBySelectedLocation(allBikes, selectedLocation)
        updateBikeList()
        fetchBikesFromApi()
    }

    private fun filterBySelectedLocation(list: List<Bike>, locationQuery: String): List<Bike> {
        if (locationQuery.isBlank()) return list
        val q = locationQuery.trim().lowercase()
        return list.filter { bike ->
            bike.location.lowercase().contains(q) ||
            bike.city.lowercase().contains(q)
        }
    }
    
    private fun getAllBikes(): List<Bike> {
        return listOf(
            Bike(
                id = "1", 
                name = "Honda Unicorn 150", 
                type = "Standard", 
                location = "Velachery, Chennai",
                address = "100 Feet Road, Near Phoenix Market City",
                city = "Chennai",
                pincode = "600001",
                landmark = "Phoenix Market City",
                price = 40, 
                rating = 4.2f, 
                reviewCount = 18
            ),
            // Additional requested locations
            Bike(
                id = "PR1",
                name = "TVS Jupiter",
                type = "Scooter",
                location = "Porur, Chennai",
                address = "Arcot Rd, Near Porur Junction",
                city = "Chennai",
                pincode = "600116",
                landmark = "Porur Junction",
                price = 38,
                rating = 4.1f,
                reviewCount = 16
            ),
            Bike(
                id = "PM1",
                name = "Hero Splendor Plus",
                type = "Standard",
                location = "Poonamallee, Chennai",
                address = "Mount Poonamallee Rd, Bus Depot",
                city = "Chennai",
                pincode = "600056",
                landmark = "Poonamallee Bus Depot",
                price = 35,
                rating = 4.0f,
                reviewCount = 14
            ),
            Bike(
                id = "T1",
                name = "Bajaj Avenger Street 160",
                type = "Cruiser",
                location = "Thandalam, Chennai",
                address = "NH48, Near Toll",
                city = "Chennai",
                pincode = "602105",
                landmark = "Thandalam Toll",
                price = 55,
                rating = 4.3f,
                reviewCount = 11
            ),
            Bike(
                id = "S1",
                name = "Honda Dio",
                type = "Scooter",
                location = "Saveetha University, Chennai",
                address = "Saveetha Nagar, Main Gate",
                city = "Chennai",
                pincode = "600124",
                landmark = "University Gate",
                price = 38,
                rating = 4.1f,
                reviewCount = 10
            ),
            Bike(
                id = "2", 
                name = "Ola S1 Pro", 
                type = "Electric", 
                location = "Velachery, Chennai",
                address = "Vijayanagar 2nd Main Road",
                city = "Chennai",
                pincode = "600017",
                landmark = "Opp. Bus Terminus",
                price = 60, 
                rating = 4.5f, 
                reviewCount = 12
            ),
            Bike(
                id = "3", 
                name = "Felo Electric", 
                type = "Electric", 
                location = "T. Nagar, Chennai",
                address = "Pondy Bazaar High Street",
                city = "Chennai",
                pincode = "600042",
                landmark = "Near Pothys",
                price = 55, 
                rating = 4.1f, 
                reviewCount = 25
            ),
            Bike(
                id = "4", 
                name = "Honda Activa 6G", 
                type = "Scooter", 
                location = "Anna Nagar, Chennai",
                address = "Shanthi Colony, Anna Nagar",
                city = "Chennai",
                pincode = "600040",
                landmark = "Anna Nagar Tower",
                price = 38, 
                rating = 4.3f, 
                reviewCount = 30
            ),
            Bike(
                id = "5", 
                name = "Vespa Sprint", 
                type = "Scooter", 
                location = "Adyar, Chennai",
                address = "LB Road, Kasturba Nagar",
                city = "Chennai",
                pincode = "600020",
                landmark = "Near IIT Madras",
                price = 42, 
                rating = 4.0f, 
                reviewCount = 22
            ),
            Bike(
                id = "6", 
                name = "Royal Enfield Classic 350", 
                type = "Classic", 
                location = "Mylapore, Chennai",
                address = "Luz Church Road",
                city = "Chennai",
                pincode = "600004",
                landmark = "Near Kapaleeshwarar Temple",
                price = 70, 
                rating = 4.7f, 
                reviewCount = 35
            ),
            Bike(
                id = "7", 
                name = "Royal Enfield Classic 650", 
                type = "Classic", 
                location = "Boat Club, Chennai",
                address = "Boat Club Road, RA Puram",
                city = "Chennai",
                pincode = "600028",
                landmark = "Near Boat Club",
                price = 85, 
                rating = 4.6f, 
                reviewCount = 28
            ),
            Bike(
                id = "8", 
                name = "KTM RC 390", 
                type = "Sports", 
                location = "OMR, Chennai",
                address = "Sholinganallur, OMR",
                city = "Chennai",
                pincode = "600119",
                landmark = "Near TCS Campus",
                price = 90, 
                rating = 4.8f, 
                reviewCount = 40
            ),
            Bike(
                id = "9", 
                name = "KTM 390 Adventure", 
                type = "Adventure", 
                location = "ECR, Chennai",
                address = "Thiruvanmiyur, ECR",
                city = "Chennai",
                pincode = "600041",
                landmark = "Near ECR Beach",
                price = 95, 
                rating = 4.9f, 
                reviewCount = 45
            ),
            Bike(
                id = "10", 
                name = "Harley Davidson Street 750", 
                type = "Luxury", 
                location = "Nungambakkam, Chennai",
                address = "Nungambakkam High Road",
                city = "Chennai",
                pincode = "600034",
                landmark = "Near Express Avenue Mall",
                price = 110, 
                rating = 4.9f, 
                reviewCount = 50
            ),
            // Additional bikes for same locations and varied categories
            Bike(
                id = "11",
                name = "TVS Jupiter",
                type = "Scooter",
                location = "Velachery, Chennai",
                address = "Velachery Main Road, Near Murugan Idli Shop",
                city = "Chennai",
                pincode = "600042",
                landmark = "Murugan Idli",
                price = 35,
                rating = 4.1f,
                reviewCount = 14
            ),
            Bike(
                id = "12",
                name = "Ather 450X",
                type = "Electric",
                location = "Velachery, Chennai",
                address = "Dhandeeswaram, Velachery",
                city = "Chennai",
                pincode = "600042",
                landmark = "Near Temple",
                price = 17,
                rating = 4.6f,
                reviewCount = 21
            ),
            Bike(
                id = "13",
                name = "Bajaj Pulsar 150",
                type = "Standard",
                location = "T. Nagar, Chennai",
                address = "North Usman Road",
                city = "Chennai",
                pincode = "600017",
                landmark = "Near Saravana Stores",
                price = 13,
                rating = 4.0f,
                reviewCount = 19
            ),
            Bike(
                id = "14",
                name = "Yamaha MT-15",
                type = "Sports",
                location = "Anna Nagar, Chennai",
                address = "2nd Avenue, Anna Nagar",
                city = "Chennai",
                pincode = "600040",
                landmark = "Near Tower Park",
                price = 22,
                rating = 4.4f,
                reviewCount = 16
            ),
            Bike(
                id = "15",
                name = "Suzuki Access 125",
                type = "Scooter",
                location = "Adyar, Chennai",
                address = "Sardar Patel Road",
                city = "Chennai",
                pincode = "600020",
                landmark = "Near Anna University",
                price = 11,
                rating = 4.2f,
                reviewCount = 20
            ),
            // New locations per request
            Bike(
                id = "P1",
                name = "Hero Splendor Plus",
                type = "Standard",
                location = "Poonamallee, Chennai",
                address = "Mount Poonamallee Rd, Bus Depot",
                city = "Chennai",
                pincode = "600056",
                landmark = "Poonamallee Bus Depot",
                price = 9,
                rating = 4.0f,
                reviewCount = 14
            ),
            Bike(
                id = "S1",
                name = "Honda Dio",
                type = "Scooter",
                location = "Saveetha University, Chennai",
                address = "Saveetha Nagar, Main Gate",
                city = "Chennai",
                pincode = "600124",
                landmark = "University Gate",
                price = 38,
                rating = 4.1f,
                reviewCount = 10
            ),
            Bike(
                id = "T1",
                name = "Bajaj Avenger Street 160",
                type = "Cruiser",
                location = "Thandalam, Chennai",
                address = "NH48, Near Toll",
                city = "Chennai",
                pincode = "602105",
                landmark = "Toll Booth",
                price = 55,
                rating = 4.3f,
                reviewCount = 11
            )
        )
    }

    private fun fetchBikesFromApi() {
        ApiClient.apiService.getBikes().enqueue(object : retrofit2.Callback<List<ApiBike>> {
            override fun onResponse(
                call: retrofit2.Call<List<ApiBike>>, response: retrofit2.Response<List<ApiBike>>
            ) {
                val body = response.body() ?: return
                val mapped = body.mapNotNull { api ->
                    val id = api.id ?: return@mapNotNull null
                    Bike(
                        id = id,
                        name = api.name ?: "Bike",
                        type = api.type ?: "Standard",
                        location = api.location ?: (api.city ?: "Chennai"),
                        price = (api.price_hour ?: 0).coerceAtLeast(0),
                        ownerId = api.owner_id ?: "",
                        imageUrl = api.image_url,
                        city = api.city ?: "",
                        registrationNumber = api.registration_number ?: "",
                        availabilityStatus = api.availability_status ?: "Inactive",
                        verificationStatus = api.verification_status ?: "Pending"
                    ).withDefaultsForKnownBike()
                }
                if (mapped.isNotEmpty()) {
                    allBikes = mapped
                    filteredBikes = filterBySelectedLocation(allBikes, selectedLocation)
                    updateBikeList()
                }
            }

            override fun onFailure(call: retrofit2.Call<List<ApiBike>>, t: Throwable) {
                // ignore and keep local list
            }
        })
    }
    
    private fun filterBikes() {
        val searchQuery = etSearch.text.toString().trim().lowercase()
        
        filteredBikes = allBikes.filter { bike ->
            bike.name.lowercase().contains(searchQuery) ||
            bike.type.lowercase().contains(searchQuery) ||
            bike.location.lowercase().contains(searchQuery)
        }
        
        updateBikeList()
    }
    
    private fun filterBikesByType(type: String) {
        val base = filterBySelectedLocation(allBikes, selectedLocation)
        filteredBikes = if (type == "All") base else base.filter { it.type == type }
        updateBikeList()
    }
    
    private fun updateBikeList() {
        bikeAdapter.updateList(filteredBikes)
        tvResultsCount.text = "${filteredBikes.size} bikes found"
        
        if (filteredBikes.isEmpty()) {
            tvNoResults.visibility = View.VISIBLE
            rvBikes.visibility = View.GONE
        } else {
            tvNoResults.visibility = View.GONE
            rvBikes.visibility = View.VISIBLE
        }
    }
    
    private fun updateSelectionSummary() {
        tvSelectedLocation.text = selectedLocation
        tvSelectedDate.text = selectedDate
        tvSelectedTime.text = if (isHourly) "$selectedTime ($duration hours)" else selectedTime
    }
    
    private fun showFilterDialog() {
        // Simple filter dialog - in a real app, this would be more comprehensive
        val filterOptions = arrayOf("Price: Low to High", "Price: High to Low", "Rating: High to Low", "Distance: Near to Far")
        
        AlertDialog.Builder(requireContext())
            .setTitle("Sort by")
            .setItems(filterOptions) { _, which ->
                when (which) {
                    0 -> sortBikesByPrice(true)
                    1 -> sortBikesByPrice(false)
                    2 -> sortBikesByRating()
                    3 -> sortBikesByDistance()
                }
            }
            .show()
    }
    
    private fun sortBikesByPrice(ascending: Boolean) {
        filteredBikes = if (ascending) {
            filteredBikes.sortedBy { it.price }
        } else {
            filteredBikes.sortedByDescending { it.price }
        }
        updateBikeList()
    }
    
    private fun sortBikesByRating() {
        filteredBikes = filteredBikes.sortedByDescending { it.rating }
        updateBikeList()
    }
    
    private fun sortBikesByDistance() {
        // Mock distance sorting
        filteredBikes = filteredBikes.shuffled()
        updateBikeList()
    }
    
    private fun showBookingDialog(bike: Bike) {
        val args = Bundle().apply {
            putBoolean("isHourly", isHourly)
            putInt("duration", duration)
            putString("startDate", arguments?.getString("startDate") ?: "")
            putString("endDate", arguments?.getString("endDate") ?: "")
        }
        BookingDialogRedesignFragment
            .newInstance(bike, args)
            .show(parentFragmentManager, "booking_redesign")
    }
}

class BrowseBikeAdapter(
    private var bikes: List<Bike>,
    private val onBikeClick: (Bike) -> Unit
) : RecyclerView.Adapter<BrowseBikeAdapter.BikeViewHolder>() {
    
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): BikeViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_bike_browse, parent, false)
        return BikeViewHolder(view)
    }
    
    override fun onBindViewHolder(holder: BikeViewHolder, position: Int) {
        holder.bind(bikes[position])
    }
    
    override fun getItemCount() = bikes.size
    
    fun updateList(newList: List<Bike>) {
        bikes = newList
        notifyDataSetChanged()
    }
    
    inner class BikeViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        fun bind(bike: Bike) {
            itemView.findViewById<TextView>(R.id.tvBikeName).text = bike.name
            itemView.findViewById<TextView>(R.id.tvBikeType).text = bike.type
            itemView.findViewById<TextView>(R.id.tvBikeLocation).text = bike.location
            itemView.findViewById<TextView>(R.id.tvBikePrice).text = "₹${bike.price}/hr"
            itemView.findViewById<TextView>(R.id.tvBikeRating).text = "★ ${bike.rating}"
            itemView.findViewById<TextView>(R.id.tvTimeWindow).text = "8:00 AM - 10:00 AM"
            // Optionally show a concise specs line in future on card subtitle
            
            // Set bike image
            val bikeImageRes = bike.getBikeImageRes()
            itemView.findViewById<ImageView>(R.id.ivBikeImage).setImageResource(bikeImageRes)
            
            itemView.findViewById<Button>(R.id.btnBookNow).setOnClickListener {
                onBikeClick(bike)
            }
        }
    }
}

