package com.example.bikerental

object BikeRepository {
    val allBikes = mutableListOf<Bike>()
    
    init {
        // Add sample bikes
        addSampleBikes()
    }
    
    private fun addSampleBikes() {
        // Sample bike 1 - Electric Scooter
        allBikes.add(
            Bike(
                id = "bike_001",
                name = "Ola S1 Pro",
                type = "Electric",
                location = "Chennai",
                price = 80,
                rating = 4.5f,
                reviewCount = 23,
                pickupMode = "smart_lock",
                ownerId = "user@example.com",
                ratings = mutableListOf(4.5f, 4.3f, 4.7f, 4.4f, 4.6f),
                underMaintenance = false,
                address = "Anna Nagar West",
                city = "Chennai",
                pincode = "600040",
                landmark = "Anna Nagar Metro Station",
                year = 2023,
                model = "S1 Pro",
                fuelType = "Electric",
                helmetProvided = true,
                insuranceIncluded = true,
                depositAmount = 2000,
                description = "Brand new Ola S1 Pro electric scooter with advanced features. Perfect for eco-friendly city commuting with smart connectivity and long battery life.",
                ownerPhone = "+91 9876543210"
            )
        )
        
        // Sample bike 2 - Standard Bike
        allBikes.add(
            Bike(
                id = "bike_002",
                name = "Honda Unicorn 150",
                type = "Standard",
                location = "Chennai",
                price = 60,
                rating = 4.2f,
                reviewCount = 18,
                pickupMode = "manual",
                ownerId = "user@example.com",
                ratings = mutableListOf(4.2f, 4.0f, 4.4f, 4.1f, 4.3f),
                underMaintenance = true,
                address = "T. Nagar",
                city = "Chennai",
                pincode = "600017",
                landmark = "T. Nagar Bus Stand",
                year = 2022,
                model = "Unicorn 150",
                fuelType = "Petrol",
                helmetProvided = true,
                insuranceIncluded = false,
                depositAmount = 1500,
                description = "Well-maintained Honda Unicorn 150 with excellent fuel efficiency. Ideal for daily commuting and long rides. Recently serviced and in great condition.",
                ownerPhone = "+91 9876543210"
            )
        )
        
        // Sample bike 3 - Sports Bike
        allBikes.add(
            Bike(
                id = "bike_003",
                name = "KTM RC 390",
                type = "Sports",
                location = "Chennai",
                price = 120,
                rating = 4.7f,
                reviewCount = 31,
                pickupMode = "manual",
                ownerId = "user@example.com",
                ratings = mutableListOf(4.7f, 4.8f, 4.6f, 4.9f, 4.5f),
                underMaintenance = false,
                address = "Velachery",
                city = "Chennai",
                pincode = "600042",
                landmark = "Phoenix Market City",
                year = 2023,
                model = "RC 390",
                fuelType = "Petrol",
                helmetProvided = true,
                insuranceIncluded = true,
                depositAmount = 5000,
                description = "High-performance KTM RC 390 sports bike with premium features. Perfect for thrill-seekers and experienced riders. Includes premium helmet and full insurance coverage.",
                ownerPhone = "+91 9876543210"
            )
        )

        // Sample bike 4 - Classic Bike
        allBikes.add(
            Bike(
                id = "bike_004",
                name = "Royal Enfield Classic 350",
                type = "Classic",
                location = "Chennai",
                price = 90,
                rating = 4.6f,
                reviewCount = 28,
                pickupMode = "manual",
                ownerId = "user@example.com",
                ratings = mutableListOf(4.6f, 4.5f, 4.7f, 4.4f, 4.8f),
                underMaintenance = false,
                address = "Mylapore",
                city = "Chennai",
                pincode = "600004",
                landmark = "Kapaleeshwarar Temple",
                year = 2022,
                model = "Classic 350",
                fuelType = "Petrol",
                helmetProvided = true,
                insuranceIncluded = true,
                depositAmount = 3000,
                description = "Timeless Royal Enfield Classic 350 with authentic retro styling. Perfect for heritage rides and city cruising. Well-maintained with premium accessories.",
                ownerPhone = "+91 9876543210"
            )
        )

        // Sample bike 5 - Adventure Bike
        allBikes.add(
            Bike(
                id = "bike_005",
                name = "KTM 390 Adventure",
                type = "Adventure",
                location = "Chennai",
                price = 110,
                rating = 4.8f,
                reviewCount = 19,
                pickupMode = "manual",
                ownerId = "user@example.com",
                ratings = mutableListOf(4.8f, 4.9f, 4.7f, 4.8f, 4.6f),
                underMaintenance = false,
                address = "OMR",
                city = "Chennai",
                pincode = "600113",
                landmark = "DLF Cybercity",
                year = 2023,
                model = "390 Adventure",
                fuelType = "Petrol",
                helmetProvided = true,
                insuranceIncluded = true,
                depositAmount = 4000,
                description = "Adventure-ready KTM 390 Adventure with off-road capabilities. Perfect for weekend getaways and highway touring. Includes adventure gear.",
                ownerPhone = "+91 9876543210"
            )
        )

        // Sample bike 6 - Scooter
        allBikes.add(
            Bike(
                id = "bike_006",
                name = "Honda Activa 6G",
                type = "Scooter",
                location = "Chennai",
                price = 45,
                rating = 4.3f,
                reviewCount = 42,
                pickupMode = "manual",
                ownerId = "user@example.com",
                ratings = mutableListOf(4.3f, 4.2f, 4.4f, 4.1f, 4.5f),
                underMaintenance = false,
                address = "Adyar",
                city = "Chennai",
                pincode = "600020",
                landmark = "IIT Madras",
                year = 2021,
                model = "Activa 6G",
                fuelType = "Petrol",
                helmetProvided = true,
                insuranceIncluded = false,
                depositAmount = 1000,
                description = "Reliable Honda Activa 6G scooter perfect for daily commuting. Excellent fuel efficiency and easy handling. Great for city rides.",
                ownerPhone = "+91 9876543210"
            )
        )

        // Sample bike 7 - Luxury Bike
        allBikes.add(
            Bike(
                id = "bike_007",
                name = "Harley Davidson Street 750",
                type = "Luxury",
                location = "Chennai",
                price = 150,
                rating = 4.9f,
                reviewCount = 15,
                pickupMode = "manual",
                ownerId = "user@example.com",
                ratings = mutableListOf(4.9f, 5.0f, 4.8f, 4.9f, 4.7f),
                underMaintenance = false,
                address = "Boat Club",
                city = "Chennai",
                pincode = "600028",
                landmark = "Marina Beach",
                year = 2023,
                model = "Street 750",
                fuelType = "Petrol",
                helmetProvided = true,
                insuranceIncluded = true,
                depositAmount = 8000,
                description = "Premium Harley Davidson Street 750 with iconic American styling. Perfect for luxury rides and special occasions. Includes premium leather gear.",
                ownerPhone = "+91 9876543210"
            )
        )

        // Sample bike 8 - Electric Bike
        allBikes.add(
            Bike(
                id = "bike_008",
                name = "Felo Electric",
                type = "Electric",
                location = "Chennai",
                price = 70,
                rating = 4.4f,
                reviewCount = 26,
                pickupMode = "smart_lock",
                ownerId = "user@example.com",
                ratings = mutableListOf(4.4f, 4.3f, 4.5f, 4.2f, 4.6f),
                underMaintenance = false,
                address = "Porur",
                city = "Chennai",
                pincode = "600116",
                landmark = "SRM University",
                year = 2023,
                model = "Felo Electric",
                fuelType = "Electric",
                helmetProvided = true,
                insuranceIncluded = true,
                depositAmount = 2500,
                description = "Modern Felo Electric bike with smart features and eco-friendly design. Perfect for tech-savvy riders who care about the environment.",
                ownerPhone = "+91 9876543210"
            )
        )

        // Sample bike 9 - Vespa Scooter
        allBikes.add(
            Bike(
                id = "bike_009",
                name = "Vespa Sprint",
                type = "Scooter",
                location = "Chennai",
                price = 65,
                rating = 4.5f,
                reviewCount = 33,
                pickupMode = "manual",
                ownerId = "user@example.com",
                ratings = mutableListOf(4.5f, 4.4f, 4.6f, 4.3f, 4.7f),
                underMaintenance = false,
                address = "Besant Nagar",
                city = "Chennai",
                pincode = "600090",
                landmark = "Elliots Beach",
                year = 2022,
                model = "Sprint",
                fuelType = "Petrol",
                helmetProvided = true,
                insuranceIncluded = false,
                depositAmount = 1800,
                description = "Stylish Vespa Sprint with Italian design and premium build quality. Perfect for fashion-conscious riders who want both style and performance.",
                ownerPhone = "+91 9876543210"
            )
        )

        // Sample bike 10 - Royal Enfield Classic 650
        allBikes.add(
            Bike(
                id = "bike_010",
                name = "Royal Enfield Classic 650",
                type = "Classic",
                location = "Chennai",
                price = 100,
                rating = 4.7f,
                reviewCount = 22,
                pickupMode = "manual",
                ownerId = "user@example.com",
                ratings = mutableListOf(4.7f, 4.6f, 4.8f, 4.5f, 4.9f),
                underMaintenance = true,
                address = "Egmore",
                city = "Chennai",
                pincode = "600008",
                landmark = "Central Station",
                year = 2023,
                model = "Classic 650",
                fuelType = "Petrol",
                helmetProvided = true,
                insuranceIncluded = true,
                depositAmount = 3500,
                description = "Powerful Royal Enfield Classic 650 with enhanced performance and classic styling. Perfect for long rides and highway cruising.",
                ownerPhone = "+91 9876543210"
            )
        )

        // Admin Sample Bike 1 - Premium Sports Bike
        allBikes.add(
            Bike(
                id = "admin_bike_001",
                name = "Ducati Panigale V4",
                type = "Sports",
                location = "Chennai",
                price = 200,
                rating = 4.9f,
                reviewCount = 35,
                pickupMode = "manual",
                ownerId = "admin@demo.com",
                ratings = mutableListOf(4.9f, 5.0f, 4.8f, 4.9f, 4.7f),
                underMaintenance = false,
                address = "Alwarpet",
                city = "Chennai",
                pincode = "600018",
                landmark = "Luxury Car Showroom",
                year = 2024,
                model = "Panigale V4",
                fuelType = "Petrol",
                helmetProvided = true,
                insuranceIncluded = true,
                depositAmount = 10000,
                description = "Exclusive Ducati Panigale V4 with Italian engineering excellence. Premium sports bike with advanced electronics and race-inspired design. Perfect for experienced riders seeking ultimate performance.",
                ownerPhone = "+91 9876543211"
            )
        )

        // Admin Sample Bike 2 - Adventure Touring Bike
        allBikes.add(
            Bike(
                id = "admin_bike_002",
                name = "BMW R 1250 GS Adventure",
                type = "Adventure",
                location = "Chennai",
                price = 180,
                rating = 4.8f,
                reviewCount = 28,
                pickupMode = "manual",
                ownerId = "admin@demo.com",
                ratings = mutableListOf(4.8f, 4.9f, 4.7f, 4.8f, 4.6f),
                underMaintenance = false,
                address = "Teynampet",
                city = "Chennai",
                pincode = "600086",
                landmark = "BMW Showroom",
                year = 2023,
                model = "R 1250 GS Adventure",
                fuelType = "Petrol",
                helmetProvided = true,
                insuranceIncluded = true,
                depositAmount = 8000,
                description = "Professional BMW R 1250 GS Adventure with advanced touring capabilities. Equipped with premium features including GPS navigation, heated grips, and adventure luggage. Ideal for long-distance touring and off-road adventures.",
                ownerPhone = "+91 9876543211"
            )
        )
    }
} 