package com.example.bikerental

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.ImageView
import android.widget.Toast
import androidx.core.content.ContextCompat

class HomeFragment : Fragment() {
    private lateinit var bikeAdapter: BikeAdapter
    private lateinit var allBikes: List<Bike>

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_home, container, false)

        // Load from API, fallback to local if network fails
        allBikes = getAllBikes()
        fetchBikesFromApi()

        // Set up RecyclerView as grid
        val rvBikes = view.findViewById<RecyclerView>(R.id.rvBikes)
        rvBikes.layoutManager = GridLayoutManager(requireContext(), 2)
        bikeAdapter = BikeAdapter(allBikes) { bike ->
            showBookingDialog(bike)
        }
        rvBikes.adapter = bikeAdapter

        // Add: Allow user to rate a bike on long click
        bikeAdapter.setOnItemLongClickListener { bike, position ->
            showRatingDialog(bike, position)
        }

        // Enhanced filter buttons with chip styling
        val btnAll = view.findViewById<Button>(R.id.btnAll)
        val btnStandard = view.findViewById<Button>(R.id.btnStandard)
        val btnScooter = view.findViewById<Button>(R.id.btnScooter)
        val btnElectric = view.findViewById<Button>(R.id.btnElectric)
        val btnSports = view.findViewById<Button>(R.id.btnSports)
        val btnClassic = view.findViewById<Button>(R.id.btnClassic)
        val btnAdventure = view.findViewById<Button>(R.id.btnAdventure)
        val btnLuxury = view.findViewById<Button>(R.id.btnLuxury)
        val btnOthers = view.findViewById<Button>(R.id.btnOthers)
        val chipButtons = listOf(btnAll, btnStandard, btnScooter, btnElectric, btnSports, btnClassic, btnAdventure, btnLuxury, btnOthers)
        
        fun setActiveChip(active: Button) {
            chipButtons.forEach { btn ->
                val isSelected = btn == active
                btn.isSelected = isSelected
                if (isSelected) {
                    btn.setBackgroundResource(R.drawable.bg_chip_selected)
                    btn.setTextColor(ContextCompat.getColor(requireContext(), android.R.color.white))
                } else {
                    btn.setBackgroundResource(R.drawable.bg_chip_unselected)
                    btn.setTextColor(ContextCompat.getColor(requireContext(), R.color.purple))
                }
            }
        }

        btnAll.setOnClickListener {
            filterBikes("All")
            setActiveChip(btnAll)
        }
        btnStandard.setOnClickListener {
            filterBikes("Standard")
            setActiveChip(btnStandard)
        }
        btnScooter.setOnClickListener {
            filterBikes("Scooter")
            setActiveChip(btnScooter)
        }
        btnElectric.setOnClickListener {
            filterBikes("Electric")
            setActiveChip(btnElectric)
        }
        btnSports.setOnClickListener {
            filterBikes("Sports")
            setActiveChip(btnSports)
        }
        btnClassic.setOnClickListener {
            filterBikes("Classic")
            setActiveChip(btnClassic)
        }
        btnAdventure.setOnClickListener {
            filterBikes("Adventure")
            setActiveChip(btnAdventure)
        }
        btnLuxury.setOnClickListener {
            filterBikes("Luxury")
            setActiveChip(btnLuxury)
        }
        btnOthers.setOnClickListener {
            filterBikes("Others")
            setActiveChip(btnOthers)
        }

        // Set location with GPS option
        val tvLocation = view.findViewById<TextView>(R.id.tvLocation)
        tvLocation.text = "Saveetha University, Chennai"
        tvLocation.setOnClickListener {
            val options = arrayOf("Use GPS", "Enter manually")
            androidx.appcompat.app.AlertDialog.Builder(requireContext())
                .setTitle("Choose Location")
                .setItems(options) { d, which ->
                    if (which == 0) {
                        tryUseGps(tvLocation)
                    } else {
                        val input = android.widget.EditText(requireContext())
                        input.hint = "Enter location"
                        androidx.appcompat.app.AlertDialog.Builder(requireContext())
                            .setTitle("Enter Location")
                            .setView(input)
                            .setPositiveButton("OK") { dd, _ ->
                                val t = input.text.toString().trim()
                                if (t.isNotEmpty()) tvLocation.text = t
                                dd.dismiss()
                            }
                            .setNegativeButton("Cancel") { dd, _ -> dd.dismiss() }
                            .show()
                    }
                    d.dismiss()
                }
                .show()
        }

        // Set up search with autocomplete
        val etSearch = view.findViewById<EditText>(R.id.etSearch)
        val rvSuggestions = view.findViewById<RecyclerView>(R.id.rvSuggestions)
        
        // Initialize suggestions adapter
        val suggestionsAdapter = LocationSuggestionAdapter(emptyList()) { suggestion ->
            etSearch.setText(suggestion.name)
            rvSuggestions.visibility = View.GONE
            
            // Launch MapsActivity with selected location
            val intent = Intent(requireContext(), MapsActivity::class.java)
            intent.putExtra("search_query", suggestion.name)
            startActivity(intent)
        }
        
        rvSuggestions.layoutManager = androidx.recyclerview.widget.LinearLayoutManager(requireContext())
        rvSuggestions.adapter = suggestionsAdapter
        
        // Add divider between suggestions
        rvSuggestions.addItemDecoration(object : androidx.recyclerview.widget.RecyclerView.ItemDecoration() {
            override fun getItemOffsets(outRect: android.graphics.Rect, view: View, parent: androidx.recyclerview.widget.RecyclerView, state: androidx.recyclerview.widget.RecyclerView.State) {
                if (parent.getChildAdapterPosition(view) < parent.adapter?.itemCount ?: 0 - 1) {
                    outRect.bottom = 1
                }
            }
        })
        
        // Sample location suggestions
        val allLocations = listOf(
            LocationSuggestionAdapter.LocationSuggestion("Marina Beach, Chennai", "Landmark", "Marina Beach, Chennai, Tamil Nadu"),
            LocationSuggestionAdapter.LocationSuggestion("T. Nagar, Chennai", "Area", "T. Nagar, Chennai, Tamil Nadu"),
            LocationSuggestionAdapter.LocationSuggestion("Velachery, Chennai", "Area", "Velachery, Chennai, Tamil Nadu"),
            LocationSuggestionAdapter.LocationSuggestion("Anna Nagar, Chennai", "Area", "Anna Nagar, Chennai, Tamil Nadu"),
            LocationSuggestionAdapter.LocationSuggestion("Phoenix Market City", "Mall", "Phoenix Market City, Velachery, Chennai"),
            LocationSuggestionAdapter.LocationSuggestion("Central Station", "Transport", "Chennai Central Station, Chennai"),
            LocationSuggestionAdapter.LocationSuggestion("Chennai Airport", "Transport", "Chennai International Airport, Chennai"),
            LocationSuggestionAdapter.LocationSuggestion("MGM Beach", "Landmark", "MGM Beach, Chennai"),
            LocationSuggestionAdapter.LocationSuggestion("VGP Universal Kingdom", "Entertainment", "VGP Universal Kingdom, Chennai"),
            LocationSuggestionAdapter.LocationSuggestion("Express Avenue Mall", "Mall", "Express Avenue Mall, Chennai"),
            LocationSuggestionAdapter.LocationSuggestion("Forum Vijaya Mall", "Mall", "Forum Vijaya Mall, Chennai"),
            LocationSuggestionAdapter.LocationSuggestion("Spencer Plaza", "Mall", "Spencer Plaza, Chennai"),
            LocationSuggestionAdapter.LocationSuggestion("Egmore Station", "Transport", "Egmore Railway Station, Chennai"),
            LocationSuggestionAdapter.LocationSuggestion("Tambaram Station", "Transport", "Tambaram Railway Station, Chennai"),
            LocationSuggestionAdapter.LocationSuggestion("Guindy National Park", "Park", "Guindy National Park, Chennai"),
            LocationSuggestionAdapter.LocationSuggestion("Vandalur Zoo", "Entertainment", "Arignar Anna Zoological Park, Vandalur"),
            LocationSuggestionAdapter.LocationSuggestion("Mahabalipuram", "Tourist", "Mahabalipuram, Tamil Nadu"),
            LocationSuggestionAdapter.LocationSuggestion("Kanchipuram", "City", "Kanchipuram, Tamil Nadu"),
            LocationSuggestionAdapter.LocationSuggestion("Vellore", "City", "Vellore, Tamil Nadu"),
            LocationSuggestionAdapter.LocationSuggestion("Pondicherry", "City", "Pondicherry, Union Territory")
        )
        
        // Text change listener for autocomplete
        etSearch.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            
            override fun afterTextChanged(s: android.text.Editable?) {
                val query = s.toString().trim()
                if (query.length >= 2) {
                    val filtered = allLocations.filter { location ->
                        location.name.contains(query, ignoreCase = true) ||
                        location.fullAddress.contains(query, ignoreCase = true)
                    }.take(8) // Limit to 8 suggestions
                    
                    if (filtered.isNotEmpty()) {
                        suggestionsAdapter.updateSuggestions(filtered)
                        rvSuggestions.visibility = View.VISIBLE
                    } else {
                        rvSuggestions.visibility = View.GONE
                    }
                } else {
                    rvSuggestions.visibility = View.GONE
                }
            }
        })
        
        // Hide suggestions when clicking outside
        etSearch.setOnFocusChangeListener { _, hasFocus ->
            if (!hasFocus) {
                rvSuggestions.visibility = View.GONE
            }
        }
        
        // Hide suggestions when clicking on the main layout
        view.setOnClickListener {
            rvSuggestions.visibility = View.GONE
            etSearch.clearFocus()
        }
        
        // Handle search submission
        etSearch.setOnEditorActionListener { _, _, _ ->
            val query = etSearch.text.toString().trim()
            if (query.isNotEmpty()) {
                // Launch MapsActivity with search query
                val intent = Intent(requireContext(), MapsActivity::class.java)
                intent.putExtra("search_query", query)
                startActivity(intent)
            }
            true
        }

        // Set default selected chip
        setActiveChip(btnAll)

        return view
    }

    private fun filterBikes(type: String) {
        val filtered = if (type == "All") {
            allBikes
        } else {
            allBikes.filter { it.type == type }
        }
        bikeAdapter.updateList(filtered)
    }

    private fun showBookingDialog(bike: Bike) {
        BookingDialogRedesignFragment
            .newInstance(bike)
            .show(parentFragmentManager, "booking_redesign")
    }

    private fun tryUseGps(tv: TextView) {
        val lm = requireContext().getSystemService(android.content.Context.LOCATION_SERVICE) as android.location.LocationManager
        val hasPerm = androidx.core.content.ContextCompat.checkSelfPermission(requireContext(), android.Manifest.permission.ACCESS_FINE_LOCATION) == android.content.pm.PackageManager.PERMISSION_GRANTED
        if (!hasPerm) {
            requestPermissions(arrayOf(android.Manifest.permission.ACCESS_FINE_LOCATION), 101)
            return
        }
        val last = lm.getLastKnownLocation(android.location.LocationManager.GPS_PROVIDER)
        if (last != null) {
            tv.text = "${last.latitude}, ${last.longitude}"
        } else {
            android.widget.Toast.makeText(requireContext(), "GPS not available, using Saveetha University", android.widget.Toast.LENGTH_SHORT).show()
            tv.text = "Saveetha University, Chennai"
        }
    }

    private fun showRatingDialog(bike: Bike, position: Int) {
        // Simple rating dialog
        val rating = (1..5).random().toFloat()
        bike.ratings.add(rating)
        bikeAdapter.notifyItemChanged(position)
        Toast.makeText(context, "Rated ${bike.name} with $rating stars!", Toast.LENGTH_SHORT).show()
    }

    private fun getAllBikes(): List<Bike> {
        // Get bikes from repository and combine with default bikes including new areas
        val defaultBikes = listOf(
            Bike(
                id = "1", 
                name = "Honda Unicorn 150", 
                type = "Standard", 
                location = "Marina Beach, Chennai",
                address = "Beach Road, Marina Beach",
                city = "Chennai",
                pincode = "600001",
                landmark = "Near Marina Beach",
                price = 40, 
                rating = 4.2f, 
                reviewCount = 18
            ),
            // New requested locations
            Bike(
                id = "P1",
                name = "Hero Splendor Plus",
                type = "Standard",
                location = "Poonamallee, Chennai",
                address = "Mount Poonamallee Rd, Bus Depot",
                city = "Chennai",
                pincode = "600056",
                landmark = "Poonamallee Bus Depot",
                price = 35,
                rating = 4.0f,
                reviewCount = 14
            ),
            Bike(
                id = "PR1",
                name = "TVS Jupiter",
                type = "Scooter",
                location = "Porur, Chennai",
                address = "Arcot Rd, Near Porur Junction",
                city = "Chennai",
                pincode = "600116",
                landmark = "Porur Junction",
                price = 38,
                rating = 4.1f,
                reviewCount = 16
            ),
            Bike(
                id = "T1",
                name = "Bajaj Avenger Street 160",
                type = "Cruiser",
                location = "Thandalam, Chennai",
                address = "NH48, Near Toll",
                city = "Chennai",
                pincode = "602105",
                landmark = "Thandalam Toll",
                price = 55,
                rating = 4.3f,
                reviewCount = 11
            ),
            Bike(
                id = "S1",
                name = "Honda Dio",
                type = "Scooter",
                location = "Saveetha University, Chennai",
                address = "Saveetha Nagar, Main Gate",
                city = "Chennai",
                pincode = "600124",
                landmark = "University Gate",
                price = 38,
                rating = 4.1f,
                reviewCount = 10
            ),
            Bike(
                id = "11",
                name = "Hero Splendor",
                type = "Standard",
                location = "Poonamallee, Chennai",
                address = "Mount Poonamallee Rd",
                city = "Chennai",
                pincode = "600056",
                landmark = "Bus Depot",
                price = 9,
                rating = 4.0f,
                reviewCount = 12
            ),
            Bike(
                id = "12",
                name = "Honda Dio",
                type = "Scooter",
                location = "Saveetha University, Chennai",
                address = "Saveetha Nagar",
                city = "Chennai",
                pincode = "600124",
                landmark = "Main Gate",
                price = 10,
                rating = 4.1f,
                reviewCount = 9
            ),
            Bike(
                id = "13",
                name = "Bajaj Avenger",
                type = "Cruiser",
                location = "Thandalam, Chennai",
                address = "Sriperumbudur Taluk",
                city = "Chennai",
                pincode = "602105",
                landmark = "Near Toll",
                price = 16,
                rating = 4.3f,
                reviewCount = 11
            ),
            Bike(
                id = "2", 
                name = "Ola S1 Pro", 
                type = "Electric", 
                location = "T. Nagar, Chennai",
                address = "Pondy Bazaar, T. Nagar",
                city = "Chennai",
                pincode = "600017",
                landmark = "Near Pondy Bazaar",
                price = 18, 
                rating = 4.5f, 
                reviewCount = 12,
                model = "S1 Pro Gen2",
                fuelType = "Electric",
                batteryCapacityKwh = 4.0f,
                powerHp = 11.0f,
                torqueNm = 58f,
                rangeKm = 181
            ),
            Bike(
                id = "3", 
                name = "Felo Electric", 
                type = "Electric", 
                location = "Velachery, Chennai",
                address = "Phoenix Market City, Velachery",
                city = "Chennai",
                pincode = "600042",
                landmark = "Near Phoenix Mall",
                price = 15, 
                rating = 4.1f, 
                reviewCount = 25
            ),
            Bike(
                id = "4", 
                name = "Honda Activa 6G", 
                type = "Scooter", 
                location = "Anna Nagar, Chennai",
                address = "Anna Nagar West, 10th Avenue",
                city = "Chennai",
                pincode = "600040",
                landmark = "Near Anna Nagar Tower",
                price = 10, 
                rating = 4.3f, 
                reviewCount = 30
            ),
            Bike(
                id = "5", 
                name = "Vespa Sprint", 
                type = "Scooter", 
                location = "Adyar, Chennai",
                address = "Kasturba Nagar, Adyar",
                city = "Chennai",
                pincode = "600020",
                landmark = "Near IIT Madras",
                price = 14, 
                rating = 4.0f, 
                reviewCount = 22
            ),
            Bike(
                id = "6", 
                name = "Royal Enfield Classic 350", 
                type = "Classic", 
                location = "Mylapore, Chennai",
                address = "Luz Corner, Mylapore",
                city = "Chennai",
                pincode = "600004",
                landmark = "Near Kapaleeshwarar Temple",
                price = 25, 
                rating = 4.7f, 
                reviewCount = 35,
                model = "Classic 350",
                fuelType = "Petrol",
                engineCc = 349,
                powerHp = 20.2f,
                torqueNm = 27f,
                mileageKmpl = 35f
            ),
            Bike(
                id = "7", 
                name = "Royal Enfield Classic 650", 
                type = "Classic", 
                location = "Boat Club, Chennai",
                address = "Boat Club Road, RA Puram",
                city = "Chennai",
                pincode = "600028",
                landmark = "Near Boat Club",
                price = 30, 
                rating = 4.6f, 
                reviewCount = 28
            ),
            Bike(
                id = "8", 
                name = "KTM RC 390", 
                type = "Sports", 
                location = "OMR, Chennai",
                address = "Old Mahabalipuram Road, Sholinganallur",
                city = "Chennai",
                pincode = "600119",
                landmark = "Near TCS Campus",
                price = 35, 
                rating = 4.8f, 
                reviewCount = 40
            ),
            Bike(
                id = "9", 
                name = "KTM 390 Adventure", 
                type = "Adventure", 
                location = "ECR, Chennai",
                address = "East Coast Road, Thiruvanmiyur",
                city = "Chennai",
                pincode = "600041",
                landmark = "Near ECR Beach",
                price = 40, 
                rating = 4.9f, 
                reviewCount = 45
            ),
            Bike(
                id = "10", 
                name = "Harley Davidson Street 750", 
                type = "Luxury", 
                location = "Nungambakkam, Chennai",
                address = "Nungambakkam High Road",
                city = "Chennai",
                pincode = "600034",
                landmark = "Near Express Avenue Mall",
                price = 50, 
                rating = 4.9f, 
                reviewCount = 50
            )
        )
        
        // Combine default bikes with bikes from repository
        return defaultBikes + BikeRepository.allBikes
    }

    private fun fetchBikesFromApi() {
        ApiClient.apiService.getBikes().enqueue(object : retrofit2.Callback<List<ApiBike>> {
            override fun onResponse(
                call: retrofit2.Call<List<ApiBike>>, response: retrofit2.Response<List<ApiBike>>
            ) {
                val body = response.body() ?: return
                val mapped = body.mapNotNull { api ->
                    val id = api.id ?: return@mapNotNull null
                    Bike(
                        id = id,
                        name = api.name ?: "Bike",
                        type = api.type ?: "Standard",
                        location = api.location ?: (api.city ?: "Chennai"),
                        price = (api.price_hour ?: 0).coerceAtLeast(0),
                        ownerId = api.owner_id ?: "",
                        imageUrl = api.image_url,
                        city = api.city ?: "",
                        registrationNumber = api.registration_number ?: "",
                        availabilityStatus = api.availability_status ?: "Inactive",
                        verificationStatus = api.verification_status ?: "Pending"
                    ).withDefaultsForKnownBike()
                }
                if (mapped.isNotEmpty()) {
                    allBikes = mapped
                    bikeAdapter.updateList(allBikes)
                }
            }

            override fun onFailure(call: retrofit2.Call<List<ApiBike>>, t: Throwable) {
                // Silent fallback to local list
            }
        })
    }
}

// Adapter for RecyclerView
class BikeAdapter(
    private var bikes: List<Bike>,
    private val onBikeClick: (Bike) -> Unit
) : RecyclerView.Adapter<BikeAdapter.BikeViewHolder>() {
    
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): BikeViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_bike_card, parent, false)
        return BikeViewHolder(view)
    }
    
    override fun onBindViewHolder(holder: BikeViewHolder, position: Int) {
        holder.bind(bikes[position])
    }
    
    override fun getItemCount() = bikes.size

    fun updateList(newList: List<Bike>) {
        bikes = newList
        notifyDataSetChanged()
    }

    fun setOnItemLongClickListener(listener: (Bike, Int) -> Unit) {
        this.onItemLongClickListener = listener
    }

    private var onItemLongClickListener: ((Bike, Int) -> Unit)? = null

    inner class BikeViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        fun bind(bike: Bike) {
            // Set bike name
            itemView.findViewById<TextView>(R.id.tvBikeName).text = bike.name
            
            // Set bike image based on bike name
            val bikeImageRes = bike.getBikeImageRes()
            itemView.findViewById<ImageView>(R.id.ivBikeImage).setImageResource(bikeImageRes)
            
            // Set bike type label
            itemView.findViewById<TextView>(R.id.tvBikeType).text = bike.type.uppercase()
            
            // Set up favorite button
            val btnFavorite = itemView.findViewById<ImageView>(R.id.btnFavorite)
            val isSaved = SavedBikesManager.isBikeSaved(bike.id)
            btnFavorite.tag = isSaved
            btnFavorite.setImageResource(
                if (isSaved) android.R.drawable.btn_star_big_on 
                else android.R.drawable.btn_star_big_off
            )
            
            btnFavorite.setOnClickListener {
                toggleFavorite(btnFavorite, bike)
            }
            
            itemView.setOnClickListener {
                onBikeClick(bike)
            }
            itemView.setOnLongClickListener {
                onItemLongClickListener?.invoke(bike, adapterPosition)
                true
            }
        }
        
        private fun toggleFavorite(btnFavorite: ImageView, bike: Bike) {
            val isFavorite = btnFavorite.tag as? Boolean ?: false
            if (isFavorite) {
                // Remove from saved bikes
                SavedBikesManager.removeBike(bike.id)
                btnFavorite.setImageResource(android.R.drawable.btn_star_big_off)
                btnFavorite.tag = false
                Toast.makeText(itemView.context, R.string.removed_from_favorites, Toast.LENGTH_SHORT).show()
            } else {
                // Add to saved bikes
                SavedBikesManager.saveBike(bike)
                btnFavorite.setImageResource(android.R.drawable.btn_star_big_on)
                btnFavorite.tag = true
                Toast.makeText(itemView.context, R.string.added_to_favorites, Toast.LENGTH_SHORT).show()
            }
        }
    }
} 