package com.example.bikerental

import android.app.Dialog
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.widget.ImageView
import android.widget.TextView
import androidx.fragment.app.DialogFragment
import com.google.android.material.button.MaterialButton

data class PromptBooking(
    val id: String,
    val bikeId: String,
    val bikeName: String,
    val imageRes: Int,
    val startMs: Long,
    val endMs: Long,
    val isHourly: Boolean,
    val hourlyRate: Double,
    val locationLabel: String
)

class BookingDialogPrompt : DialogFragment() {

    private var booking: PromptBooking? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        retainInstance = true
    }

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        val v = LayoutInflater.from(requireContext()).inflate(R.layout.dialog_booking_prompt, null, false)
        val tvBikeName = v.findViewById<TextView>(R.id.tvBikeName)
        val ivBike = v.findViewById<ImageView>(R.id.ivBike)
        val tvTimeWindow = v.findViewById<TextView>(R.id.tvTimeWindow)
        val ivMapPreview = v.findViewById<ImageView>(R.id.ivMapPreview)
        val btnCancel = v.findViewById<MaterialButton>(R.id.btnCancel)
        val btnConfirm = v.findViewById<MaterialButton>(R.id.btnConfirm)

        booking?.let { b ->
            tvBikeName.text = b.bikeName
            if (b.imageRes != 0) ivBike.setImageResource(b.imageRes) else ivBike.setImageResource(R.drawable.re350_classic)
            tvTimeWindow.text = formatWindowReadablePrompt(b.startMs, b.endMs, b.isHourly)
            ivMapPreview.setOnClickListener { openMapWithLocation(requireContext(), b.locationLabel) }
        }

        btnCancel.setOnClickListener { dismissAllowingStateLoss() }
        btnConfirm.setOnClickListener {
            val b = booking ?: return@setOnClickListener
            if (!canBookNow(requireContext(), b.startMs, b.endMs)) {
                android.widget.Toast.makeText(requireContext(), "You already have an overlapping booking.", android.widget.Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            saveBooking(requireContext(), b)
            startActivity(Intent(requireContext(), PaymentActivityPrompt::class.java).apply {
                putExtra("bikeName", b.bikeName)
                putExtra("imageRes", b.imageRes)
                putExtra("startMs", b.startMs)
                putExtra("endMs", b.endMs)
                putExtra("isHourly", b.isHourly)
                putExtra("hourlyRate", b.hourlyRate)
                putExtra("locationLabel", b.locationLabel)
            })
            dismissAllowingStateLoss()
        }

        return androidx.appcompat.app.AlertDialog.Builder(requireContext())
            .setView(v)
            .create()
    }

    private fun openMapWithLocation(context: Context, label: String) {
        val uri = Uri.parse("geo:0,0?q=" + Uri.encode(label))
        val intent = Intent(Intent.ACTION_VIEW, uri)
        intent.setPackage("com.google.android.apps.maps")
        if (intent.resolveActivity(context.packageManager) != null) context.startActivity(intent)
    }

    private fun saveBooking(context: Context, booking: PromptBooking) {
        val prefs = context.getSharedPreferences("bookings", Context.MODE_PRIVATE)
        val json = org.json.JSONObject().apply {
            put("id", booking.id)
            put("bikeId", booking.bikeId)
            put("bikeName", booking.bikeName)
            put("imageRes", booking.imageRes)
            put("startMs", booking.startMs)
            put("endMs", booking.endMs)
            put("isHourly", booking.isHourly)
            put("hourlyRate", booking.hourlyRate)
            put("locationLabel", booking.locationLabel)
        }.toString()

        val set = prefs.getStringSet("items", mutableSetOf())?.toMutableSet() ?: mutableSetOf()
        set.add(json)
        prefs.edit().putStringSet("items", set).apply()
    }

    private fun canBookNow(context: Context, newStart: Long, newEnd: Long): Boolean {
        val prefs = context.getSharedPreferences("bookings", Context.MODE_PRIVATE)
        val existing = prefs.getStringSet("items", emptySet()) ?: emptySet()
        for (s in existing) {
            try {
                val o = org.json.JSONObject(s)
                val a = o.getLong("startMs")
                val b = o.getLong("endMs")
                if (a < newEnd && newStart < b) return false
            } catch (_: Throwable) { }
        }
        return true
    }

    companion object {
        fun newInstance(
            bikeId: String,
            bikeName: String,
            imageRes: Int,
            timeWindowStartMs: Long,
            timeWindowEndMs: Long,
            isHourly: Boolean,
            hourlyRate: Double,
            locationLabel: String
        ): BookingDialogPrompt {
            val f = BookingDialogPrompt()
            f.booking = PromptBooking(
                id = java.util.UUID.randomUUID().toString(),
                bikeId = bikeId,
                bikeName = bikeName,
                imageRes = imageRes,
                startMs = timeWindowStartMs,
                endMs = timeWindowEndMs,
                isHourly = isHourly,
                hourlyRate = hourlyRate,
                locationLabel = locationLabel
            )
            return f
        }
    }
}

fun formatWindowReadablePrompt(startMs: Long, endMs: Long, isHourly: Boolean): String {
    val zone = java.time.ZoneId.systemDefault()
    val start = java.time.Instant.ofEpochMilli(startMs).atZone(zone)
    val end = java.time.Instant.ofEpochMilli(endMs).atZone(zone)
    return if (isHourly) {
        "${start.toLocalDate()} ${start.toLocalTime()} → ${end.toLocalDate()} ${end.toLocalTime()}"
    } else {
        "${start.toLocalDate()} → ${end.toLocalDate()}"
    }
}










