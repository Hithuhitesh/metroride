package com.example.bikerental

object BookingRepository {
    val allBookings = mutableListOf<Booking>()
} 