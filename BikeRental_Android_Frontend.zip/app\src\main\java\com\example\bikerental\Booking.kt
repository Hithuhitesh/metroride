package com.example.bikerental

data class Booking(
    val bikeName: String,
    val renterName: String,
    val location: String,
    val startDate: String,
    val endDate: String,
    val pickupTime: String = "",
    val dropoffTime: String = "",
    val price: Int,
    val imageRes: Int,
    val status: String,
    val pickupMode: String = "manual",
    val lastKnownLocation: String = "Unknown",
    val bookingCode: String = "",
    val apiId: String? = null,
    // User details captured during checkout
    val userName: String = "",
    val licenseNumber: String = "",
    val mobileNumber: String = "",
    val email: String = ""
) 