package com.example.bikerental

import android.content.Context
import android.location.Location
import com.google.android.gms.maps.model.LatLng
import kotlin.math.roundToInt

object MapUtils {
    
    /**
     * Calculate distance between two LatLng points in meters
     */
    fun calculateDistance(from: LatLng, to: LatLng): Float {
        val results = FloatArray(1)
        Location.distanceBetween(from.latitude, from.longitude, to.latitude, to.longitude, results)
        return results[0]
    }
    
    /**
     * Format distance for display
     */
    fun formatDistance(distanceInMeters: Float): String {
        return when {
            distanceInMeters < 1000 -> "${distanceInMeters.roundToInt()}m"
            else -> "${(distanceInMeters / 1000).roundToInt()}km"
        }
    }
    
    /**
     * Get estimated travel time in minutes
     */
    fun getEstimatedTravelTime(distanceInMeters: Float, averageSpeedKmh: Float = 30f): Int {
        val distanceInKm = distanceInMeters / 1000
        return (distanceInKm / averageSpeedKmh * 60).roundToInt()
    }
    
    /**
     * Check if a location is within a certain radius
     */
    fun isWithinRadius(userLocation: LatLng, targetLocation: LatLng, radiusInMeters: Float): Boolean {
        return calculateDistance(userLocation, targetLocation) <= radiusInMeters
    }
    
    /**
     * Get bearing between two points
     */
    fun getBearing(from: LatLng, to: LatLng): Float {
        val lat1 = Math.toRadians(from.latitude)
        val lat2 = Math.toRadians(to.latitude)
        val deltaLon = Math.toRadians(to.longitude - from.longitude)
        
        val y = Math.sin(deltaLon) * Math.cos(lat2)
        val x = Math.cos(lat1) * Math.sin(lat2) - Math.sin(lat1) * Math.cos(lat2) * Math.cos(deltaLon)
        
        val bearing = Math.toDegrees(Math.atan2(y, x))
        return ((bearing + 360) % 360).toFloat()
    }
    
    /**
     * Get direction string from bearing
     */
    fun getDirectionString(bearing: Float): String {
        return when {
            bearing in 337.5..360.0 || bearing in 0.0..22.5 -> "N"
            bearing in 22.5..67.5 -> "NE"
            bearing in 67.5..112.5 -> "E"
            bearing in 112.5..157.5 -> "SE"
            bearing in 157.5..202.5 -> "S"
            bearing in 202.5..247.5 -> "SW"
            bearing in 247.5..292.5 -> "W"
            bearing in 292.5..337.5 -> "NW"
            else -> "N"
        }
    }
    
    /**
     * Get area information for a location
     */
    fun getAreaInfo(location: LatLng): String {
        return """
            📍 Location Details
            
            Latitude: ${location.latitude}
            Longitude: ${location.longitude}
            
            🏪 Nearby Places:
            • Restaurants: 5
            • Gas Stations: 2
            • Parking: Available
            
            🚗 Traffic: Normal
            🌤️ Weather: Sunny
            
            💡 Tip: This area has good bike rental demand!
        """.trimIndent()
    }
    
    /**
     * Get popular locations for search
     */
    fun getPopularLocations(): List<String> {
        return listOf(
            "Marina Beach, Chennai",
            "T. Nagar, Chennai", 
            "Velachery, Chennai",
            "Anna Nagar, Chennai",
            "Phoenix Market City",
            "Central Station",
            "Airport",
            "Clear Search"
        )
    }
    
    /**
     * Get bike type icon resource
     */
    fun getBikeTypeIcon(bikeType: MapsActivity.BikeType): Int {
        return when (bikeType) {
            MapsActivity.BikeType.ELECTRIC -> android.R.drawable.ic_menu_compass
            MapsActivity.BikeType.SCOOTER -> android.R.drawable.ic_menu_myplaces
            MapsActivity.BikeType.SPORTS -> android.R.drawable.ic_menu_compass
            MapsActivity.BikeType.STANDARD -> android.R.drawable.ic_menu_myplaces
        }
    }
    
    /**
     * Get bike type color
     */
    fun getBikeTypeColor(bikeType: MapsActivity.BikeType): Int {
        return when (bikeType) {
            MapsActivity.BikeType.ELECTRIC -> android.graphics.Color.GREEN
            MapsActivity.BikeType.SCOOTER -> android.graphics.Color.BLUE
            MapsActivity.BikeType.SPORTS -> android.graphics.Color.RED
            MapsActivity.BikeType.STANDARD -> android.graphics.Color.GRAY
        }
    }
    
    /**
     * Validate coordinates
     */
    fun isValidCoordinate(latitude: Double, longitude: Double): Boolean {
        return latitude in -90.0..90.0 && longitude in -180.0..180.0
    }
    
    /**
     * Get location from address (placeholder - would integrate with Geocoding API)
     */
    fun getLocationFromAddress(context: Context, address: String, callback: (LatLng?) -> Unit) {
        // This would integrate with Google Geocoding API
        // For now, return a default location
        callback(LatLng(13.0827, 80.2707)) // Chennai center
    }
} 