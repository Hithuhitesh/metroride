package com.example.bikerental

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton
import java.time.Duration
import java.time.ZoneId

class PaymentActivityPrompt : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_payment_prompt)

        val bikeName = intent.getStringExtra("bikeName") ?: "-"
        val imageRes = intent.getIntExtra("imageRes", 0)
        val startMs = intent.getLongExtra("startMs", 0L)
        val endMs = intent.getLongExtra("endMs", 0L)
        val isHourly = intent.getBooleanExtra("isHourly", true)
        val hourlyRate = intent.getDoubleExtra("hourlyRate", 100.0)
        val locationLabel = intent.getStringExtra("locationLabel") ?: "Chennai"

        findViewById<TextView>(R.id.tvBikeName).text = bikeName
        findViewById<TextView>(R.id.tvWindow).text = formatWindowReadablePrompt(startMs, endMs, isHourly)

        findViewById<ImageView>(R.id.ivMapPreview).apply {
            if (imageRes != 0) setImageResource(R.drawable.harley_luxury)
            setOnClickListener { openMap(locationLabel) }
        }

        val (durationLabel, hoursOrDays) = calculateDurationLabel(startMs, endMs, isHourly)
        val subtotal = hoursOrDays * hourlyRate
        val tax = subtotal * 0.18
        val total = subtotal + tax

        findViewById<TextView>(R.id.tvDurationRow).text = "Duration: $durationLabel"
        findViewById<TextView>(R.id.tvRateRow).text = "Rate: ₹${hourlyRate}"
        findViewById<TextView>(R.id.tvSubtotalRow).text = "Subtotal: ₹${"%.2f".format(subtotal)}"
        findViewById<TextView>(R.id.tvTaxRow).text = "Tax (18%): ₹${"%.2f".format(tax)}"
        findViewById<TextView>(R.id.tvTotalRow).text = "Total: ₹${"%.2f".format(total)}"

        findViewById<MaterialButton>(R.id.btnPay).setOnClickListener {
            android.widget.Toast.makeText(this, "Payment successful", android.widget.Toast.LENGTH_SHORT).show()
            finish()
        }
    }

    private fun openMap(label: String) {
        val uri = Uri.parse("geo:0,0?q=" + Uri.encode(label))
        val intent = Intent(Intent.ACTION_VIEW, uri).setPackage("com.google.android.apps.maps")
        if (intent.resolveActivity(packageManager) != null) startActivity(intent)
    }

    private fun calculateDurationLabel(startMs: Long, endMs: Long, isHourly: Boolean): Pair<String, Int> {
        val zone = ZoneId.systemDefault()
        val start = java.time.Instant.ofEpochMilli(startMs).atZone(zone)
        val end = java.time.Instant.ofEpochMilli(endMs).atZone(zone)
        return if (isHourly) {
            val hours = Duration.between(start, end).toHours().toInt().coerceAtLeast(1)
            ("${hours}h" to hours)
        } else {
            val days = Duration.between(start.toLocalDate().atStartOfDay(zone), end.toLocalDate().atStartOfDay(zone)).toDays().toInt().coerceAtLeast(1)
            ("${days} day(s)" to days)
        }
    }
}










