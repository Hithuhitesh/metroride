package com.example.bikerental

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import com.google.android.material.bottomnavigation.BottomNavigationView
import androidx.fragment.app.commit
import android.os.Build
import android.view.View
import android.view.WindowManager
import androidx.core.view.WindowCompat
import android.widget.FrameLayout
import android.view.animation.AnimationUtils
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Button
import android.widget.Toast

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        try {
            // Initialize managers with error handling
            try {
                UserManager.initialize(this)
            } catch (e: Exception) {
                android.util.Log.e("MainActivity", "Error initializing UserManager: ${e.message}")
            }
            
            try {
                SavedBikesManager.initialize(this)
            } catch (e: Exception) {
                android.util.Log.e("MainActivity", "Error initializing SavedBikesManager: ${e.message}")
            }

            // Set status bar color to white and dark icons
            try {
                window.statusBarColor = 0xFFFFFFFF.toInt()
                WindowCompat.getInsetsController(window, window.decorView)?.isAppearanceLightStatusBars = true
            } catch (e: Exception) {
                android.util.Log.e("MainActivity", "Error setting status bar: ${e.message}")
            }

            val bottomNav = findViewById<BottomNavigationView>(R.id.bottomNavigationView)
            val fragmentContainer = findViewById<FrameLayout>(R.id.fragmentContainerView)

            if (bottomNav == null || fragmentContainer == null) {
                android.util.Log.e("MainActivity", "Critical: Navigation elements not found")
                showErrorScreen()
                return
            }

            // Handle intent extra to open specific fragments
            val openFragment = intent.getStringExtra("open_fragment")
            if (openFragment == "my_bikes") {
                try {
                    switchFragment(MyBikesFragment())
                    bottomNav.selectedItemId = R.id.menu_my_bikes
                } catch (e: Exception) {
                    android.util.Log.e("MainActivity", "Error opening MyBikesFragment: ${e.message}")
                    showHomeFragment(bottomNav)
                }
                return
            }

            // Get user role from UserManager
            val role = try {
                val currentRole = UserManager.getCurrentUserRole()
                android.util.Log.d("MainActivity", "Current user role: $currentRole")
                currentRole
            } catch (e: Exception) {
                android.util.Log.e("MainActivity", "Error getting user role: ${e.message}")
                "user" // Default to user
            }
            
            android.util.Log.d("MainActivity", "Final role being used: $role")
            
            // Setup navigation based on role
            try {
                setupNavigationForRole(bottomNav, role)
            } catch (e: Exception) {
                android.util.Log.e("MainActivity", "Error setting up navigation: ${e.message}")
                // Continue with default navigation
            }

            bottomNav.setOnItemSelectedListener { item ->
                try {
                    android.util.Log.d("MainActivity", "Navigation item clicked: ${item.title}")
                    when (item.itemId) {
                        R.id.menu_home -> {
                            android.util.Log.d("MainActivity", "Switching to TimeDatePickerFragment")
                            switchFragment(TimeDatePickerFragment())
                        }
                        R.id.menu_rentals -> {
                            android.util.Log.d("MainActivity", "Switching to RentalsFragment")
                            switchFragment(RentalsFragment())
                        }
                        R.id.menu_my_bikes -> {
                            android.util.Log.d("MainActivity", "Switching to MyBikesFragment")
                            switchFragment(MyBikesFragment())
                        }
                        R.id.menu_list_bike -> {
                            android.util.Log.d("MainActivity", "Switching to ListYourBikeFragment")
                            switchFragment(ListYourBikeFragment())
                        }
                        R.id.menu_profile -> {
                            android.util.Log.d("MainActivity", "Switching to ProfileFragment")
                            val prefs = getSharedPreferences("metro_ride_prefs", 0)
                            val currentRole = prefs.getString("role", "user") ?: "user"
                            android.util.Log.d("MainActivity", "Current role when profile button pressed: $currentRole")
                            switchFragment(ProfileFragment())
                        }
                        else -> {
                            android.util.Log.w("MainActivity", "Unknown menu item clicked: ${item.itemId}")
                            return@setOnItemSelectedListener false
                        }
                    }
                    true
                } catch (e: Exception) {
                    android.util.Log.e("MainActivity", "Error switching fragments: ${e.message}", e)
                    false
                }
            }
            
            // Set default fragment based on role - only if no saved state
            if (savedInstanceState == null) {
                try {
                    if (role == "admin") {
                        switchFragment(MyBikesFragment())
                        bottomNav.selectedItemId = R.id.menu_my_bikes
                    } else {
                        switchFragment(TimeDatePickerFragment())
                        bottomNav.selectedItemId = R.id.menu_home
                    }
                } catch (e: Exception) {
                    android.util.Log.e("MainActivity", "Error setting default fragment: ${e.message}")
                    // Fallback to home fragment
                    showHomeFragment(bottomNav)
                }
            }
        } catch (e: Exception) {
            android.util.Log.e("MainActivity", "Critical error in onCreate: ${e.message}", e)
            showErrorScreen()
        }
    }

    override fun onBackPressed() {
        try {
            // Check if we're on the home fragment
            val currentFragment = supportFragmentManager.findFragmentById(R.id.fragmentContainerView)
            if (currentFragment is TimeDatePickerFragment) {
                // Show exit confirmation dialog
                androidx.appcompat.app.AlertDialog.Builder(this)
                    .setTitle("Exit App")
                    .setMessage("Are you sure you want to exit Metro Ride?")
                    .setPositiveButton("Exit") { _, _ ->
                        finish()
                    }
                    .setNegativeButton("Cancel", null)
                    .show()
            } else {
                // Go back to home fragment
                val bottomNav = findViewById<BottomNavigationView>(R.id.bottomNavigationView)
                switchFragment(TimeDatePickerFragment())
                bottomNav?.selectedItemId = R.id.menu_home
            }
        } catch (e: Exception) {
            android.util.Log.e("MainActivity", "Error handling back press: ${e.message}")
            super.onBackPressed()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        android.util.Log.d("MainActivity", "MainActivity destroyed")
    }

    private fun setupNavigationForRole(bottomNav: BottomNavigationView, role: String?) {
        try {
            val menu = bottomNav.menu
            
            android.util.Log.d("MainActivity", "Setting up navigation for role: $role")
            
            if (role == "admin") {
                // Admin navigation: My Bikes, List Your Bike, Profile
                android.util.Log.d("MainActivity", "Setting up admin navigation")
                menu.findItem(R.id.menu_home)?.isVisible = false
                menu.findItem(R.id.menu_rentals)?.isVisible = false
                menu.findItem(R.id.menu_my_bikes)?.isVisible = true
                menu.findItem(R.id.menu_list_bike)?.isVisible = true
                menu.findItem(R.id.menu_profile)?.isVisible = true
            } else {
                // User navigation: Home, Rentals, Profile
                android.util.Log.d("MainActivity", "Setting up user navigation")
                menu.findItem(R.id.menu_home)?.isVisible = true
                menu.findItem(R.id.menu_rentals)?.isVisible = true
                menu.findItem(R.id.menu_my_bikes)?.isVisible = false
                menu.findItem(R.id.menu_list_bike)?.isVisible = false
                menu.findItem(R.id.menu_profile)?.isVisible = true
            }
            
            android.util.Log.d("MainActivity", "Navigation setup completed for role: $role")
        } catch (e: Exception) {
            android.util.Log.e("MainActivity", "Error setting up navigation: ${e.message}", e)
        }
    }

    fun updateNavigationForRole(newRole: String, shouldNavigate: Boolean = true) {
        try {
            val bottomNav = findViewById<BottomNavigationView>(R.id.bottomNavigationView)
            bottomNav?.let { nav ->
                setupNavigationForRole(nav, newRole)
                
                // Only navigate to appropriate default fragment if shouldNavigate is true
                if (shouldNavigate) {
                    if (newRole == "admin") {
                        switchFragment(MyBikesFragment())
                        nav.selectedItemId = R.id.menu_my_bikes
                    } else {
                        switchFragment(TimeDatePickerFragment())
                        nav.selectedItemId = R.id.menu_home
                    }
                }
            }
        } catch (e: Exception) {
            android.util.Log.e("MainActivity", "Error updating navigation: ${e.message}")
        }
    }

    private fun switchFragment(fragment: Fragment) {
        try {
            // Add slide animation for fragment transitions
            val slideInRight = AnimationUtils.loadAnimation(this, R.anim.slide_in_right)
            findViewById<FrameLayout>(R.id.fragmentContainerView).startAnimation(slideInRight)
            
            supportFragmentManager.commit {
                replace(R.id.fragmentContainerView, fragment)
            }
        } catch (e: Exception) {
            android.util.Log.e("MainActivity", "Error switching fragment: ${e.message}")
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        // Save current state to prevent issues during recreation
    }

    override fun onRestoreInstanceState(savedInstanceState: Bundle) {
        super.onRestoreInstanceState(savedInstanceState)
        // Restore state if needed
    }

    private fun showHomeFragment(bottomNav: BottomNavigationView) {
        try {
            switchFragment(TimeDatePickerFragment())
            bottomNav.selectedItemId = R.id.menu_home
        } catch (e: Exception) {
            android.util.Log.e("MainActivity", "Critical error showing home fragment: ${e.message}")
            showErrorScreen()
        }
    }

    private fun showErrorScreen() {
        try {
            // Create a simple error layout
            val errorLayout = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = android.view.Gravity.CENTER
                setBackgroundColor(0xFF7B5BE4.toInt())
                
                addView(TextView(this@MainActivity).apply {
                    text = "Metro Ride"
                    textSize = 24f
                    setTextColor(android.graphics.Color.WHITE)
                    gravity = android.view.Gravity.CENTER
                    setPadding(32, 64, 32, 32)
                })
                
                addView(Button(this@MainActivity).apply {
                    text = "Try Again"
                    setOnClickListener {
                        recreate()
                    }
                    setPadding(32, 16, 32, 16)
                })
            }
            
            setContentView(errorLayout)
        } catch (e: Exception) {
            android.util.Log.e("MainActivity", "Error showing error screen: ${e.message}")
            // Last resort - show system error
            Toast.makeText(this, "App error. Please restart.", Toast.LENGTH_LONG).show()
            finish()
        }
    }
}