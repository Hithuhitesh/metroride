package com.example.bikerental

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import com.example.bikerental.databinding.FragmentListYourBikeBinding

class ListYourBikeFragment : Fragment() {
    private var _binding: FragmentListYourBikeBinding? = null
    private val binding get() = _binding!!
    
    private val bikeTypes = listOf("Select Bike Type", "Standard", "Electric", "Scooter", "Sports", "Classic", "Adventure", "Luxury", "Others")
    
    private var selectedImageUri: Uri? = null
    private var selectedImageRes: Int = R.drawable.unicorn_standard_bike
    
    // Activity result launcher for image selection
    private val galleryLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            result.data?.data?.let { uri ->
                selectedImageUri = uri
                binding.ivBikeImage.setImageURI(uri)
                binding.ivBikeImage.visibility = View.VISIBLE
                binding.llUploadPlaceholder.visibility = View.GONE
                binding.btnUploadImage.text = "Change Photo"
                Toast.makeText(requireContext(), "Photo selected successfully!", Toast.LENGTH_SHORT).show()
            }
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentListYourBikeBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupSpinners()
        setupClickListeners()
        setupRentalTypeListener()
    }

    private fun setupSpinners() {
        val bikeTypeAdapter = ArrayAdapter(requireContext(), android.R.layout.simple_spinner_dropdown_item, bikeTypes)
        binding.spinnerType.adapter = bikeTypeAdapter
    }

    private fun setupClickListeners() {
        binding.btnSubmit.setOnClickListener {
            if (validateForm()) {
                submitBikeListing()
            }
        }

        binding.btnUploadImage.setOnClickListener {
            showImageUploadDialog()
        }

        binding.btnBack.setOnClickListener {
            // Handle back navigation
            requireActivity().onBackPressed()
        }
    }

    private fun showImageUploadDialog() {
        val options = arrayOf("Choose from Gallery", "Cancel")
        AlertDialog.Builder(requireContext())
            .setTitle("Upload Bike Photo")
            .setItems(options) { dialog, which ->
                when (which) {
                    0 -> {
                        // Choose from Gallery
                        openGallery()
                    }
                    1 -> dialog.dismiss()
                }
            }
            .show()
    }

    private fun openGallery() {
        val intent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
        galleryLauncher.launch(intent)
    }

    private fun setupRentalTypeListener() {
        binding.rgRentalType.setOnCheckedChangeListener { _, checkedId ->
            when (checkedId) {
                R.id.rbHourly -> {
                    updateDurationLabels("Min Hours *", "Max Hours *", "Enter price per hour")
                    binding.etMinDuration.hint = "1"
                    binding.etMaxDuration.hint = "24"
                    // Set default values
                    if (binding.etMinDuration.text.isEmpty()) {
                        binding.etMinDuration.setText("1")
                    }
                    if (binding.etMaxDuration.text.isEmpty()) {
                        binding.etMaxDuration.setText("24")
                    }
                }
                R.id.rbDaily -> {
                    updateDurationLabels("Min Days *", "Max Days *", "Enter price per day")
                    binding.etMinDuration.hint = "1"
                    binding.etMaxDuration.hint = "30"
                    // Set default values
                    if (binding.etMinDuration.text.isEmpty()) {
                        binding.etMinDuration.setText("1")
                    }
                    if (binding.etMaxDuration.text.isEmpty()) {
                        binding.etMaxDuration.setText("7")
                    }
                }
            }
        }
    }

    private fun updateDurationLabels(minLabel: String, maxLabel: String, priceHint: String) {
        binding.tvMinDurationLabel.text = minLabel
        binding.tvMaxDurationLabel.text = maxLabel
        binding.tvPriceLabel.text = priceHint.replace("Enter ", "")
        binding.etPrice.hint = priceHint
    }

    private fun validateForm(): Boolean {
        var isValid = true

        val name = binding.etBikeName.text.toString().trim()
        val type = binding.spinnerType.selectedItem?.toString()?.trim() ?: ""
        val address = binding.etAddress.text.toString().trim()
        val ownerPhone = binding.etOwnerPhone.text.toString().trim()
        val priceHour = binding.etPrice.text.toString().trim()
        val priceDay = binding.etPriceDay.text.toString().trim()
        val minDuration = binding.etMinDuration.text.toString().trim()
        val maxDuration = binding.etMaxDuration.text.toString().trim()

        // Validate name
        if (name.isEmpty()) {
            binding.etBikeName.error = "Bike name is required"
            isValid = false
        }

        // Validate type
        if (type == "Select Bike Type" || type.isEmpty()) {
            Toast.makeText(requireContext(), "Please select a bike type", Toast.LENGTH_SHORT).show()
            isValid = false
        }

        // Validate address
        if (address.isEmpty()) {
            binding.etAddress.error = "Address is required"
            isValid = false
        }

        // Validate owner phone
        if (ownerPhone.isEmpty()) {
            binding.etOwnerPhone.error = "Owner phone is required"
            isValid = false
        }

        // Validate price fields
        if (priceHour.isEmpty()) {
            binding.etPrice.error = "Hourly price is required"
            isValid = false
        } else {
            try {
                priceHour.toDouble()
            } catch (e: NumberFormatException) {
                binding.etPrice.error = "Please enter a valid price"
                isValid = false
            }
        }

        if (priceDay.isEmpty()) {
            binding.etPriceDay.error = "Daily price is required"
            isValid = false
        } else {
            try {
                priceDay.toDouble()
            } catch (e: NumberFormatException) {
                binding.etPriceDay.error = "Please enter a valid price"
                isValid = false
            }
        }

        // Validate duration fields
        if (minDuration.isEmpty()) {
            val unit = if (binding.rbHourly.isChecked) "hours" else "days"
            binding.etMinDuration.error = "Minimum $unit is required"
            isValid = false
        }

        if (maxDuration.isEmpty()) {
            val unit = if (binding.rbHourly.isChecked) "hours" else "days"
            binding.etMaxDuration.error = "Maximum $unit is required"
            isValid = false
        }

        if (minDuration.isNotEmpty() && maxDuration.isNotEmpty()) {
            try {
                val min = minDuration.toInt()
                val max = maxDuration.toInt()
                if (min > max) {
                    binding.etMaxDuration.error = "Maximum duration must be greater than minimum"
                    isValid = false
                }
            } catch (e: NumberFormatException) {
                binding.etMinDuration.error = "Please enter valid numbers"
                binding.etMaxDuration.error = "Please enter valid numbers"
                isValid = false
            }
        }

        return isValid
    }

    private fun submitBikeListing() {
        val name = binding.etBikeName.text.toString().trim()
        val type = binding.spinnerType.selectedItem?.toString()?.trim() ?: ""
        val address = binding.etAddress.text.toString().trim()
        val ownerPhone = binding.etOwnerPhone.text.toString().trim()
        val landmark = binding.etLandmark.text.toString().trim()
        val priceHour = binding.etPrice.text.toString().trim()
        val priceDay = binding.etPriceDay.text.toString().trim()
        val description = binding.etDescription.text.toString().trim()
        val minDuration = binding.etMinDuration.text.toString().trim()
        val maxDuration = binding.etMaxDuration.text.toString().trim()
        val isHourly = binding.rbHourly.isChecked
        val rentalType = if (isHourly) "Hourly" else "Daily"
        val durationUnit = if (isHourly) "hours" else "days"
        val price = if (isHourly) priceHour.toIntOrNull() ?: 0 else priceDay.toIntOrNull() ?: 0
        // Registration number (optional until UI field exists)
        val registrationNumber = binding.root.findViewById<android.widget.EditText>(R.id.etRegistrationNumber)?.text?.toString()?.trim() ?: ""
        
        // Get pickup mode
        val pickupMode = if (binding.rbManualPickup.isChecked) "manual" else "station"

        // Create location string for display
        val locationDisplay = if (landmark.isNotEmpty()) {
            "$landmark, Chennai"
        } else {
            "Chennai"
        }

        // Show loading state
        binding.btnSubmit.text = "Submitting..."
        binding.btnSubmit.isEnabled = false

        // Simulate API call
        binding.btnSubmit.postDelayed({
            // Get current user info
            val prefs = requireContext().getSharedPreferences("metro_ride_prefs", 0)
            val userEmail = prefs.getString("email", "") ?: ""
            
            // Create Bike object with all details
            val bike = Bike(
                id = java.util.UUID.randomUUID().toString(),
                name = name,
                type = type,
                location = locationDisplay,
                price = price,
                imageRes = selectedImageRes,
                pickupMode = pickupMode,
                address = address,
                city = "Chennai",
                pincode = "",
                landmark = landmark,
                description = description,
                ownerPhone = ownerPhone,
                ownerId = userEmail,
                registrationNumber = registrationNumber,
                availabilityStatus = "Inactive",
                verificationStatus = "Pending"
            )

            // Save bike to repository
            BikeRepository.allBikes.add(bike)
            
            // Also post to backend
            postBikeToBackend(bike)
            
            // Show success dialog
            showSuccessDialog(bike, rentalType, minDuration, maxDuration, durationUnit)
        }, 1000)
    }

    private fun postBikeToBackend(bike: Bike) {
        val currentUser = UserManager.getCurrentUser()
        val request = CreateBikeRequest(
            owner_id = currentUser?.id ?: "unknown",
            name = bike.name,
            model = bike.model,
            type = bike.type,
            location = bike.location,
            city = bike.city,
            registration_number = bike.registrationNumber,
            price_hour = bike.price,
            price_day = bike.price * 8,
            image_url = ""
        )
        
        ApiClient.apiService.createBike(request).enqueue(object : retrofit2.Callback<Map<String, Any>> {
            override fun onResponse(call: retrofit2.Call<Map<String, Any>>, response: retrofit2.Response<Map<String, Any>>) {
                if (response.isSuccessful) {
                    android.util.Log.d("ListYourBike", "Bike posted to backend successfully")
                } else {
                    android.util.Log.d("ListYourBike", "Failed to post bike to backend: ${response.code()}")
                }
            }
            
            override fun onFailure(call: retrofit2.Call<Map<String, Any>>, t: Throwable) {
                android.util.Log.d("ListYourBike", "Network error posting bike to backend: ${t.message}")
            }
        })
    }

    private fun showSuccessDialog(bike: Bike, rentalType: String, minDuration: String, maxDuration: String, durationUnit: String) {
        val pickupModeText = if (bike.pickupMode == "manual") "Manual Pickup" else "Station Pickup"
        
        AlertDialog.Builder(requireContext())
            .setTitle("Bike Listed Successfully!")
            .setMessage("Your ${bike.type} bike '${bike.name}' has been listed for ₹${bike.price} per ${rentalType.lowercase()} " +
                    "($minDuration-$maxDuration $durationUnit) in ${bike.location}.\n\n" +
                    "Pickup Mode: $pickupModeText\n\n" +
                    "You'll be notified when someone wants to rent your bike.")
            .setPositiveButton("View My Bikes") { dialog, _ ->
                // Navigate to My Bikes fragment
                try {
                    val fragment = MyBikesFragment()
                    requireActivity().supportFragmentManager.beginTransaction()
                        .replace(R.id.fragmentContainerView, fragment)
                        .addToBackStack(null)
                        .commit()
                } catch (e: Exception) {
                    Toast.makeText(requireContext(), "Error navigating to My Bikes", Toast.LENGTH_SHORT).show()
                }
                resetForm()
                dialog.dismiss()
            }
            .setNegativeButton("List Another Bike") { dialog, _ ->
                resetForm()
                dialog.dismiss()
            }
            .setCancelable(false)
            .show()
    }

    private fun resetForm() {
        // Reset basic information
        binding.etBikeName.text.clear()
        binding.spinnerType.setSelection(0)
        
        // Reset location fields
        binding.etAddress.text.clear()
        binding.etLandmark.text.clear()
        binding.etOwnerPhone.text.clear()
        
        // Reset price fields
        binding.etPrice.text.clear()
        binding.etPriceDay.text.clear()
        
        // Reset rental details
        binding.etMinDuration.text.clear()
        binding.etMaxDuration.text.clear()
        
        // Reset description
        binding.etDescription.text.clear()
        
        // Reset image
        selectedImageUri = null
        selectedImageRes = R.drawable.unicorn_standard_bike
        binding.ivBikeImage.visibility = View.GONE
        binding.llUploadPlaceholder.visibility = View.VISIBLE
        binding.btnUploadImage.text = "Upload Photo"
        
        // Reset submit button
        binding.btnSubmit.text = "Submit"
        binding.btnSubmit.isEnabled = true
        
        // Reset to hourly by default
        binding.rbHourly.isChecked = true
        updateDurationLabels("Min Hours *", "Max Hours *", "Enter price per hour")
        
        // Reset pickup mode to Manual Pickup by default
        binding.rbManualPickup.isChecked = true
        
        // Clear any error states
        binding.etBikeName.error = null
        binding.etAddress.error = null
        binding.etPrice.error = null
        binding.etPriceDay.error = null
        binding.etMinDuration.error = null
        binding.etMaxDuration.error = null
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
} 