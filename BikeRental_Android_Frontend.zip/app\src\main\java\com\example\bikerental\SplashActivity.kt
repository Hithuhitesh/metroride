package com.example.bikerental

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.bikerental.databinding.ActivitySplashBinding
import android.os.Handler
import android.os.Looper
import android.view.animation.AnimationUtils
import android.view.View
import android.app.AlertDialog

class SplashActivity : AppCompatActivity() {
    private lateinit var binding: ActivitySplashBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySplashBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Add entrance animations
        addEntranceAnimations()

        // Reset login state to show full flow (for testing)
        val prefs = getSharedPreferences("metro_ride_prefs", MODE_PRIVATE)
        prefs.edit().putBoolean("isLoggedIn", false).apply()
        
        // Continue button navigates to RoleSelectActivity
        binding.btnContinue.setOnClickListener {
            val intent = Intent(this, RoleSelectActivity::class.java)
            startActivity(intent)
            finish()
        }

        // Learn More button shows info dialog
        binding.btnLearnMore.setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle("About Metro Ride")
                .setMessage("Metro Ride is your one-stop solution for renting bikes and scooters in your city. Enjoy seamless booking, easy payments, and a wide range of vehicles to choose from!")
                .setPositiveButton("OK", null)
                .show()
        }
    }

    private fun addEntranceAnimations() {
        // Animate background circles (if any)
        binding.root.findViewById<View?>(R.id.bgCircle1)?.let {
            it.startAnimation(AnimationUtils.loadAnimation(this, R.anim.fade_in))
        }
        binding.root.findViewById<View?>(R.id.bgCircle2)?.let {
            it.startAnimation(AnimationUtils.loadAnimation(this, R.anim.fade_in))
        }
        // Animate logo: scale and fade in
        binding.ivSplashLogo.startAnimation(AnimationUtils.loadAnimation(this, R.anim.scale_up))
        binding.ivSplashLogo.startAnimation(AnimationUtils.loadAnimation(this, R.anim.fade_in))
        // Animate welcome text: slide up and fade in
        binding.tvWelcomeTitle?.startAnimation(AnimationUtils.loadAnimation(this, R.anim.slide_up))
        binding.tvWelcomeTitle?.startAnimation(AnimationUtils.loadAnimation(this, R.anim.fade_in))
        binding.tvWelcomeSubtitle?.startAnimation(AnimationUtils.loadAnimation(this, R.anim.slide_up))
        binding.tvWelcomeSubtitle?.startAnimation(AnimationUtils.loadAnimation(this, R.anim.fade_in))
    }
} 