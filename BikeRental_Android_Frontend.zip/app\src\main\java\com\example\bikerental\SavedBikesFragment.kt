package com.example.bikerental

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.GridLayoutManager
import com.example.bikerental.MainActivity

class SavedBikesFragment : Fragment() {
    private lateinit var recyclerView: RecyclerView
    private lateinit var emptyStateLayout: View
    private lateinit var exploreButton: Button
    private lateinit var adapter: SavedBikesAdapter

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_saved, container, false)
        
        // Initialize views safely
        recyclerView = view.findViewById(R.id.rvSavedBikes)
        emptyStateLayout = view.findViewById(R.id.layoutEmptyState)
        exploreButton = emptyStateLayout.findViewById(R.id.exploreButton)
        
        // Setup back button
        val btnBack = view.findViewById<ImageView>(R.id.btnBack)
        btnBack.setOnClickListener {
            requireActivity().supportFragmentManager.popBackStack()
        }
        
        // Setup RecyclerView with GridLayoutManager
        recyclerView.layoutManager = GridLayoutManager(requireContext(), 2)
        adapter = SavedBikesAdapter(emptyList()) { bike ->
            BookingDialogRedesignFragment
                .newInstance(bike)
                .show(parentFragmentManager, "booking_redesign")
        }
        recyclerView.adapter = adapter
        
        // Setup explore button
        exploreButton.setOnClickListener {
            // Navigate to home fragment
            requireActivity().supportFragmentManager.popBackStack()
        }
        
        updateUI()
        return view
    }

    override fun onResume() {
        super.onResume()
        updateUI()
    }

    private fun updateUI() {
        val savedBikes = SavedBikesManager.getSavedBikes()
        
        if (savedBikes.isEmpty()) {
            recyclerView.visibility = View.GONE
            emptyStateLayout.visibility = View.VISIBLE
        } else {
            recyclerView.visibility = View.VISIBLE
            emptyStateLayout.visibility = View.GONE
            adapter.updateBikes(savedBikes)
        }
    }

    // Adapter for Saved Bikes
    class SavedBikesAdapter(
        private var bikes: List<Bike>,
        private val onBikeClick: (Bike) -> Unit
    ) : RecyclerView.Adapter<SavedBikesAdapter.BikeViewHolder>() {
        
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): BikeViewHolder {
            val view = LayoutInflater.from(parent.context).inflate(R.layout.item_bike_card, parent, false)
            return BikeViewHolder(view)
        }
        
        override fun onBindViewHolder(holder: BikeViewHolder, position: Int) {
            holder.bind(bikes[position])
        }
        
        override fun getItemCount() = bikes.size

        fun updateBikes(newBikes: List<Bike>) {
            bikes = newBikes
            notifyDataSetChanged()
        }

        inner class BikeViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
            fun bind(bike: Bike) {
                // Set bike name
                itemView.findViewById<TextView>(R.id.tvBikeName).text = bike.name
                
                // Set bike image based on bike name
                val bikeImageRes = bike.getBikeImageRes()
                itemView.findViewById<ImageView>(R.id.ivBikeImage).setImageResource(bikeImageRes)
                
                // Set bike type label
                itemView.findViewById<TextView>(R.id.tvBikeType).text = bike.type.uppercase()
                
                // Set up favorite button (should always be filled since it's saved)
                val btnFavorite = itemView.findViewById<ImageView>(R.id.btnFavorite)
                btnFavorite.setImageResource(android.R.drawable.btn_star_big_on)
                btnFavorite.tag = true
                
                btnFavorite.setOnClickListener {
                    // Remove from saved bikes
                    SavedBikesManager.removeBike(bike.id)
                    btnFavorite.setImageResource(android.R.drawable.btn_star_big_off)
                    btnFavorite.tag = false
                    Toast.makeText(itemView.context, R.string.removed_from_favorites, Toast.LENGTH_SHORT).show()
                    
                    // Update the UI
                    (itemView.context as? MainActivity)?.let { activity ->
                        activity.supportFragmentManager.beginTransaction()
                            .replace(R.id.fragmentContainerView, SavedBikesFragment())
                            .addToBackStack(null)
                            .commit()
                    }
                }
                
                itemView.setOnClickListener {
                    onBikeClick(bike)
                }
            }
        }
    }
} 