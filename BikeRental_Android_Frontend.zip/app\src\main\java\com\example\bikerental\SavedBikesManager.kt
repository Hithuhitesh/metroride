package com.example.bikerental

import android.content.Context
import android.content.SharedPreferences
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

object SavedBikesManager {
    private const val PREF_NAME = "saved_bikes_prefs"
    private const val KEY_SAVED_BIKES = "saved_bikes"
    
    private lateinit var sharedPreferences: SharedPreferences
    private val gson = Gson()
    
    fun initialize(context: Context) {
        sharedPreferences = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
    }
    
    fun saveBike(bike: Bike) {
        val savedBikes = getSavedBikes().toMutableList()
        if (!savedBikes.any { it.id == bike.id }) {
            savedBikes.add(bike)
            saveBikesToPrefs(savedBikes)
        }
    }
    
    fun removeBike(bikeId: String) {
        val savedBikes = getSavedBikes().toMutableList()
        savedBikes.removeAll { it.id == bikeId }
        saveBikesToPrefs(savedBikes)
    }
    
    fun isBikeSaved(bikeId: String): Boolean {
        return getSavedBikes().any { it.id == bikeId }
    }
    
    fun getSavedBikes(): List<Bike> {
        val json = sharedPreferences.getString(KEY_SAVED_BIKES, "[]")
        val type = object : TypeToken<List<Bike>>() {}.type
        return try {
            gson.fromJson(json, type) ?: emptyList()
        } catch (e: Exception) {
            emptyList()
        }
    }
    
    private fun saveBikesToPrefs(bikes: List<Bike>) {
        val json = gson.toJson(bikes)
        sharedPreferences.edit().putString(KEY_SAVED_BIKES, json).apply()
    }
} 