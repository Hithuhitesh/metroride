package com.example.bikerental

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.chip.Chip
import com.google.android.material.chip.ChipGroup
import java.text.SimpleDateFormat
import java.util.*

class TimeDatePickerFragment : Fragment() {
    private lateinit var etLocation: EditText
    private lateinit var btnUseGps: ImageButton
    private lateinit var chipDaily: Chip
    private lateinit var chipHourly: Chip
    private lateinit var containerDateRange: LinearLayout
    private lateinit var containerHourly: LinearLayout
    private lateinit var tvDateRange: TextView
    private lateinit var tvPickupTime: TextView
    private lateinit var tvDropoffTime: TextView
    private lateinit var tvHourlyDate: TextView
    private lateinit var tvHourlyStartTime: TextView
    private lateinit var btnDecDuration: Button
    private lateinit var tvDuration: TextView
    private lateinit var btnIncDuration: Button
    private lateinit var btnClear: Button
    private lateinit var btnContinue: Button
    
    private var isHourly = false
    private var duration = 2
    private var selectedLocation: String = "Chennai"
    private var startDate: Date? = null
    private var endDate: Date? = null
    private var pickupTime: Date? = null
    private var dropoffTime: Date? = null
    private var hourlyDate: Date? = null
    private var hourlyStartTime: Date? = null
    
    private val dateFormat = SimpleDateFormat("dd MMM yyyy", Locale.getDefault())
    private val timeFormat = SimpleDateFormat("hh:mm a", Locale.getDefault())
    private val dateTimeFormat = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault())
    
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_time_date_picker, container, false)
    }
    
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        
        initializeViews(view)
        setupClickListeners()
        updateUI()
    }
    
    private fun initializeViews(view: View) {
        etLocation = view.findViewById(R.id.etLocation)
        btnUseGps = view.findViewById(R.id.btnUseGps)
        chipDaily = view.findViewById(R.id.chipDaily)
        chipHourly = view.findViewById(R.id.chipHourly)
        containerDateRange = view.findViewById(R.id.containerDateRange)
        containerHourly = view.findViewById(R.id.containerHourly)
        tvDateRange = view.findViewById(R.id.tvDateRange)
        tvPickupTime = view.findViewById(R.id.tvPickupTime)
        tvDropoffTime = view.findViewById(R.id.tvDropoffTime)
        tvHourlyDate = view.findViewById(R.id.tvHourlyDate)
        tvHourlyStartTime = view.findViewById(R.id.tvHourlyStartTime)
        btnDecDuration = view.findViewById(R.id.btnDecDuration)
        tvDuration = view.findViewById(R.id.tvDuration)
        btnIncDuration = view.findViewById(R.id.btnIncDuration)
        btnClear = view.findViewById(R.id.btnClear)
        btnContinue = view.findViewById(R.id.btnContinue)
        
        // Set default location
        etLocation.setText(selectedLocation)
    }
    
    private fun setupClickListeners() {
        // Location input and GPS button
        btnUseGps.setOnClickListener { tryUseGps() }
        etLocation.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: android.text.Editable?) {
                selectedLocation = s?.toString()?.trim() ?: ""
            }
        })
        
        // Trip mode toggle
        chipDaily.setOnClickListener {
            isHourly = false
            updateUI()
        }
        
        chipHourly.setOnClickListener {
            isHourly = true
            updateUI()
        }
        
        // Date range picker for daily mode
        tvDateRange.setOnClickListener {
            showDateRangePicker()
        }
        
        tvPickupTime.setOnClickListener {
            showTimePicker { time ->
                pickupTime = enforceAtLeastOneHourFromNowForDaily(time, true)
                updateTimeDisplay()
            }
        }
        
        tvDropoffTime.setOnClickListener {
            showTimePicker { time ->
                dropoffTime = time
                updateTimeDisplay()
            }
        }
        
        // Hourly mode
        tvHourlyDate.setOnClickListener {
            // Restrict to today or future dates
            val calendar = Calendar.getInstance().apply {
                set(Calendar.HOUR_OF_DAY, 0)
                set(Calendar.MINUTE, 0)
                set(Calendar.SECOND, 0)
                set(Calendar.MILLISECOND, 0)
            }
            val dp = DatePickerDialog(requireContext(), { _, y, m, d ->
                hourlyDate = Calendar.getInstance().apply { set(y, m, d, 0, 0, 0); set(Calendar.MILLISECOND, 0) }.time
                updateTimeDisplay()
            }, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH))
            dp.datePicker.minDate = calendar.timeInMillis
            dp.show()
        }
        
        tvHourlyStartTime.setOnClickListener {
            showTimePicker { time ->
                hourlyStartTime = enforceAtLeastOneHourFromNowForHourly(time)
                updateTimeDisplay()
            }
        }
        
        // Duration controls
        btnDecDuration.setOnClickListener {
            if (duration > 1) {
                duration--
                tvDuration.text = "$duration hours"
            }
        }
        
        btnIncDuration.setOnClickListener {
            if (duration < 24) {
                duration++
                tvDuration.text = "$duration hours"
            }
        }
        
        // Action buttons
        btnClear.setOnClickListener {
            clearAll()
        }
        
        btnContinue.setOnClickListener {
            proceedToBikeSelection()
        }
    }
    
    private fun updateUI() {
        if (isHourly) {
            chipHourly.isChecked = true
            chipDaily.isChecked = false
            containerDateRange.visibility = View.GONE
            containerHourly.visibility = View.VISIBLE
        } else {
            chipDaily.isChecked = true
            chipHourly.isChecked = false
            containerDateRange.visibility = View.VISIBLE
            containerHourly.visibility = View.GONE
        }
        updateTimeDisplay()
    }
    
    private fun updateTimeDisplay() {
        if (isHourly) {
            tvHourlyDate.text = hourlyDate?.let { dateFormat.format(it) } ?: "Select date"
            tvHourlyStartTime.text = hourlyStartTime?.let { timeFormat.format(it) } ?: "08:00 AM"
        } else {
            tvDateRange.text = when {
                startDate != null && endDate != null -> "${dateFormat.format(startDate!!)} - ${dateFormat.format(endDate!!)}"
                startDate != null -> "From ${dateFormat.format(startDate!!)}"
                else -> "Select start & end date"
            }
            tvPickupTime.text = pickupTime?.let { timeFormat.format(it) } ?: "08:00 AM"
            tvDropoffTime.text = dropoffTime?.let { timeFormat.format(it) } ?: "08:00 AM"
        }
    }
    
    private fun showLocationPicker() { /* removed in favor of inline input + GPS button */ }

    private fun tryUseGps() {
        val ctx = requireContext()
        val lm = ctx.getSystemService(android.content.Context.LOCATION_SERVICE) as android.location.LocationManager
        val fine = androidx.core.content.ContextCompat.checkSelfPermission(ctx, android.Manifest.permission.ACCESS_FINE_LOCATION)
        val coarse = androidx.core.content.ContextCompat.checkSelfPermission(ctx, android.Manifest.permission.ACCESS_COARSE_LOCATION)
        if (fine != android.content.pm.PackageManager.PERMISSION_GRANTED && coarse != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(android.Manifest.permission.ACCESS_FINE_LOCATION, android.Manifest.permission.ACCESS_COARSE_LOCATION), 2025)
            return
        }
        val providers = listOf(android.location.LocationManager.GPS_PROVIDER, android.location.LocationManager.NETWORK_PROVIDER)
        var best: android.location.Location? = null
        for (p in providers) {
            val l = try { lm.getLastKnownLocation(p) } catch (_: SecurityException) { null }
            if (l != null && (best == null || l.accuracy < best!!.accuracy)) best = l
        }
        if (best != null) {
            // Constrain to Chennai context; otherwise prefer Saveetha University default
            val geocoder = android.location.Geocoder(ctx, java.util.Locale.getDefault())
            val label = try {
                val list = geocoder.getFromLocation(best!!.latitude, best!!.longitude, 1)
                if (!list.isNullOrEmpty()) {
                    val a = list[0]
                    val candidate = listOfNotNull(a.subLocality, a.locality, a.adminArea).joinToString(", ")
                    val full = listOfNotNull(a.featureName, a.subLocality, a.locality, a.adminArea).joinToString(", ")
                    val text = if (candidate.isNotBlank()) candidate else full
                    val lc = (a.locality ?: "").lowercase()
                    val admin = (a.adminArea ?: "").lowercase()
                    val country = (a.countryName ?: "").lowercase()
                    if (lc.contains("chennai") || admin.contains("tamil") || country.contains("india")) text else null
                } else null
            } catch (_: Exception) { null }
            selectedLocation = label ?: "Saveetha University, Chennai"
            etLocation.setText(selectedLocation)
        } else {
            // Fallback default
            selectedLocation = "Saveetha University, Chennai"
            etLocation.setText(selectedLocation)
            Toast.makeText(ctx, "Using default location (Saveetha University).", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 2025) {
            val granted = grantResults.isNotEmpty() && grantResults.any { it == android.content.pm.PackageManager.PERMISSION_GRANTED }
            if (granted) {
                tryUseGps()
            } else {
                // Default to Saveetha when permission denied
                selectedLocation = "Saveetha University, Chennai"
                etLocation.setText(selectedLocation)
                Toast.makeText(requireContext(), "Location permission denied. Using Saveetha University.", Toast.LENGTH_SHORT).show()
            }
        }
    }
    
    private fun showDateRangePicker() {
        val calendar = Calendar.getInstance().apply {
            // normalize to today 00:00
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        val startPicker = DatePickerDialog(requireContext(), { _, year, month, dayOfMonth ->
            startDate = Calendar.getInstance().apply {
                set(year, month, dayOfMonth, 0, 0, 0)
                set(Calendar.MILLISECOND, 0)
            }.time
            // End date picker cannot be before start date
            val endCal = Calendar.getInstance().apply { time = startDate!! }
            val endPicker = DatePickerDialog(requireContext(), { _, y2, m2, d2 ->
                endDate = Calendar.getInstance().apply {
                    set(y2, m2, d2, 0, 0, 0)
                    set(Calendar.MILLISECOND, 0)
                }.time
                updateTimeDisplay()
            }, endCal.get(Calendar.YEAR), endCal.get(Calendar.MONTH), endCal.get(Calendar.DAY_OF_MONTH))
            endPicker.datePicker.minDate = endCal.timeInMillis
            endPicker.show()
        }, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH))
        startPicker.datePicker.minDate = calendar.timeInMillis
        startPicker.show()
    }
    
    private fun showDatePicker(onDateSelected: (Date) -> Unit) {
        val calendar = Calendar.getInstance()
        DatePickerDialog(requireContext(), { _, year, month, dayOfMonth ->
            val selectedDate = Calendar.getInstance().apply {
                set(year, month, dayOfMonth)
            }.time
            onDateSelected(selectedDate)
        }, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH)).show()
    }
    
    private fun showTimePicker(onTimeSelected: (Date) -> Unit) {
        val calendar = Calendar.getInstance()
        TimePickerDialog(requireContext(), { _, hourOfDay, minute ->
            val selectedTime = Calendar.getInstance().apply {
                set(Calendar.HOUR_OF_DAY, hourOfDay)
                set(Calendar.MINUTE, minute)
            }.time
            onTimeSelected(selectedTime)
        }, calendar.get(Calendar.HOUR_OF_DAY), calendar.get(Calendar.MINUTE), false).show()
    }

    private fun enforceAtLeastOneHourFromNowForHourly(selected: Date): Date {
        val now = Calendar.getInstance()
        val min = Calendar.getInstance().apply { add(Calendar.HOUR_OF_DAY, 1); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0) }
        val chosen = Calendar.getInstance().apply { time = selected }
        // If user-picked time is before now+1h on the same chosen date, bump to min
        val result = if (hourlyDate != null) {
            val chosenDate = Calendar.getInstance().apply { time = hourlyDate!!; set(Calendar.HOUR_OF_DAY, chosen.get(Calendar.HOUR_OF_DAY)); set(Calendar.MINUTE, chosen.get(Calendar.MINUTE)); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0) }
            if (chosenDate.before(min)) min.time else chosen.time
        } else {
            if (chosen.before(min)) min.time else chosen.time
        }
        if (Date().before(result)) return result else return min.time
    }

    private fun enforceAtLeastOneHourFromNowForDaily(selected: Date, isPickup: Boolean): Date {
        val min = Calendar.getInstance().apply { add(Calendar.HOUR_OF_DAY, 1); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0) }
        val chosen = Calendar.getInstance().apply { time = selected }
        // If pickup is today and before now+1h, bump it
        if (isPickup && startDate != null) {
            val startCal = Calendar.getInstance().apply { time = startDate!!; set(Calendar.HOUR_OF_DAY, chosen.get(Calendar.HOUR_OF_DAY)); set(Calendar.MINUTE, chosen.get(Calendar.MINUTE)); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0) }
            if (isSameDay(startCal, Calendar.getInstance()) && startCal.before(min)) {
                return min.time
            }
        }
        return chosen.time
    }

    private fun isSameDay(a: Calendar, b: Calendar): Boolean {
        return a.get(Calendar.YEAR) == b.get(Calendar.YEAR) && a.get(Calendar.DAY_OF_YEAR) == b.get(Calendar.DAY_OF_YEAR)
    }
    
    private fun clearAll() {
        startDate = null
        endDate = null
        pickupTime = null
        dropoffTime = null
        hourlyDate = null
        hourlyStartTime = null
        duration = 2
        tvDuration.text = "$duration hours"
        updateTimeDisplay()
    }
    
    private fun proceedToBikeSelection() {
        if (!validateSelection()) return
        
        val bundle = Bundle()
        bundle.putBoolean("isHourly", isHourly)
        bundle.putInt("duration", duration)
        bundle.putString("location", selectedLocation)
        
        if (isHourly) {
            hourlyDate?.let { bundle.putString("date", dateFormat.format(it)) }
            hourlyStartTime?.let { bundle.putString("startTime", timeFormat.format(it)) }
        } else {
            startDate?.let { bundle.putString("startDate", dateFormat.format(it)) }
            endDate?.let { bundle.putString("endDate", dateFormat.format(it)) }
            pickupTime?.let { bundle.putString("pickupTime", timeFormat.format(it)) }
            dropoffTime?.let { bundle.putString("dropoffTime", timeFormat.format(it)) }
        }
        
        // Navigate to BrowseBikesFragment
        val fragment = BrowseBikesFragment()
        fragment.arguments = bundle
        parentFragmentManager.beginTransaction()
            .replace(R.id.fragmentContainerView, fragment)
            .addToBackStack(null)
            .commit()
    }
    
    private fun validateSelection(): Boolean {
        val now = Calendar.getInstance()
        val minStart = Calendar.getInstance().apply { add(Calendar.HOUR_OF_DAY, 1); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0) }

        if (isHourly) {
            if (hourlyDate == null || hourlyStartTime == null) return false

            // Combine hourly date and time
            val chosen = Calendar.getInstance().apply {
                time = hourlyDate!!
                val t = Calendar.getInstance().apply { time = hourlyStartTime!! }
                set(Calendar.HOUR_OF_DAY, t.get(Calendar.HOUR_OF_DAY))
                set(Calendar.MINUTE, t.get(Calendar.MINUTE))
                set(Calendar.SECOND, 0)
                set(Calendar.MILLISECOND, 0)
            }
            val todayMidnight = Calendar.getInstance().apply {
                set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
            }
            if (chosen.before(minStart)) {
                Toast.makeText(requireContext(), "Start time must be at least 1 hour from now.", Toast.LENGTH_SHORT).show()
                return false
            }
            if (Calendar.getInstance().time.before(chosen.time) && hourlyDate!!.before(todayMidnight.time)) {
                Toast.makeText(requireContext(), "Cannot select a past date.", Toast.LENGTH_SHORT).show()
                return false
            }
            return true
        } else {
            if (startDate == null || endDate == null || pickupTime == null || dropoffTime == null) return false

            val startDay = Calendar.getInstance().apply { time = startDate!!; set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0) }
            val today = Calendar.getInstance().apply { set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0) }

            if (startDay.before(today)) {
                Toast.makeText(requireContext(), "Start date cannot be in the past.", Toast.LENGTH_SHORT).show()
                return false
            }
            if (endDate!!.before(startDate)) {
                Toast.makeText(requireContext(), "End date must be after start date.", Toast.LENGTH_SHORT).show()
                return false
            }
            // If start is today, pickup must be at least 1 hour from now
            val pickupCal = Calendar.getInstance().apply {
                time = startDate!!
                val t = Calendar.getInstance().apply { time = pickupTime!! }
                set(Calendar.HOUR_OF_DAY, t.get(Calendar.HOUR_OF_DAY))
                set(Calendar.MINUTE, t.get(Calendar.MINUTE))
                set(Calendar.SECOND, 0)
                set(Calendar.MILLISECOND, 0)
            }
            if (isSameDay(startDay, today) && pickupCal.before(minStart)) {
                Toast.makeText(requireContext(), "Pickup must be at least 1 hour from now.", Toast.LENGTH_SHORT).show()
                return false
            }
            return true
        }
    }
    
    private fun extractDurationHours(): Int = duration
}

