package com.example.bikerental

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class EarningsDashboardFragment : Fragment() {
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_earnings_dashboard, container, false)
        val tvWeeklyEarnings = view.findViewById<TextView>(R.id.tvWeeklyEarnings)
        val tvMonthlyEarnings = view.findViewById<TextView>(R.id.tvMonthlyEarnings)
        val rvPerBike = view.findViewById<RecyclerView>(R.id.rvPerBikeEarnings)
        val rvTopBikes = view.findViewById<RecyclerView>(R.id.rvTopBikes)
        tvWeeklyEarnings.text = "₹2,500"
        tvMonthlyEarnings.text = "₹10,000"
        rvPerBike.layoutManager = LinearLayoutManager(requireContext())
        rvPerBike.adapter = PerBikeEarningsAdapter(getMockPerBikeEarnings())
        rvTopBikes.layoutManager = LinearLayoutManager(requireContext())
        rvTopBikes.adapter = TopBikesAdapter(getMockTopBikes())
        return view
    }

    private fun getMockPerBikeEarnings(): List<Pair<String, Int>> = listOf(
        "Marina Cruiser" to 4000,
        "E-Bike Pro" to 3500,
        "Scooty Zip" to 2500
    )
    private fun getMockTopBikes(): List<Pair<String, Int>> = listOf(
        "Marina Cruiser" to 40,
        "E-Bike Pro" to 35,
        "Scooty Zip" to 25
    )

    inner class PerBikeEarningsAdapter(private val items: List<Pair<String, Int>>) : RecyclerView.Adapter<PerBikeEarningsAdapter.ViewHolder>() {
        inner class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
            val tvBikeName: TextView = view.findViewById(R.id.tvBikeName)
            val tvEarnings: TextView = view.findViewById(R.id.tvEarnings)
        }
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
            val v = LayoutInflater.from(parent.context).inflate(R.layout.item_per_bike_earning, parent, false)
            return ViewHolder(v)
        }
        override fun onBindViewHolder(holder: ViewHolder, position: Int) {
            val (name, earnings) = items[position]
            holder.tvBikeName.text = name
            holder.tvEarnings.text = "₹$earnings"
        }
        override fun getItemCount() = items.size
    }
    inner class TopBikesAdapter(private val items: List<Pair<String, Int>>) : RecyclerView.Adapter<TopBikesAdapter.ViewHolder>() {
        inner class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
            val tvBikeName: TextView = view.findViewById(R.id.tvBikeName)
            val tvBookings: TextView = view.findViewById(R.id.tvBookings)
        }
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
            val v = LayoutInflater.from(parent.context).inflate(R.layout.item_top_bike, parent, false)
            return ViewHolder(v)
        }
        override fun onBindViewHolder(holder: ViewHolder, position: Int) {
            val (name, bookings) = items[position]
            holder.tvBikeName.text = name
            holder.tvBookings.text = "$bookings bookings"
        }
        override fun getItemCount() = items.size
    }
} 