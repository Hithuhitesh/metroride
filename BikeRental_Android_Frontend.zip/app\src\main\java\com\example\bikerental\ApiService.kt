package com.example.bikerental

import retrofit2.Call
import retrofit2.http.*

data class ApiBike(
    val id: String?,
    val owner_id: String?,
    val name: String?,
    val model: String?,
    val type: String?,
    val location: String?,
    val city: String?,
    val registration_number: String?,
    val price_hour: Int?,
    val price_day: Int?,
    val availability_status: String?,
    val verification_status: String?,
    val image_url: String?
)

data class ApiBooking(
    val id: String?,
    val user_id: String?,
    val bike_id: String?,
    val start_time: String?,
    val end_time: String?,
    val pricing_mode: String?,
    val total_amount: Int?,
    val status: String?
)

data class CreateBikeRequest(
    val owner_id: String,
    val name: String,
    val model: String = "",
    val type: String = "",
    val location: String = "",
    val city: String = "",
    val registration_number: String = "",
    val price_hour: Int = 0,
    val price_day: Int = 0,
    val image_url: String = ""
)

data class CreateBookingRequest(
    val user_id: String,
    val bike_id: String,
    val start_time: String,
    val end_time: String,
    val pricing_mode: String,
    val total_amount: Int
)

data class LoginRequest(
    val email: String,
    val password: String? = null,
    val name: String? = null,
    val phone: String? = null
)

data class LoginResponse(
    val success: Boolean,
    val token: String? = null,
    val user: ApiUser? = null,
    val error: String? = null
)

data class ApiUser(
    val id: String,
    val name: String,
    val email: String,
    val phone: String = "",
    val role: String = "user"
)

data class SeedRequest(
    val key: String = "dev"
)

data class SeedResponse(
    val ok: Boolean? = null,
    val success: Boolean? = null,
    val admin_id: String? = null,
    val email: String? = null,
    val password: String? = null,
    val error: String? = null
)

interface ApiService {
    @GET("bikes")
    fun getBikes(
        @Query("q") query: String? = null,
        @Query("location") location: String? = null,
        @Query("status") status: String? = null,
        @Query("verify") verify: String? = null,
        @Query("limit") limit: Int? = null
    ): Call<List<ApiBike>>

    @POST("bikes")
    fun createBike(@Body body: CreateBikeRequest): Call<Map<String, Any>>

    @GET("bikes/{id}")
    fun getBike(@Path("id") id: String): Call<ApiBike>

    @POST("bookings")
    fun createBooking(@Body body: CreateBookingRequest): Call<Map<String, Any>>

    @GET("bookings")
    fun getBookings(@Query("user_id") userId: String? = null): Call<List<ApiBooking>>

    @PATCH("bookings/{id}/cancel")
    fun cancelBooking(@Path("id") id: String, @Body body: Map<String, String>): Call<Map<String, Any>>

    @POST("auth/login")
    fun login(@Body body: LoginRequest): Call<LoginResponse>

    @GET("auth/me")
    fun getCurrentUser(@Header("Authorization") token: String): Call<LoginResponse>

    @POST("admin/seed")
    fun seedAdmin(@Body body: SeedRequest): Call<SeedResponse>
}


